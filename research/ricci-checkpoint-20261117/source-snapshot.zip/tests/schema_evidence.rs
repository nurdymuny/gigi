use gigi::engine::schema_evidence::fingerprint_plain_schema;
use gigi::types::*;
use sha2::{Digest, Sha256};
use std::{
    alloc::{GlobalAlloc, Layout, System},
    cell::Cell,
};

thread_local! {
    static TRACK: Cell<bool> = const { Cell::new(false) };
    static ALLOCATED: Cell<usize> = const { Cell::new(0) };
}
struct MeasuredAllocator;
fn account(bytes: usize) {
    let _ = TRACK.try_with(|on| {
        if on.get() {
            let _ = ALLOCATED.try_with(|n| n.set(n.get() + bytes));
        }
    });
}
unsafe impl GlobalAlloc for MeasuredAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = System.alloc(layout);
        if !p.is_null() {
            account(layout.size());
        }
        p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = System.alloc_zeroed(layout);
        if !p.is_null() {
            account(layout.size());
        }
        p
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let p = System.realloc(p, layout, size);
        if !p.is_null() {
            account(size);
        }
        p
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) {
        System.dealloc(p, layout);
    }
}
#[global_allocator]
static ALLOCATOR: MeasuredAllocator = MeasuredAllocator;

fn schema() -> BundleSchema {
    BundleSchema::new("a")
        .base(FieldDef::numeric("id"))
        .fiber(FieldDef::numeric("x"))
        .fiber(FieldDef::categorical("kind"))
}
fn hash(s: &BundleSchema) -> [u8; 32] {
    fingerprint_plain_schema(s, 16 * 1024 * 1024)
        .unwrap()
        .sha256
}

#[test]
fn each_value_tag_matches_independent_literal_byte_vectors() {
    let cases = vec![
        (Value::Null, vec![0]),
        (
            Value::Integer(-7),
            [vec![1], (-7i64).to_le_bytes().to_vec()].concat(),
        ),
        (
            Value::Float(-0.0),
            [vec![2], 0x8000000000000000u64.to_le_bytes().to_vec()].concat(),
        ),
        (
            Value::Float(f64::from_bits(0x7ff8000000000012)),
            [vec![2], 0x7ff8000000000012u64.to_le_bytes().to_vec()].concat(),
        ),
        (
            Value::Text("ab".into()),
            [vec![3], 2u64.to_le_bytes().to_vec(), b"ab".to_vec()].concat(),
        ),
        (Value::Bool(true), vec![4, 1]),
        (
            Value::Timestamp(-7),
            [vec![5], (-7i64).to_le_bytes().to_vec()].concat(),
        ),
        (
            Value::Vector(vec![1.0, -0.0]),
            [
                vec![6],
                2u64.to_le_bytes().to_vec(),
                1.0f64.to_le_bytes().to_vec(),
                0x8000000000000000u64.to_le_bytes().to_vec(),
            ]
            .concat(),
        ),
        (
            Value::Binary(vec![0, 255]),
            [vec![7], 2u64.to_le_bytes().to_vec(), vec![0, 255]].concat(),
        ),
    ];
    for (value, payload) in cases {
        let s = BundleSchema::new("ignored").fiber(FieldDef::numeric("x").with_default(value));
        let mut bytes = b"GIGI-SOURCE-SCHEMA\x01".to_vec();
        bytes.extend(0u64.to_le_bytes()); // base count
        bytes.extend(1u64.to_le_bytes()); // fiber count
        bytes.extend(1u64.to_le_bytes());
        bytes.push(b'x');
        bytes.push(0); // name and Numeric
        bytes.extend(payload);
        bytes.push(0); // default and absent range
        bytes.extend(1.0f64.to_le_bytes());
        bytes.extend([0; 3]); // weight, encryption, group, unit
        bytes.extend([0; 8]);
        bytes.extend([0; 5]); // indices, gauge, seed, order, retention, rows
        bytes.extend([0; 8]);
        bytes.extend(3.0f64.to_le_bytes()); // adjacency, h1
        bytes.extend([0; 8]);
        bytes.push(0); // invariants, Kahler
        let e = fingerprint_plain_schema(&s, bytes.len()).unwrap();
        assert_eq!(e.encoded_schema_bytes, bytes.len() as u64);
        assert_eq!(e.sha256, <[u8; 32]>::from(Sha256::digest(bytes)));
    }
}
fn differs(edit: impl FnOnce(&mut BundleSchema)) {
    let original = schema();
    let mut changed = original.clone();
    edit(&mut changed);
    assert_ne!(hash(&original), hash(&changed));
}

#[test]
fn full_schema_matches_independent_python_golden() {
    // Reproduced by scripts/verify_schema_evidence_wine.py::simple_schema_golden.
    let e = fingerprint_plain_schema(&schema(), 10000).unwrap();
    let hex: String = e.sha256.iter().map(|b| format!("{b:02x}")).collect();
    assert_eq!(e.encoded_schema_bytes, 146);
    assert_eq!(
        hex,
        "bf15e96915a5c1439af7ce97aae875bb40091f9cfe3dbef067e74c6011430ccd"
    );
    #[cfg(feature = "kahler")]
    {
        use gigi::geometry::{ClosedTwoForm, ComplexStructure, KahlerStructure, TwoForm};
        let mut s = schema();
        s.kahler = Some(KahlerStructure::new(
            ComplexStructure::standard(1),
            ClosedTwoForm::new_constant(TwoForm::new(vec![0.0, 0.5, -0.5, 0.0], 2).unwrap()),
        ));
        let e = fingerprint_plain_schema(&s, 10000).unwrap();
        let hex: String = e.sha256.iter().map(|b| format!("{b:02x}")).collect();
        assert_eq!(e.encoded_schema_bytes, 242);
        assert_eq!(
            hex,
            "4c630988ecf36cb021ff3b426a5768203a4cda0822c756f38a496e72193d78f0"
        );
    }
}

#[test]
fn retention_and_row_semantics_variants_remain_distinct() {
    let hashes: std::collections::HashSet<_> = [
        Retention::Undeclared,
        Retention::Days(0),
        Retention::Days(1),
        Retention::Days(u32::MAX),
        Retention::Indefinite,
    ]
    .into_iter()
    .map(|r| {
        let mut s = schema();
        s.retention = r;
        hash(&s)
    })
    .collect();
    assert_eq!(hashes.len(), 5);
    let hashes: std::collections::HashSet<_> = [
        RowSemantics::Unspecified,
        RowSemantics::ClockSamples,
        RowSemantics::DiscreteEvents,
    ]
    .into_iter()
    .map(|r| {
        let mut s = schema();
        s.row_semantics = r;
        hash(&s)
    })
    .collect();
    assert_eq!(hashes.len(), 3);
}

#[test]
fn empty_schema_has_independent_byte_oracle_and_rename_invariance() {
    let mut bytes = b"GIGI-SOURCE-SCHEMA\x01".to_vec();
    // Empty base, fiber and index lists; absent gauge, Random seed, absent order.
    bytes.extend([0; 24]);
    bytes.extend([0; 3]);
    // Undeclared retention, Unspecified rows, empty adjacencies.
    bytes.extend([0; 2]);
    bytes.extend([0; 8]);
    bytes.extend(3.0f64.to_le_bytes());
    bytes.extend([0; 8]); // invariants
    bytes.push(0); // Kahler absent, independently of build features
    let actual = fingerprint_plain_schema(&BundleSchema::new("one"), bytes.len()).unwrap();
    assert_eq!(actual.format_version, 1);
    assert_eq!(actual.encoded_schema_bytes, bytes.len() as u64);
    assert_eq!(actual.sha256, <[u8; 32]>::from(Sha256::digest(&bytes)));
    assert_eq!(
        actual,
        fingerprint_plain_schema(&BundleSchema::new("two"), bytes.len()).unwrap()
    );
}

#[test]
fn field_settings_and_order_participate() {
    differs(|s| s.base_fields[0].name = "other_id".into());
    differs(|s| s.base_fields[0].weight = 2.0);
    differs(|s| s.fiber_fields[0].name = "other_x".into());
    differs(|s| s.fiber_fields[0].range = Some(2.0));
    differs(|s| s.fiber_fields[0].weight = 2.0);
    differs(|s| s.fiber_fields[0].unit = Some("mV".into()));
    differs(|s| s.fiber_fields[0].encryption_group = Some("group".into()));
    differs(|s| s.fiber_fields.swap(0, 1));
    differs(|s| {
        s.indexed_fields.push("x".into());
    });
    let mut s = schema();
    s.indexed_fields = vec!["x".into(), "kind".into()];
    let a = hash(&s);
    s.indexed_fields.reverse();
    assert_ne!(a, hash(&s));
    s.indexed_fields.push("x".into());
    assert_ne!(a, hash(&s));
}

#[test]
fn type_variants_and_payloads_are_distinct() {
    let types = [
        FieldType::Numeric,
        FieldType::Categorical,
        FieldType::Timestamp,
        FieldType::Binary,
        FieldType::Vector { dims: 2 },
        FieldType::Vector { dims: 3 },
        FieldType::OrderedCat {
            order: vec!["a".into(), "b".into()],
        },
        FieldType::OrderedCat {
            order: vec!["b".into(), "a".into()],
        },
    ];
    let hashes: std::collections::HashSet<_> = types
        .into_iter()
        .map(|t| {
            let mut s = schema();
            s.fiber_fields[0].field_type = t;
            hash(&s)
        })
        .collect();
    assert_eq!(hashes.len(), 8);
}

#[test]
fn default_values_preserve_types_bits_and_vector_order() {
    let values = [
        Value::Null,
        Value::Integer(0),
        Value::Integer(i64::MAX),
        Value::Timestamp(0),
        Value::Float(0.0),
        Value::Float(-0.0),
        Value::Float(f64::from_bits(0x7ff8000000000001)),
        Value::Float(f64::from_bits(0x7ff8000000000002)),
        Value::Float(f64::INFINITY),
        Value::Text("a".into()),
        Value::Binary(vec![b'a']),
        Value::Bool(false),
        Value::Bool(true),
        Value::Vector(vec![1.0, 2.0]),
        Value::Vector(vec![2.0, 1.0]),
    ];
    let n = values.len();
    let hashes: std::collections::HashSet<_> = values
        .into_iter()
        .map(|v| {
            let mut s = schema();
            s.fiber_fields[0].default = v;
            hash(&s)
        })
        .collect();
    assert_eq!(hashes.len(), n);
}

#[test]
fn source_declarations_and_option_presence_participate() {
    differs(|s| s.order_field = Some("x".into()));
    differs(|s| s.order_field = Some("".into()));
    differs(|s| s.seed_source = EncryptionSeedSource::Env("SOURCE_A".into()));
    let mut s = schema();
    s.seed_source = EncryptionSeedSource::Env("A".into());
    let h = hash(&s);
    s.seed_source = EncryptionSeedSource::Env("B".into());
    assert_ne!(h, hash(&s));
    for r in [
        Retention::Days(0),
        Retention::Days(1),
        Retention::Indefinite,
    ] {
        differs(|s| s.retention = r);
    }
    for r in [RowSemantics::ClockSamples, RowSemantics::DiscreteEvents] {
        differs(|s| s.row_semantics = r);
    }
    let mut s = schema();
    s.fiber_fields[0].range = Some(0.0);
    let h = hash(&s);
    s.fiber_fields[0].range = Some(-0.0);
    assert_ne!(h, hash(&s));
}

#[test]
fn adjacency_variants_parameters_and_invariants_participate() {
    let kinds = [
        AdjacencyKind::Equality { field: "x".into() },
        AdjacencyKind::Metric {
            field: "x".into(),
            radius: 1.0,
        },
        AdjacencyKind::Metric {
            field: "x".into(),
            radius: 2.0,
        },
        AdjacencyKind::Threshold {
            field: "x".into(),
            threshold: 1.0,
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Log10,
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Scale { a: 1.0, b: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Biofilm { lo: 1.0, hi: 2.0 },
        },
        AdjacencyKind::Morphism {
            source_bundle: "b".into(),
            join_field: "id".into(),
            quality: 0.5,
        },
    ];
    let hashes: std::collections::HashSet<_> = kinds
        .into_iter()
        .map(|kind| {
            let mut s = schema();
            s.adjacencies.push(AdjacencyDef {
                name: "a".into(),
                kind,
                weight: 1.0,
            });
            let h = hash(&s);
            assert_ne!(h, hash(&schema()));
            s.adjacencies[0].weight = 2.0;
            assert_ne!(h, hash(&s));
            h
        })
        .collect();
    assert_eq!(hashes.len(), 8);
    differs(|s| s.h1_threshold = 4.0);
    let mut s = schema();
    s.invariants.push(InvariantDef {
        expr_field: "x".into(),
        expected: 1.0,
        tol: 0.1,
    });
    let h = hash(&s);
    assert_ne!(h, hash(&schema()));
    s.invariants[0].expected = 2.0;
    assert_ne!(h, hash(&s));
    s.invariants[0].expected = 1.0;
    s.invariants[0].tol = 0.2;
    assert_ne!(h, hash(&s));
    s.invariants[0].tol = 0.1;
    s.invariants[0].expr_field = "y".into();
    assert_ne!(h, hash(&s));
}

#[test]
fn exact_limits_and_long_payload_are_enforced() {
    let mut s = schema();
    s.fiber_fields[0].default = Value::Text("x".repeat(100_000));
    let e = fingerprint_plain_schema(&s, 1_000_000).unwrap();
    assert_eq!(
        e,
        fingerprint_plain_schema(&s, e.encoded_schema_bytes as usize).unwrap()
    );
    for limit in [0, e.encoded_schema_bytes as usize - 1, 16 * 1024 * 1024 + 1] {
        assert!(fingerprint_plain_schema(&s, limit).is_err());
    }
}

#[test]
fn encrypted_sources_refuse_without_disclosing_keys() {
    for mode in [
        EncryptionMode::Affine,
        EncryptionMode::Opaque,
        EncryptionMode::Indexed,
        EncryptionMode::Probabilistic { sigma: 0.1 },
        EncryptionMode::Isometric,
    ] {
        let mut s = schema();
        s.fiber_fields[0].encryption = mode;
        let error = fingerprint_plain_schema(&s, 10000).unwrap_err();
        assert!(error.contains("encryption"), "{error}");
    }
    let mut s = schema();
    s.gauge_key = Some(gigi::crypto::GaugeKey { transforms: vec![] });
    assert!(fingerprint_plain_schema(&s, 10000)
        .unwrap_err()
        .contains("gauge_key"));
    s.gauge_key = None;
    s.seed_source = EncryptionSeedSource::Hex("DO_NOT_DISCLOSE_THIS_SEED".into());
    let error = fingerprint_plain_schema(&s, 10000).unwrap_err();
    assert!(error.contains("seed_source"));
    assert!(!error.contains("DO_NOT_DISCLOSE"));
}

#[test]
fn success_streams_without_allocating_or_cloning_the_schema() {
    let mut s = schema();
    s.fiber_fields[0].default = Value::Binary(vec![42; 1024 * 1024]);
    let expected = fingerprint_plain_schema(&s, 2 * 1024 * 1024).unwrap();
    ALLOCATED.with(|n| n.set(0));
    TRACK.with(|on| on.set(true));
    let result = fingerprint_plain_schema(&s, 2 * 1024 * 1024);
    TRACK.with(|on| on.set(false));
    assert_eq!(result.unwrap(), expected);
    assert_eq!(ALLOCATED.with(Cell::get), 0);
}

#[test]
fn adjacency_payloads_and_sequence_positions_are_not_interchangeable() {
    let cases = vec![
        AdjacencyKind::Equality { field: "x".into() },
        AdjacencyKind::Equality { field: "y".into() },
        AdjacencyKind::Threshold {
            field: "x".into(),
            threshold: 1.0,
        },
        AdjacencyKind::Threshold {
            field: "x".into(),
            threshold: 2.0,
        },
        AdjacencyKind::Threshold {
            field: "y".into(),
            threshold: 1.0,
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Scale { a: 1.0, b: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "z".into(),
            target_field: "y".into(),
            transform: TransformFn::Scale { a: 1.0, b: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "z".into(),
            transform: TransformFn::Scale { a: 1.0, b: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Scale { a: 2.0, b: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Scale { a: 1.0, b: 3.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Biofilm { lo: 1.0, hi: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Biofilm { lo: 0.0, hi: 2.0 },
        },
        AdjacencyKind::Transform {
            source_field: "x".into(),
            target_field: "y".into(),
            transform: TransformFn::Biofilm { lo: 1.0, hi: 3.0 },
        },
        AdjacencyKind::Morphism {
            source_bundle: "b".into(),
            join_field: "id".into(),
            quality: 0.5,
        },
        AdjacencyKind::Morphism {
            source_bundle: "c".into(),
            join_field: "id".into(),
            quality: 0.5,
        },
        AdjacencyKind::Morphism {
            source_bundle: "b".into(),
            join_field: "key".into(),
            quality: 0.5,
        },
        AdjacencyKind::Morphism {
            source_bundle: "b".into(),
            join_field: "id".into(),
            quality: 0.75,
        },
    ];
    let n = cases.len();
    let hashes: std::collections::HashSet<_> = cases
        .into_iter()
        .map(|kind| {
            let mut s = schema();
            s.adjacencies.push(AdjacencyDef {
                name: "a".into(),
                kind,
                weight: 1.0,
            });
            let h = hash(&s);
            s.adjacencies[0].name = "b".into();
            assert_ne!(h, hash(&s));
            h
        })
        .collect();
    assert_eq!(hashes.len(), n);
    let mut s = schema();
    for name in ["a", "b"] {
        s.adjacencies.push(AdjacencyDef {
            name: name.into(),
            kind: AdjacencyKind::Equality { field: "x".into() },
            weight: 1.0,
        });
    }
    let h = hash(&s);
    s.adjacencies.reverse();
    assert_ne!(h, hash(&s));
}

#[cfg(feature = "kahler")]
#[test]
fn geometric_matrices_are_not_silently_omitted() {
    use gigi::geometry::{ClosedTwoForm, ComplexStructure, KahlerStructure, TwoForm};
    let mut s = schema();
    let original = hash(&s);
    let k = |j, b| {
        KahlerStructure::new(
            j,
            ClosedTwoForm::new_constant(TwoForm::new(vec![0.0, b, -b, 0.0], 2).unwrap()),
        )
    };
    s.kahler = Some(k(ComplexStructure::standard(1), 0.5));
    let h = hash(&s);
    assert_ne!(h, original);
    s.kahler = Some(k(ComplexStructure::standard(1), 0.75));
    assert_ne!(h, hash(&s));
    let j = ComplexStructure::new(
        ComplexStructure::standard(1)
            .matrix()
            .iter()
            .map(|x| -x)
            .collect(),
        2,
    )
    .unwrap();
    s.kahler = Some(k(j, 0.5));
    assert_ne!(h, hash(&s));
}
