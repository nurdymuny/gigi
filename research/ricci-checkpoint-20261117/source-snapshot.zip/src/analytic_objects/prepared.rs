use crate::geometry::{
    harmonic_conjugate::{self, Polynomial, RealTerm},
    holomorphic::{self, Observation, Point, Representation},
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Serialize)]
pub struct Answer {
    pub z: Point,
    pub value: Point,
    pub first_derivative: Option<Point>,
    pub second_derivative: Option<Point>,
    pub center: Option<Point>,
    pub radius: Option<f64>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct InformationContract {
    pub model_class: String,
    pub operations: Vec<String>,
    pub discarded: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
enum Model {
    Polynomial(Polynomial),
    Family {
        representation: Representation,
        observations: Vec<Observation>,
    },
}

#[derive(Debug, Clone, Serialize)]
pub struct Prepared {
    model: Model,
    scale: f64,
    normalization_count: Option<u64>,
    information: InformationContract,
    evidence: serde_json::Value,
}

impl Prepared {
    pub(crate) fn heap_charge(&self) -> usize {
        use std::mem::size_of;
        fn value_heap(value: &serde_json::Value) -> usize {
            use serde_json::Value;
            match value {
                Value::String(s) => s.capacity(),
                Value::Array(a) => {
                    a.capacity() * size_of::<Value>() + a.iter().map(value_heap).sum::<usize>()
                }
                // serde_json::Map does not expose capacity. Immutable decoded
                // maps get a conservative fourfold capacity/control allowance.
                Value::Object(m) => {
                    4 * (m.len() + 2) * (size_of::<String>() + size_of::<Value>() + 32)
                        + m.iter()
                            .map(|(k, v)| k.capacity() + value_heap(v))
                            .sum::<usize>()
                }
                _ => 0,
            }
        }
        let model = match &self.model {
            Model::Polynomial(p) => p.coefficients.capacity() * size_of::<Point>(),
            Model::Family {
                representation,
                observations,
            } => {
                representation.steps.capacity() * size_of::<holomorphic::SchurStep>()
                    + observations.capacity() * size_of::<Observation>()
            }
        };
        let strings = |v: &Vec<String>| {
            v.capacity() * size_of::<String>() + v.iter().map(String::capacity).sum::<usize>()
        };
        size_of::<Self>()
            + 16
            + model
            + self.information.model_class.capacity()
            + strings(&self.information.operations)
            + strings(&self.information.discarded)
            + value_heap(&self.evidence)
    }
    pub(crate) fn validate_points(points: &[Point]) -> Result<(), String> {
        if points.len() > 256 {
            return Err("provide at most 256 query points".into());
        }
        for (i, z) in points.iter().enumerate() {
            if !z[0].is_finite() || !z[1].is_finite() || z[0].hypot(z[1]) > 1. - 1e-8 {
                return Err(format!(
                    "query {i} must be finite and have modulus <=1-1e-8"
                ));
            }
        }
        Ok(())
    }
    pub(crate) fn representation_hash(&self) -> Result<[u8; 32], String> {
        let bytes = super::encoding::encode(
            &serde_json::json!({"model":self.model,"scale":self.scale,"normalization_count":self.normalization_count}),
        )?;
        Ok(Sha256::digest(bytes).into())
    }
    pub fn encode(&self) -> Result<Vec<u8>, String> {
        super::encoding::encode(
            &serde_json::json!({"evaluator": "gigi-analytic-binary64-v1", "prepared": self}),
        )
    }
    pub fn restore(bytes: &[u8], expected_digest: &[u8; 32]) -> Result<Self, String> {
        if bytes.len() > super::encoding::MAX_BYTES {
            return Err("resource_limit: prepared representation too large".into());
        }
        let actual: [u8; 32] = Sha256::digest(bytes).into();
        if actual != *expected_digest {
            return Err("corrupt_object: representation digest mismatch".into());
        }
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Stored {
            model: Model,
            scale: f64,
            normalization_count: Option<u64>,
            information: InformationContract,
            evidence: serde_json::Value,
        }
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Envelope {
            evaluator: String,
            prepared: Stored,
        }
        let envelope: Envelope = serde_json::from_value(super::encoding::decode(bytes)?)
            .map_err(|e| format!("corrupt_object: invalid stored structure: {e}"))?;
        if envelope.evaluator != "gigi-analytic-binary64-v1" {
            return Err("unsupported_version: evaluator".into());
        }
        let data = envelope.prepared;
        let result = Self {
            model: data.model,
            scale: data.scale,
            normalization_count: data.normalization_count,
            information: data.information,
            evidence: data.evidence,
        };
        result.validate()?;
        Ok(result)
    }
    fn validate(&self) -> Result<(), String> {
        let invalid = || "corrupt_object: representation/evidence invariants disagree".to_string();
        if !self.scale.is_finite() || self.scale <= 0. {
            return Err(invalid());
        }
        match &self.model {
            Model::Polynomial(model) => {
                let mut bound =
                    harmonic_conjugate::validate_bound(&model.coefficients, model.bound)
                        .ok_or_else(invalid)?;
                if bound.upper > model.bound
                    || model.conjugate_at_center != model.coefficients[0][1]
                    || self.evidence["status"] != "bounded_holomorphic"
                    || self.evidence["reconstruction_residual"].as_f64() != Some(0.)
                {
                    return Err(invalid());
                }
                let (class, discarded) = if let Some(total) = self.normalization_count {
                    if total == 0 || total > 1u64 << 53 || self.scale != 1. / total as f64 {
                        return Err(invalid());
                    }
                    let counts = self.evidence["integer_counts"]
                        .as_array()
                        .ok_or_else(invalid)?;
                    if counts.is_empty() || counts.len() > 33 {
                        return Err(invalid());
                    }
                    let mut sum = 0u64;
                    for (i, count) in counts.iter().enumerate() {
                        let count = count.as_u64().ok_or_else(invalid)?;
                        sum = sum.checked_add(count).ok_or_else(invalid)?;
                        if model.coefficients.get(i).copied().unwrap_or([0., 0.])
                            != [count as f64, 0.]
                        {
                            return Err(invalid());
                        }
                    }
                    if sum != total
                        || model.coefficients.len() > counts.len()
                        || self.evidence["normalization_count"].as_u64() != Some(total)
                        || self.evidence["output_scale"].as_f64() != Some(self.scale)
                    {
                        return Err(invalid());
                    }
                    let declared = self.evidence["declared_bound"]
                        .as_f64()
                        .ok_or_else(invalid)?;
                    if declared * total as f64 != model.bound {
                        return Err(invalid());
                    }
                    (
                        "empirical_histogram_polynomial",
                        vec![
                            "row_identity",
                            "time_and_order",
                            "within_bin_detail",
                            "joint_cross_field_dependence",
                        ],
                    )
                } else {
                    if self.scale != 1. {
                        return Err(invalid());
                    }
                    ("bounded_holomorphic_polynomial", vec![])
                };
                bound.upper *= self.scale;
                bound.lower *= self.scale;
                bound.allowance *= self.scale;
                if serde_json::to_value(bound).map_err(|e| e.to_string())?
                    != self.evidence["bound_evidence"]
                    || self.information
                        != (InformationContract {
                            model_class: class.into(),
                            operations: vec!["value_and_derivatives".into()],
                            discarded: discarded.into_iter().map(String::from).collect(),
                        })
                {
                    return Err(invalid());
                }
            }
            Model::Family {
                representation,
                observations,
            } => {
                if self.scale != 1. || self.normalization_count.is_some() {
                    return Err(invalid());
                }
                representation.validate(observations)?;
                let status = if representation.free_terminal {
                    "feasible_family"
                } else {
                    "feasible_unique"
                };
                if self.evidence["status"] != status {
                    return Err(invalid());
                }
                let min = self.evidence["min_pick_eigenvalue"]
                    .as_f64()
                    .ok_or_else(invalid)?;
                let tolerance = self.evidence["pick_tolerance"]
                    .as_f64()
                    .ok_or_else(invalid)?;
                let error = self.evidence["max_interpolation_error"]
                    .as_f64()
                    .ok_or_else(invalid)?;
                if !min.is_finite()
                    || !tolerance.is_finite()
                    || tolerance < 1e-10
                    || min < -tolerance
                    || (representation.free_terminal && min <= tolerance)
                    || !(0. ..=1e-8).contains(&error)
                    || self.information
                        != (InformationContract {
                            model_class: "bounded_holomorphic_family".into(),
                            operations: vec!["value_disk".into()],
                            discarded: vec![
                                "unobserved_function_not_uniquely_identified_by_a_representative"
                                    .into(),
                            ],
                        })
                {
                    return Err(invalid());
                }
            }
        }
        Ok(())
    }
    pub fn histogram_from_values(
        values: &[f64],
        edges: &[f64],
        bound: f64,
    ) -> Result<Self, String> {
        if !(2..=34).contains(&edges.len())
            || edges.iter().any(|v| !v.is_finite())
            || edges.windows(2).any(|v| v[0] >= v[1])
        {
            return Err("provide 2..34 finite strictly increasing bin edges".into());
        }
        let mut counts = vec![0u64; edges.len() - 1];
        let (mut nonfinite, mut below, mut above) = (0usize, 0usize, 0usize);
        for &value in values {
            crate::geometry::analytic_work::record(|w| w.source_rows += 1);
            if !value.is_finite() {
                nonfinite += 1;
                continue;
            }
            if value < edges[0] {
                below += 1;
                continue;
            }
            if value > edges[edges.len() - 1] {
                above += 1;
                continue;
            }
            let bin = (edges.partition_point(|&edge| edge <= value) - 1).min(counts.len() - 1);
            counts[bin] = counts[bin]
                .checked_add(1)
                .ok_or("histogram count overflow")?;
        }
        if nonfinite + below + above != 0 {
            return Err(format!("invalid histogram observations: nonfinite={nonfinite}, below_range={below}, above_range={above}; correct data or explicitly revise the fixed bin policy; no rows were silently omitted"));
        }
        let mut model = Self::histogram(&counts, bound)?;
        model.evidence["bin_edges"] = serde_json::to_value(edges).map_err(|e| e.to_string())?;
        model.evidence["endpoint_policy"] = "left_closed_right_open_last_closed".into();
        Ok(model)
    }
    pub fn polynomial(terms: &[RealTerm], imaginary: f64, bound: f64) -> Result<Self, String> {
        let result = harmonic_conjugate::recover(terms, imaginary, bound, &[])?;
        let mut evidence = serde_json::to_value(&result).map_err(|e| e.to_string())?;
        evidence
            .as_object_mut()
            .expect("Recovery serializes as object")
            .remove("representation");
        let model = result
            .representation
            .ok_or_else(|| format!("{}: {}", result.status, result.reason))?;
        Ok(Self {
            model: Model::Polynomial(model),
            scale: 1.,
            normalization_count: None,
            information: InformationContract {
                model_class: "bounded_holomorphic_polynomial".into(),
                operations: vec!["value_and_derivatives".into()],
                discarded: vec![],
            },
            evidence,
        })
    }
    pub fn family(observations: &[Observation], bound: f64) -> Result<Self, String> {
        let result = holomorphic::complete(observations, bound, &[])?;
        let mut evidence = serde_json::to_value(&result).map_err(|e| e.to_string())?;
        evidence
            .as_object_mut()
            .expect("Completion serializes as object")
            .remove("representation");
        let representation = result
            .representation
            .ok_or_else(|| format!("{}: {}", result.status, result.reason))?;
        Ok(Self {
            model: Model::Family {
                representation,
                observations: observations.to_vec(),
            },
            scale: 1.,
            normalization_count: None,
            information: InformationContract {
                model_class: "bounded_holomorphic_family".into(),
                operations: vec!["value_disk".into()],
                discarded: vec![
                    "unobserved_function_not_uniquely_identified_by_a_representative".into(),
                ],
            },
            evidence,
        })
    }
    pub fn histogram(counts: &[u64], bound: f64) -> Result<Self, String> {
        if counts.is_empty() || counts.len() > 33 {
            return Err("histogram requires 1..33 counts".into());
        }
        let total = counts.iter().try_fold(0u64, |n, &v| n.checked_add(v))
            .filter(|&n| n > 0 && n <= 1u64 << 53)
            .ok_or("histogram total must be positive and exactly representable in the supported integer range")?;
        let mut terms = Vec::new();
        for (n, &count) in counts.iter().enumerate() {
            let mut choose = 1u64;
            for q in 0..=n {
                if q % 2 == 0 && count != 0 {
                    let product = u128::from(count) * u128::from(choose);
                    if product > 1u128 << 53 {
                        return Err("unsupported_exact_expansion: binomial coefficient product exceeds 2^53; use fewer bins or smaller exact counts".into());
                    }
                    let coefficient = product as f64 * if q % 4 == 0 { 1. } else { -1. };
                    terms.push(RealTerm {
                        x_power: n - q,
                        y_power: q,
                        coefficient,
                    });
                }
                if q < n {
                    choose = choose * (n - q) as u64 / (q + 1) as u64;
                }
            }
        }
        let mut result = Self::polynomial(&terms, 0., bound * total as f64)?;
        result.scale = 1. / total as f64;
        result.normalization_count = Some(total);
        result.information.model_class = "empirical_histogram_polynomial".into();
        result.information.discarded = [
            "row_identity",
            "time_and_order",
            "within_bin_detail",
            "joint_cross_field_dependence",
        ]
        .map(String::from)
        .into();
        result.evidence["normalization_count"] = total.into();
        result.evidence["integer_counts"] =
            serde_json::to_value(counts).map_err(|e| e.to_string())?;
        result.evidence["output_scale"] = result.scale.into();
        result.evidence["declared_bound"] = bound.into();
        for field in ["upper", "lower", "allowance"] {
            let internal = result.evidence["bound_evidence"][field]
                .as_f64()
                .ok_or("accepted polynomial is missing bound evidence")?;
            result.evidence["bound_evidence"][field] = (internal * result.scale).into();
        }
        Ok(result)
    }
    pub fn information(&self) -> &InformationContract {
        &self.information
    }
    pub fn evidence(&self) -> &serde_json::Value {
        &self.evidence
    }
    pub fn scale(&self) -> f64 {
        self.scale
    }

    pub fn query(&self, points: &[Point]) -> Result<Vec<Answer>, String> {
        Self::validate_points(points)?;
        let scaled = |z: Point| [z[0] * self.scale, z[1] * self.scale];
        points
            .iter()
            .map(|&z| match &self.model {
                Model::Polynomial(model) => {
                    let value = model
                        .evaluate(z)
                        .ok_or("numerically_unresolved: unsafe polynomial evaluation")?;
                    Ok(Answer {
                        z,
                        value: scaled(value.value),
                        first_derivative: Some(scaled(value.first_derivative)),
                        second_derivative: Some(scaled(value.second_derivative)),
                        center: None,
                        radius: None,
                    })
                }
                Model::Family {
                    representation,
                    observations,
                } => {
                    let value = representation.query(z, observations)?;
                    Ok(Answer {
                        z,
                        value: value.representative,
                        center: Some(value.center),
                        radius: Some(value.radius),
                        first_derivative: None,
                        second_derivative: None,
                    })
                }
            })
            .collect()
    }
}
