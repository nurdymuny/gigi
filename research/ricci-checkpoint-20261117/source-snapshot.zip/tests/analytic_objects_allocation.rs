#![cfg(feature = "kahler")]
use gigi::analytic_objects::{prepared::Prepared, registry::*};
use std::{
    alloc::{GlobalAlloc, Layout, System},
    cell::Cell,
};

thread_local! {
    static TRACK:Cell<bool>=const {Cell::new(false)};
    static ALLOCATED:Cell<usize>=const {Cell::new(0)};
    static LIVE:Cell<isize>=const {Cell::new(0)};
}
struct MeasuredAllocator;
fn account(bytes: usize) {
    let _ = TRACK.try_with(|active| {
        if active.get() {
            let _ = ALLOCATED.try_with(|n| n.set(n.get() + bytes));
        }
    });
}
fn retained(bytes: isize) {
    let _ = TRACK.try_with(|active| {
        if active.get() {
            let _ = LIVE.try_with(|n| n.set(n.get() + bytes));
        }
    });
}
unsafe impl GlobalAlloc for MeasuredAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let pointer = System.alloc(layout);
        if !pointer.is_null() {
            account(layout.size());
            retained(layout.size() as isize);
        }
        pointer
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let pointer = System.alloc_zeroed(layout);
        if !pointer.is_null() {
            account(layout.size());
            retained(layout.size() as isize);
        }
        pointer
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let pointer = System.realloc(pointer, layout, size);
        if !pointer.is_null() {
            account(size);
            retained(size as isize - layout.size() as isize);
        }
        pointer
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        retained(-(layout.size() as isize));
        System.dealloc(pointer, layout);
    }
}

#[test]
fn allocator_observed_retained_cache_memory_stays_below_charged_budgets() {
    let source = SourceRevision {
        bundle_id: "4bbd50a4-f478-42d1-a19e-d27601834bb4".into(),
        incarnation: "21cc3633-e53f-4649-aed5-d77c0ee482a4".into(),
        revision: 7,
        schema_digest: [1; 32],
    };
    let request = BuildRequest {
        object_id: None,
        expected_head: None,
        sources: vec![SourceSnapshot {
            name: "measurements".into(),
            source: source.clone(),
            content_digest: [2; 32],
            records: 3,
        }],
        coordinates: Coordinates {
            input_units: "dimensionless".into(),
            output_units: "frequency".into(),
            meaning: "polynomial coordinate".into(),
            chart: "unit_disk".into(),
            regime: "fixture".into(),
            normalization: "1/N".into(),
        },
        recipe: serde_json::json!({"kind":"histogram"}),
        numerical_policy: POLICY.into(),
    };
    let tmp = tempfile::tempdir().unwrap();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let mut manifests = Vec::new();
    for i in 0..12 {
        manifests.push(
            registry
                .prepare(
                    "bee",
                    &format!("object-{i}"),
                    &request,
                    || Ok(vec![source.clone()]),
                    || Prepared::histogram(&[2, 1], 1.01),
                )
                .unwrap(),
        );
    }
    registry.configure_caches(24 * 1024, 4 * 1024).unwrap();
    LIVE.with(|n| n.set(0));
    TRACK.with(|t| t.set(true));
    for i in 0..1024 {
        let manifest = &manifests[i % manifests.len()];
        let result = registry
            .query(
                "bee",
                &manifest.object_id,
                &manifest.version_id,
                Freshness::Pinned,
                "value_and_derivatives",
                &[[i as f64 / 2048., 0.]],
                None,
            )
            .unwrap();
        assert!((result.answers[0].value[0] - (2. + i as f64 / 2048.) / 3.).abs() < 1e-12);
        drop(result);
        let measured = LIVE.with(Cell::get);
        let usage = registry.cache_usage();
        let charged = usage[0].1 + usage[1].1;
        assert!(
            measured >= 0,
            "measurement unexpectedly freed pre-existing state"
        );
        assert!(
            measured as usize <= charged,
            "allocator retained {measured}, reported charge {charged}"
        );
        assert!(usage[0].1 <= 24 * 1024 && usage[1].1 <= 4 * 1024);
    }
    registry.configure_caches(0, 0).unwrap();
    let after_clear = LIVE.with(Cell::get);
    TRACK.with(|t| t.set(false));
    assert_eq!(
        after_clear, 0,
        "cache disabling must release all measured retained allocations"
    );
}
#[global_allocator]
static ALLOCATOR: MeasuredAllocator = MeasuredAllocator;

#[test]
fn cached_scalar_does_not_copy_a_large_recipe_or_evidence_document() {
    let source = SourceRevision {
        bundle_id: "4bbd50a4-f478-42d1-a19e-d27601834bb4".into(),
        incarnation: "21cc3633-e53f-4649-aed5-d77c0ee482a4".into(),
        revision: 7,
        schema_digest: [1; 32],
    };
    let request = BuildRequest {
        object_id: None,
        expected_head: None,
        sources: vec![SourceSnapshot {
            name: "measurements".into(),
            source: source.clone(),
            content_digest: [2; 32],
            records: 3,
        }],
        coordinates: Coordinates {
            input_units: "dimensionless".into(),
            output_units: "frequency".into(),
            meaning: "polynomial coordinate".into(),
            chart: "unit_disk".into(),
            regime: "fixture".into(),
            normalization: "1/N".into(),
        },
        recipe: serde_json::json!({"kind":"histogram","lineage_notes":"e".repeat(24*1024)}),
        numerical_policy: POLICY.into(),
    };
    let tmp = tempfile::tempdir().unwrap();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let manifest = registry
        .prepare(
            "bee",
            "one",
            &request,
            || Ok(vec![source.clone()]),
            || Prepared::histogram(&[2, 1], 1.01),
        )
        .unwrap();
    registry
        .query(
            "bee",
            &manifest.object_id,
            &manifest.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0.25, 0.]],
            None,
        )
        .unwrap();
    ALLOCATED.with(|n| n.set(0));
    TRACK.with(|t| t.set(true));
    let result = registry.query(
        "bee",
        &manifest.object_id,
        &manifest.version_id,
        Freshness::Pinned,
        "value_and_derivatives",
        &[[0.25, 0.]],
        None,
    );
    TRACK.with(|t| t.set(false));
    let allocated = ALLOCATED.with(Cell::get);
    let result = result.unwrap();
    assert_eq!(result.execution_mode, "point_cache_hit");
    assert!(
        allocated < 16 * 1024,
        "cached scalar allocated {allocated} bytes; recipe/evidence must not be cloned"
    );
    assert!(serde_json::to_vec(&result).unwrap().len() <= 8192);
}
