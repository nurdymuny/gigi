//! Per-thread operation receipts for the synchronous analytic kernels.
use std::cell::Cell;

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, serde::Serialize)]
pub struct Work {
    pub preparations: u64,
    pub eigensolves: u64,
    pub recurrence_steps: u64,
    pub source_rows: u64,
}
thread_local! {
    static WORK: Cell<Work> = const { Cell::new(Work {
        preparations: 0, eigensolves: 0, recurrence_steps: 0, source_rows: 0,
    }) };
}
pub fn reset() {
    WORK.set(Work::default());
}
pub fn read() -> Work {
    WORK.get()
}
pub(crate) fn record(update: impl FnOnce(&mut Work)) {
    WORK.with(|cell| {
        let mut value = cell.get();
        update(&mut value);
        cell.set(value);
    });
}
