#![cfg(feature = "kahler")]
use gigi::geometry::harmonic_conjugate::{recover, RealTerm};
use nalgebra::Complex;

fn t(x: usize, y: usize, coefficient: f64) -> RealTerm {
    RealTerm {
        x_power: x,
        y_power: y,
        coefficient,
    }
}
fn near(a: f64, b: f64) {
    assert!((a - b).abs() < 1e-9, "{a} != {b}");
}
fn mixed() -> Vec<RealTerm> {
    vec![
        t(0, 0, 0.25),
        t(1, 0, 0.5),
        t(0, 1, 0.25),
        t(2, 0, 0.125),
        t(0, 2, -0.125),
        t(1, 1, -0.5),
    ]
}

#[test]
fn recovers_joint_pair_with_correct_conjugate_sign_and_derivatives() {
    let result = recover(&mixed(), 0.125, 2., &[[0.2, 0.3], [-0.4, 0.5]]).unwrap();
    assert_eq!(result.status, "bounded_holomorphic");
    near(result.reconstruction_residual.unwrap(), 0.);
    let model = result.representation.unwrap();
    assert_eq!(
        model.coefficients,
        vec![[0.25, 0.125], [0.5, -0.25], [0.125, 0.25]]
    );
    for q in result.queries {
        let [x, y] = q.z;
        near(
            q.value[0],
            0.25 + 0.5 * x + 0.25 * y + 0.125 * (x * x - y * y) - 0.5 * x * y,
        );
        near(
            q.value[1],
            0.125 + 0.5 * y - 0.25 * x + 0.25 * x * y + 0.25 * (x * x - y * y),
        );
        let derivative = Complex::new(0.5, -0.25) + Complex::new(0.25, 0.5) * Complex::new(x, y);
        near(q.first_derivative[0], derivative.re);
        near(q.first_derivative[1], derivative.im);
        assert_eq!(q.second_derivative, [0.25, 0.5]);
        let h = 1e-4;
        let xp = model.evaluate([x + h, y]).unwrap().value;
        let xm = model.evaluate([x - h, y]).unwrap().value;
        let yp = model.evaluate([x, y + h]).unwrap().value;
        let ym = model.evaluate([x, y - h]).unwrap().value;
        near((xp[0] - xm[0]) / (2. * h), (yp[1] - ym[1]) / (2. * h));
        near((yp[0] - ym[0]) / (2. * h), -(xp[1] - xm[1]) / (2. * h));
        for i in 0..2 {
            assert!(((xp[i] + xm[i] + yp[i] + ym[i] - 4. * q.value[i]) / (h * h)).abs() < 2e-7);
        }
    }
}

#[test]
fn refuses_nonharmonic_field_instead_of_discarding_y_coefficients() {
    let r = recover(&[t(2, 0, 1.), t(0, 2, 1.)], 0., 5., &[[0.2, 0.3]]).unwrap();
    assert_eq!(r.status, "non_harmonic");
    assert!(r.harmonic_residual.unwrap() > 0.);
    assert!(r.queries.is_empty() && r.representation.is_none());
}

#[test]
fn almost_harmonic_is_unresolved_not_silently_projected() {
    let r = recover(&[t(2, 0, 1.), t(0, 2, -1. + 1e-14)], 0., 5., &[]).unwrap();
    assert_eq!(r.status, "numerically_unresolved");
    assert!(r.reconstruction_residual.unwrap() > 0.);
    assert!(r.representation.is_none());
}

#[test]
fn imaginary_normalization_participates_in_full_bound() {
    let terms = [t(0, 0, 0.)];
    let good = recover(&terms, 0.5, 1., &[[0.3, 0.2]]).unwrap();
    assert_eq!(good.status, "bounded_holomorphic");
    assert_eq!(good.queries[0].value, [0., 0.5]);
    let bad = recover(&terms, 2., 1., &[]).unwrap();
    assert_eq!(bad.status, "bound_exceeded");
    assert!(bad.bound_evidence.unwrap().lower > 1.);
    assert!(bad.representation.is_none());
}

#[test]
fn mesh_bound_handles_cancellation_where_triangle_bound_fails() {
    // f=1+z-z^2 has boundary maximum sqrt(5), not coefficient L1=3.
    let r = recover(
        &[t(0, 0, 1.), t(1, 0, 1.), t(2, 0, -1.), t(0, 2, 1.)],
        0.,
        2.5,
        &[],
    )
    .unwrap();
    assert_eq!(r.status, "bounded_holomorphic");
    let b = r.bound_evidence.unwrap();
    assert_eq!(b.method, "boundary_mesh_with_global_derivative_bound");
    assert!(b.lower <= 5_f64.sqrt() && b.upper >= 5_f64.sqrt());
    assert!(b.upper <= 2.5 && b.mesh_points >= 64);
}

#[test]
fn mesh_values_alone_cannot_certify_bound_between_samples() {
    let angle = std::f64::consts::PI / 64.;
    let terms = [t(0, 0, 1.), t(1, 0, angle.cos()), t(0, 1, angle.sin())];
    let r = recover(&terms, 0., 1.9999, &[]).unwrap();
    assert_eq!(r.status, "bound_exceeded");
    assert!(r.bound_evidence.unwrap().lower > 1.9999);
    assert!(r.queries.is_empty() && r.representation.is_none());
}

#[test]
fn exact_bound_without_numerical_headroom_is_unresolved() {
    let r = recover(&[t(1, 0, 1.)], 0., 1., &[]).unwrap();
    assert_eq!(r.status, "numerically_unresolved");
    assert!(r.representation.is_none());
}

#[test]
fn ordering_and_explicit_zero_terms_do_not_change_recovered_values() {
    let mut terms = mixed();
    let before = recover(&terms, 0., 2., &[[0.2, 0.1]]).unwrap();
    terms.reverse();
    terms.push(t(3, 0, 0.));
    let after = recover(&terms, 0., 2., &[[0.2, 0.1]]).unwrap();
    assert_eq!(before.status, "bounded_holomorphic");
    assert_eq!(after.status, "bounded_holomorphic");
    assert_eq!(before.queries[0].value, after.queries[0].value);
}

#[test]
fn invalid_terms_and_query_contract_are_refused() {
    for (terms, needle) in [
        (vec![], "1..561"),
        (vec![t(0, 0, 1.), t(0, 0, 2.)], "duplicate"),
        (vec![t(33, 0, 0.)], "32"),
        (vec![t(0, 0, f64::NAN)], "finite"),
    ] {
        assert!(recover(&terms, 0., 1., &[]).unwrap_err().contains(needle));
    }
    assert!(recover(&[t(0, 0, 0.)], 0., 0., &[])
        .unwrap_err()
        .contains("bound"));
    assert!(recover(&[t(0, 0, 0.)], f64::INFINITY, 1., &[])
        .unwrap_err()
        .contains("center"));
    assert!(recover(&[t(0, 0, 0.)], 0., 1., &[[1., 0.]])
        .unwrap_err()
        .contains("query"));
    assert!(recover(&[t(0, 0, 0.)], 0., 1., &[[0., 0.]; 257])
        .unwrap_err()
        .contains("256"));
}

#[test]
fn zero_polynomial_and_unsafe_scale_are_explicit() {
    let zero = recover(&[t(0, 0, 0.)], 0., 0.1, &[[0.2, 0.3]]).unwrap();
    assert_eq!(zero.status, "bounded_holomorphic");
    assert_eq!(zero.queries[0].value, [0., 0.]);
    let huge = recover(&[t(32, 0, 1e308)], 0., 1e308, &[]).unwrap();
    assert_eq!(huge.status, "numerically_unresolved");
    assert!(huge.representation.is_none());
}
