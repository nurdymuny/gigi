//! Recovery of a bounded harmonic pair from real polynomial coefficients.
use super::holomorphic::Point;
use nalgebra::Complex;
use serde::Serialize;
type C = Complex<f64>;
const MAX_DEGREE: usize = 32;
fn point(z: C) -> Point {
    [z.re, z.im]
}
fn finite(z: C) -> bool {
    z.re.is_finite() && z.im.is_finite()
}

fn jet(coefficients: &[Point], z: C) -> (C, C, C) {
    let (mut value, mut first, mut second) = (C::new(0., 0.), C::new(0., 0.), C::new(0., 0.));
    for a in coefficients.iter().rev() {
        super::analytic_work::record(|w| w.recurrence_steps += 1);
        second = second * z + first * 2.;
        first = first * z + value;
        value = value * z + C::new(a[0], a[1]);
    }
    (value, first, second)
}

#[derive(Debug, Clone, Copy, Serialize)]
pub struct RealTerm {
    pub x_power: usize,
    pub y_power: usize,
    pub coefficient: f64,
}

#[derive(Debug, Clone, Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Polynomial {
    pub coefficients: Vec<Point>,
    pub bound: f64,
    pub conjugate_at_center: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct Evaluation {
    pub z: Point,
    pub value: Point,
    pub first_derivative: Point,
    pub second_derivative: Point,
}

impl Polynomial {
    pub fn evaluate(&self, z: Point) -> Option<Evaluation> {
        let coordinate = C::new(z[0], z[1]);
        if !finite(coordinate)
            || coordinate.norm() > 1. - 1e-8
            || self.coefficients.is_empty()
            || self.coefficients.len() > 33
        {
            return None;
        }
        let (value, first, second) = jet(&self.coefficients, coordinate);
        (finite(value) && finite(first) && finite(second)).then(|| Evaluation {
            z,
            value: point(value),
            first_derivative: point(first),
            second_derivative: point(second),
        })
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct BoundEvidence {
    pub lower: f64,
    pub upper: f64,
    pub allowance: f64,
    pub mesh_points: usize,
    pub method: &'static str,
}

#[derive(Debug, Clone, Serialize)]
pub struct Recovery {
    pub status: &'static str,
    pub reason: String,
    pub harmonic_residual: Option<f64>,
    pub reconstruction_residual: Option<f64>,
    pub bound_evidence: Option<BoundEvidence>,
    pub representation: Option<Polynomial>,
    pub queries: Vec<Evaluation>,
    pub notes: Vec<String>,
}

pub fn recover(
    terms: &[RealTerm],
    conjugate_at_center: f64,
    bound: f64,
    queries: &[Point],
) -> Result<Recovery, String> {
    super::analytic_work::record(|w| w.preparations += 1);
    if terms.is_empty() || terms.len() > 561 {
        return Err("provide 1..561 real polynomial terms; omitted monomials mean zero, not missing observations".into());
    }
    if !bound.is_finite() || bound <= 0. {
        return Err("bound must be finite and positive".into());
    }
    if !conjugate_at_center.is_finite() {
        return Err(
            "conjugate_at_center must be finite; specify the imaginary normalization".into(),
        );
    }
    if queries.len() > 256 {
        return Err("provide at most 256 queries".into());
    }
    for (i, z) in queries.iter().enumerate() {
        let z = C::new(z[0], z[1]);
        if !finite(z) || z.norm() > 1. - 1e-8 {
            return Err(format!(
                "query {i} must be finite and have modulus <=1-1e-8"
            ));
        }
    }
    let mut input = [[0.; 33]; 33];
    let mut seen = [[false; 33]; 33];
    let mut degree = 0;
    for term in terms {
        let (x, y) = (term.x_power, term.y_power);
        if x > MAX_DEGREE || y > MAX_DEGREE || x + y > MAX_DEGREE {
            return Err("real polynomial total degree must be <=32; provide a lower-degree explicitly represented field".into());
        }
        if !term.coefficient.is_finite() {
            return Err("every coefficient must be finite; no imputation is performed".into());
        }
        if seen[x][y] {
            return Err(format!("duplicate monomial powers ({x},{y}); provide one explicit coefficient per monomial"));
        }
        seen[x][y] = true;
        input[x][y] = term.coefficient;
        if term.coefficient != 0. {
            degree = degree.max(x + y);
        }
    }
    let mut result=Recovery {
        status:"numerically_unresolved", reason:"unsafe arithmetic or unresolved bound; use higher precision or a justified bound with numerical headroom".into(),
        harmonic_residual:None, reconstruction_residual:None, bound_evidence:None,
        representation:None, queries:vec![], notes:vec![
            "floating_point_not_formal_proof; no directed-rounding certificate".into(),
            "Complete real polynomial input; omitted monomials mean zero, not missing observations".into(),
            "One holomorphic polynomial contains both bounded harmonic components; imaginary value at center fixes the conjugate constant".into(),
            "No inference that the physical source is harmonic, no noisy-data projection, no arbitrary-manifold gluing".into(),
        ],
    };
    let mut coefficients = vec![[input[0][0], conjugate_at_center]];
    for n in 1..=degree {
        coefficients.push([input[n][0], -input[n - 1][1] / n as f64]);
    }
    let mut expected = [[0.; 33]; 33];
    for (n, a) in coefficients.iter().enumerate() {
        // Exact integer binomial coefficients through degree 32; no fitted basis.
        let mut choose = 1u64;
        for q in 0..=n {
            let component = match q % 4 {
                0 => a[0],
                1 => -a[1],
                2 => -a[0],
                _ => a[1],
            };
            expected[n - q][q] = component * choose as f64;
            if q < n {
                choose = choose * (n - q) as u64 / (q + 1) as u64;
            }
        }
    }
    let mut laplacian = [[0.; 33]; 33];
    let (mut residual, mut norm, mut lap_scale) = (0., 0., 0.);
    for x in 0..=degree {
        for y in 0..=degree - x {
            residual += (input[x][y] - expected[x][y]).abs();
            norm += input[x][y].abs();
            if x >= 2 {
                let value = input[x][y] * (x * (x - 1)) as f64;
                laplacian[x - 2][y] += value;
                lap_scale += value.abs();
            }
            if y >= 2 {
                let value = input[x][y] * (y * (y - 1)) as f64;
                laplacian[x][y - 2] += value;
                lap_scale += value.abs();
            }
        }
    }
    let lap_norm: f64 = laplacian.iter().flatten().map(|v| v.abs()).sum();
    if !residual.is_finite() || !norm.is_finite() || !lap_scale.is_finite() || !lap_norm.is_finite()
    {
        return Ok(result);
    }
    result.harmonic_residual = Some(lap_norm / lap_scale.max(1.));
    result.reconstruction_residual = Some(residual);
    if residual != 0. {
        if residual > 1e-12 * norm.max(1.) {
            result.status = "non_harmonic";
            result.reason="real coefficients cannot form a harmonic pair; correct the polynomial, no projection or coefficients are discarded".into();
        } else {
            result.reason="nonzero coefficient mismatch near numerical precision; use higher precision, no harmonic projection is performed".into();
        }
        return Ok(result);
    }
    let Some(evidence) = validate_bound(&coefficients, bound) else { return Ok(result); };
    let accepted = evidence.upper <= bound;
    if evidence.lower > bound {
        result.status = "bound_exceeded";
        result.reason="the recovered complex function exceeds the requested bound; justify a different bound or imaginary normalization, no clipping is performed".into();
    }
    result.bound_evidence = Some(evidence);
    if !accepted { return Ok(result); }
    let representation = Polynomial { coefficients, bound, conjugate_at_center };
    let Some(values) = queries.iter().map(|&z| representation.evaluate(z)).collect::<Option<Vec<_>>>() else { return Ok(result); };
    result.status = "bounded_holomorphic";
    result.reason="real polynomial and recovered conjugate share one holomorphic representation with a numerical domain-wide magnitude bound".into();
    result.representation = Some(representation);
    result.queries = values;
    Ok(result)
}

pub(crate) fn validate_bound(coefficients: &[Point], bound: f64) -> Option<BoundEvidence> {
    if coefficients.is_empty() || coefficients.len() > 33 || !bound.is_finite() || bound <= 0.
        || coefficients.iter().flatten().any(|v| !v.is_finite()) { return None; }
    let degree = coefficients.len() - 1;
    let l1: f64 = coefficients.iter().map(|a| C::new(a[0], a[1]).norm()).sum();
    let lipschitz: f64 = coefficients
        .iter()
        .enumerate()
        .map(|(n, a)| n as f64 * C::new(a[0], a[1]).norm())
        .sum();
    let allowance = 128. * f64::EPSILON * (degree + 1) as f64 * l1.max(1.);
    let triangle = l1 + allowance;
    if !triangle.is_finite() || !lipschitz.is_finite() {
        return None;
    }
    let coefficient_lower = coefficients
        .iter()
        .map(|a| C::new(a[0], a[1]).norm())
        .fold(0., f64::max);
    let mut evidence = BoundEvidence {
        lower: (coefficient_lower - allowance).max(0.),
        upper: triangle,
        allowance,
        mesh_points: 0,
        method: "coefficient_triangle_bound",
    };
    if evidence.lower <= bound && evidence.upper > bound {
        for n in (6..=16).map(|power| 1usize << power) {
            let mut sample_max = 0f64;
            for k in 0..n {
                let angle = std::f64::consts::TAU * k as f64 / n as f64;
                let value = jet(&coefficients, C::new(angle.cos(), angle.sin())).0;
                if !finite(value) {
                    return None;
                }
                sample_max = sample_max.max(value.norm());
            }
            // Every boundary point is at angular distance <= pi/n from a node.
            let correction = std::f64::consts::PI * lipschitz / n as f64;
            evidence = BoundEvidence {
                lower: (sample_max.max(coefficient_lower) - allowance).max(0.),
                upper: triangle.min(sample_max + correction + allowance),
                allowance,
                mesh_points: n,
                method: "boundary_mesh_with_global_derivative_bound",
            };
            if evidence.lower > bound || evidence.upper <= bound {
                break;
            }
        }
    }
    Some(evidence)
}
