#![cfg(feature = "kahler")]
use gigi::geometry::holomorphic::{complete, Observation};

fn obs(z: [f64; 2], value: [f64; 2]) -> Observation {
    Observation { z, value }
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() < 1e-9, "{a} != {b}");
}

#[test]
fn identity_is_unique_by_schwarz_equality() {
    let r = complete(
        &[obs([0., 0.], [0., 0.]), obs([0.5, 0.], [0.5, 0.])],
        1.,
        &[[0.2, 0.3]],
    )
    .unwrap();
    assert_eq!(r.status, "feasible_unique");
    close(r.queries[0].representative[0], 0.2);
    close(r.queries[0].representative[1], 0.3);
    close(r.queries[0].radius, 0.);
}

#[test]
fn bounded_individual_values_can_be_jointly_impossible() {
    let r = complete(
        &[obs([0., 0.], [0., 0.]), obs([0.5, 0.], [0.9, 0.])],
        1.,
        &[[0.2, 0.]],
    )
    .unwrap();
    assert_eq!(r.status, "infeasible");
    assert!(r.queries.is_empty() && r.representation.is_none());
    assert!(r.min_pick_eigenvalue.unwrap() < 0.);
}

#[test]
fn single_zero_has_exact_schwarz_disk_not_unconstrained_bound() {
    let r = complete(&[obs([0., 0.], [0., 0.])], 2., &[[0.3, 0.4]]).unwrap();
    assert_eq!(r.status, "feasible_family");
    close(r.queries[0].radius, 1.);
    assert_eq!(r.queries[0].center, [0., 0.]);
}

#[test]
fn conjugation_is_harmonic_but_not_holomorphic() {
    let r = complete(
        &[
            obs([0., 0.], [0., 0.]),
            obs([0.5, 0.], [0.5, 0.]),
            obs([0., 0.5], [0., -0.5]),
        ],
        1.,
        &[],
    )
    .unwrap();
    assert_eq!(r.status, "infeasible");
}

#[test]
fn constant_unit_value_forces_constant_function() {
    let r = complete(&[obs([0.2, 0.3], [0., 3.])], 3., &[[0.8, 0.1]]).unwrap();
    assert_eq!(r.status, "feasible_unique");
    assert_eq!(r.queries[0].representative, [0., 3.]);
}

#[test]
fn conflicting_duplicates_are_not_averaged() {
    let r = complete(
        &[obs([0., 0.], [0.1, 0.]), obs([0., 0.], [0.2, 0.])],
        1.,
        &[],
    )
    .unwrap();
    assert_eq!(r.status, "infeasible");
    assert!(r.reason.contains("duplicate"));
}

#[test]
fn near_boundary_is_unresolved_not_rounded_to_unique() {
    let r = complete(&[obs([0., 0.], [1. - 1e-12, 0.])], 1., &[]).unwrap();
    assert_eq!(r.status, "numerically_unresolved");
}

#[test]
fn input_contract_refuses_without_silently_cleaning() {
    let o = [obs([0., 0.], [0., 0.])];
    assert!(complete(&o, 0., &[]).unwrap_err().contains("bound"));
    assert!(complete(&o, 1., &[[1., 0.]]).unwrap_err().contains("query"));
    assert!(complete(&[obs([0., 0.], [f64::NAN, 0.])], 1., &[])
        .unwrap_err()
        .contains("finite"));
    assert!(complete(&[], 1., &[]).unwrap_err().contains("observation"));
}

#[test]
fn bounded_polynomial_is_contained_and_representation_interpolates() {
    use nalgebra::Complex;
    let f = |z: [f64; 2]| {
        let z = Complex::new(z[0], z[1]);
        let w = (z * z + z) * 0.3 + Complex::new(0.1, 0.);
        [w.re, w.im]
    };
    let nodes = [[0., 0.], [0.5, 0.], [0., 0.5], [-0.3, 0.1]];
    let observations: Vec<_> = nodes.iter().map(|&z| obs(z, f(z))).collect();
    let queries = [[0.1, 0.2], [0.7, -0.2], [-0.4, -0.5]];
    let r = complete(&observations, 1., &queries).unwrap();
    assert_eq!(r.status, "feasible_family");
    let model = r.representation.unwrap();
    for o in &observations {
        let w = model.evaluate(o.z).unwrap();
        close(w[0], o.value[0]);
        close(w[1], o.value[1]);
    }
    for q in r.queries {
        let truth = f(q.z);
        assert!((truth[0] - q.center[0]).hypot(truth[1] - q.center[1]) <= q.radius + 1e-9);
        assert!(q.radius < 0.5);
    }
    for k in 0..64 {
        let angle = k as f64 * std::f64::consts::TAU / 64.;
        let w = model
            .evaluate([0.99 * angle.cos(), 0.99 * angle.sin()])
            .unwrap();
        assert!(w[0].hypot(w[1]) <= 1. + 1e-10);
    }
    let mut reverse = observations.clone();
    reverse.reverse();
    let r2 = complete(&reverse, 1., &queries).unwrap();
    assert_eq!(
        serde_json::to_value(&model).unwrap(),
        serde_json::to_value(r2.representation.unwrap()).unwrap()
    );
}

#[test]
fn complex_rotated_identity_and_actual_cauchy_riemann_derivatives() {
    let r = complete(
        &[obs([0., 0.], [0., 0.]), obs([0.5, 0.], [0., 0.5])],
        1.,
        &[],
    )
    .unwrap();
    assert_eq!(r.status, "feasible_unique");
    let model = r.representation.unwrap();
    let h = 1e-5;
    let xp = model.evaluate([0.2 + h, 0.3]).unwrap();
    let xm = model.evaluate([0.2 - h, 0.3]).unwrap();
    let yp = model.evaluate([0.2, 0.3 + h]).unwrap();
    let ym = model.evaluate([0.2, 0.3 - h]).unwrap();
    close((xp[0] - xm[0]) / (2. * h), (yp[1] - ym[1]) / (2. * h));
    close((xp[1] - xm[1]) / (2. * h), -(yp[0] - ym[0]) / (2. * h));
}

#[test]
fn nonzero_observation_has_shifted_pick_disk() {
    let r = complete(&[obs([0., 0.], [0.5, 0.])], 1., &[[0.5, 0.], [0., 0.]]).unwrap();
    assert_eq!(r.status, "feasible_family");
    close(r.queries[0].center[0], 0.4);
    close(r.queries[0].radius, 0.4);
    close(r.queries[0].representative[0], 0.5);
    close(r.queries[1].radius, 0.);
}

#[test]
fn duplicate_equal_nodes_and_resource_limits_are_explicit() {
    let r = complete(&[obs([0., 0.], [0., 0.]); 2], 1., &[[0.5, 0.]]).unwrap();
    assert_eq!(r.status, "feasible_family");
    close(r.queries[0].radius, 0.5);
    assert!(complete(&[obs([0., 0.], [0., 0.]); 65], 1., &[])
        .unwrap_err()
        .contains("64"));
    assert!(complete(&[obs([0., 0.], [0., 0.])], 1., &[[0., 0.]; 257])
        .unwrap_err()
        .contains("256"));
    let near = complete(
        &[obs([0., 0.], [0., 0.]), obs([1e-9, 0.], [0., 0.])],
        1.,
        &[],
    )
    .unwrap();
    assert_eq!(near.status, "numerically_unresolved");
}

#[test]
fn rounded_unit_norm_does_not_prove_uniqueness() {
    let r = complete(&[obs([0., 0.], [0.6, 0.8])], 1., &[]).unwrap();
    assert_eq!(r.status, "numerically_unresolved");
}
