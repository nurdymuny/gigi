#![cfg(feature = "kahler")]
use gigi::analytic_objects::{coordinator::Coordinator, prepared::Prepared, registry::*};
use std::{
    sync::{
        atomic::{AtomicUsize, Ordering},
        mpsc, Arc, Barrier,
    },
    thread,
    time::{Duration, Instant},
};

fn request() -> BuildRequest {
    BuildRequest {
        object_id: None,
        expected_head: None,
        sources: vec![SourceSnapshot {
            name: "immutable_fixture".into(),
            source: SourceRevision {
                bundle_id: "4bbd50a4-f478-42d1-a19e-d27601834bb4".into(),
                incarnation: "21cc3633-e53f-4649-aed5-d77c0ee482a4".into(),
                revision: 7,
                schema_digest: [1; 32],
            },
            content_digest: [2; 32],
            records: 3,
        }],
        coordinates: Coordinates {
            input_units: "dimensionless".into(),
            output_units: "frequency".into(),
            meaning: "generating function".into(),
            chart: "unit_disk".into(),
            regime: "fixture".into(),
            normalization: "1/N".into(),
        },
        recipe: serde_json::json!({"kind":"fixed_histogram"}),
        numerical_policy: POLICY.into(),
    }
}
fn current(r: &BuildRequest) -> Vec<SourceRevision> {
    r.sources.iter().map(|s| s.source.clone()).collect()
}
fn model() -> Result<Prepared, String> {
    Prepared::histogram(&[2, 1], 1.01)
}
fn wait_for_waiter(c: &Coordinator) -> bool {
    let deadline = Instant::now() + Duration::from_secs(3);
    while Instant::now() < deadline {
        if c.usage().1 > 0 {
            return true;
        }
        thread::sleep(Duration::from_millis(2));
    }
    false
}

#[test]
fn thirty_two_simultaneous_requests_share_one_build_and_durable_receipt() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("log");
    let c = Arc::new(Coordinator::new(Registry::open(&path, 1024 * 1024).unwrap(), 4).unwrap());
    let starts = Arc::new(Barrier::new(32));
    let builds = Arc::new(AtomicUsize::new(0));
    let threads: Vec<_> = (0..32)
        .map(|_| {
            let (c, starts, builds) = (c.clone(), starts.clone(), builds.clone());
            thread::spawn(move || {
                let r = request();
                starts.wait();
                c.prepare(
                    "bee",
                    "one",
                    &r,
                    || Ok(current(&r)),
                    || {
                        builds.fetch_add(1, Ordering::SeqCst);
                        thread::sleep(Duration::from_millis(50));
                        model()
                    },
                )
            })
        })
        .collect();
    let results: Vec<_> = threads.into_iter().map(|t| t.join().unwrap()).collect();
    assert!(results.iter().all(Result::is_ok), "{results:?}");
    assert_eq!(builds.load(Ordering::SeqCst), 1);
    let first = results[0].as_ref().unwrap();
    for result in &results {
        let m = result.as_ref().unwrap();
        assert_eq!(m.object_id, first.object_id);
        assert_eq!(m.version_id, first.version_id);
    }
    assert_eq!(c.usage(), (0, 0));
    drop(c);
    let mut recovered = Registry::open(&path, 1024 * 1024).unwrap();
    let r = request();
    let retry = recovered
        .prepare(
            "bee",
            "one",
            &r,
            || Err::<Vec<SourceRevision>, _>("offline".into()),
            || panic!("durable retry rebuilt"),
        )
        .unwrap();
    assert_eq!(retry.version_id, first.version_id);
}

#[test]
fn different_keys_build_concurrently_without_holding_the_registry_lock() {
    let tmp = tempfile::tempdir().unwrap();
    let c = Arc::new(
        Coordinator::new(
            Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap(),
            2,
        )
        .unwrap(),
    );
    let (started, events) = mpsc::channel();
    let mut releases = vec![];
    let mut threads = vec![];
    for key in ["one", "two"] {
        let (c, started) = (c.clone(), started.clone());
        let (tx, rx) = mpsc::channel();
        releases.push(tx);
        threads.push(thread::spawn(move || {
            let r = request();
            c.prepare(
                "bee",
                key,
                &r,
                || Ok(current(&r)),
                || {
                    started.send(key).unwrap();
                    rx.recv_timeout(Duration::from_secs(5))
                        .map_err(|_| "registry held across independent build".to_string())?;
                    model()
                },
            )
        }));
    }
    let first = events.recv_timeout(Duration::from_secs(3));
    let second = events.recv_timeout(Duration::from_secs(3));
    for release in releases {
        let _ = release.send(());
    }
    let results: Vec<_> = threads.into_iter().map(|t| t.join().unwrap()).collect();
    assert!(
        first.is_ok() && second.is_ok(),
        "both builders must enter before either is released"
    );
    assert!(results.iter().all(Result::is_ok), "{results:?}");
    assert_eq!(c.usage(), (0, 0));
}

#[test]
fn failed_and_panicking_builders_release_waiters_and_allow_a_clean_retry() {
    for panic in [false, true] {
        let tmp = tempfile::tempdir().unwrap();
        let c = Arc::new(
            Coordinator::new(
                Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap(),
                1,
            )
            .unwrap(),
        );
        let (started, entered) = mpsc::channel();
        let (release, resume) = mpsc::channel();
        let leader_c = c.clone();
        let leader = thread::spawn(move || {
            let r = request();
            leader_c.prepare(
                "bee",
                "one",
                &r,
                || Ok(current(&r)),
                || {
                    started.send(()).unwrap();
                    resume
                        .recv_timeout(Duration::from_secs(5))
                        .map_err(|_| "release timeout".to_string())?;
                    if panic {
                        panic!("injected builder cancellation");
                    }
                    Err("injected failure".into())
                },
            )
        });
        let entered = entered.recv_timeout(Duration::from_secs(3)).is_ok();
        let follower_c = c.clone();
        let follower = thread::spawn(move || {
            let r = request();
            follower_c.prepare(
                "bee",
                "one",
                &r,
                || Ok(current(&r)),
                || panic!("waiter must not build"),
            )
        });
        let joined = wait_for_waiter(&c);
        let _ = release.send(());
        let a = leader.join().unwrap();
        let b = follower.join().unwrap();
        assert!(entered && joined, "waiter did not join a live flight");
        let expected = if panic {
            "builder_panicked"
        } else {
            "injected failure"
        };
        assert!(a.unwrap_err().contains(expected));
        assert!(b.unwrap_err().contains(expected));
        assert_eq!(c.usage(), (0, 0));
        let r = request();
        assert!(c
            .prepare("bee", "one", &r, || Ok(current(&r)), model)
            .is_ok());
    }
}

#[test]
fn active_flights_enforce_request_binding_and_capacity_without_rebuilding() {
    let tmp = tempfile::tempdir().unwrap();
    let c = Arc::new(
        Coordinator::new(
            Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap(),
            1,
        )
        .unwrap(),
    );
    let (started, entered) = mpsc::channel();
    let (release, resume) = mpsc::channel();
    let other = c.clone();
    let leader = thread::spawn(move || {
        let r = request();
        other.prepare(
            "bee",
            "one",
            &r,
            || Ok(current(&r)),
            || {
                started.send(()).unwrap();
                resume
                    .recv_timeout(Duration::from_secs(5))
                    .map_err(|_| "release timeout".to_string())?;
                model()
            },
        )
    });
    let entered = entered.recv_timeout(Duration::from_secs(3)).is_ok();
    let mut wrong = request();
    wrong.recipe["different"] = true.into();
    let conflict = c.prepare(
        "bee",
        "one",
        &wrong,
        || Ok(current(&wrong)),
        || panic!("conflict built"),
    );
    let r = request();
    let busy = c.prepare(
        "bee",
        "two",
        &r,
        || Ok(current(&r)),
        || panic!("capacity overflow built"),
    );
    let _ = release.send(());
    let result = leader.join().unwrap();
    assert!(entered);
    assert!(conflict.unwrap_err().contains("idempotency_conflict"));
    assert!(busy.unwrap_err().contains("resource_limit"));
    assert!(result.is_ok());
    assert_eq!(c.usage(), (0, 0));
}
