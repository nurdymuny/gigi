#![cfg(feature = "kahler")]
use gigi::geometry::passive_network::*;
use std::collections::BTreeMap;

fn node(id: &str, c: f64, v: f64) -> Node {
    Node {
        id: id.into(),
        capacitance_f: c,
        voltage_v: v,
    }
}
fn link(g: f64) -> Configuration {
    Configuration {
        edges: vec![Edge {
            source: "a".into(),
            target: "b".into(),
            conductance_s: g,
        }],
        ports: vec![],
    }
}
fn port(u: f64) -> Configuration {
    Configuration {
        edges: vec![],
        ports: vec![Port {
            node: "a".into(),
            conductance_s: 1.,
            voltage_v: u,
        }],
    }
}
fn phase(duration_s: f64, configuration: Configuration) -> Phase {
    Phase {
        duration_s,
        configuration,
    }
}
fn weights(a: f64, b: f64) -> BTreeMap<String, f64> {
    BTreeMap::from([("a".into(), a), ("b".into(), b)])
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() <= 1e-10 * b.abs().max(1e-12), "{a} != {b}");
}

#[test]
fn two_store_oracle_charge_energy_and_current() {
    let r = conduct(
        &[node("a", 1., 3.), node("b", 1., 1.)],
        &[phase(2., link(2.))],
        &[0., 0.1, 0.7, 2.],
    )
    .unwrap();
    close(r.initial_stored_j, 5.);
    close(r.samples[0].edge_currents_a[0], 4.);
    close(r.samples[0].dissipated_w, 8.);
    for s in r.samples {
        let e = (-4. * s.time_s).exp();
        close(s.voltages_v[0], 2. + e);
        close(s.voltages_v[1], 2. - e);
        close(s.voltages_v.iter().sum(), 4.);
        close(s.stored_j, 4. + e * e);
        if s.time_s > 0. {
            close(s.dissipated_j, 1. - e * e);
        }
        assert!(s.balance_residual_j.abs() < 1e-12);
    }
}
#[test]
fn source_power_includes_port_loss() {
    let r = conduct(
        &[node("a", 1., 0.)],
        &[phase(2., port(1.))],
        &[0., 0.1, 1., 2.],
    )
    .unwrap();
    for s in r.samples {
        let e = (-s.time_s).exp();
        if s.time_s > 0. {
            close(s.voltages_v[0], 1. - e);
            close(s.supplied_j, 1. - e);
            close(s.dissipated_j, (1. - e * e) / 2.);
        }
        close(s.dissipated_w, e * e);
        close(s.supplied_w, e);
        assert!(s.balance_residual_j.abs() < 1e-12);
    }
}
#[test]
fn switches_are_exact_not_rounded_to_output_grid() {
    let r = conduct(
        &[node("a", 1., 3.), node("b", 1., 1.)],
        &[
            phase(0.137, link(0.)),
            phase(0.222, link(2.)),
            phase(1., link(0.)),
        ],
        &[0.1, 0.137, 0.2, 0.359, 1.],
    )
    .unwrap();
    close(r.samples[1].voltages_v[0], 3.);
    close(
        r.samples[2].voltages_v[0],
        2. + (-4_f64 * (0.2 - 0.137)).exp(),
    );
    close(r.samples[4].voltages_v[0], 2. + (-4_f64 * 0.222).exp());
    close(r.samples[4].dissipated_j, r.samples[3].dissipated_j);
    assert_eq!(r.samples[1].phase_index, 0);
    close(r.samples[4].edge_currents_a[0], 0.);
}
#[test]
fn unequal_storage_and_disconnected_equilibria() {
    let ns = [node("a", 2., 3.), node("b", 1., 0.), node("c", 4., 7.)];
    let s = settle(&ns, &link(2.), &weights(1., -1.), 0.1, 2.).unwrap();
    close(s.equilibrium_v[0], 2.);
    close(s.equilibrium_v[1], 2.);
    close(s.equilibrium_v[2], 7.);
    close(s.settling_bound_s, 30_f64.ln() / 3.);
}
#[test]
fn settling_bound_and_deadline_have_fixed_answers() {
    let ns = [node("a", 1., 3.), node("b", 1., 1.)];
    let s = settle(&ns, &link(2.), &weights(1., -1.), 0.1, 0.7).unwrap();
    close(s.settling_bound_s, 20_f64.ln() / 4.);
    assert!(!s.meets_deadline);
    assert!(
        settle(&ns, &link(2.), &weights(1., -1.), 0.1, 0.8)
            .unwrap()
            .meets_deadline
    );
    close(s.envelope_at_deadline_v, 2. * (-2.8_f64).exp());
}
#[test]
fn crossing_is_not_settling() {
    let ns = [node("a", 1., 1.), node("b", 1., -1.)];
    let cfg = Configuration {
        edges: vec![],
        ports: vec![
            Port {
                node: "a".into(),
                conductance_s: 1.,
                voltage_v: 0.,
            },
            Port {
                node: "b".into(),
                conductance_s: 2.,
                voltage_v: 0.,
            },
        ],
    };
    let s = settle(&ns, &cfg, &weights(1., 1.), 0.01, 0.).unwrap();
    close(s.readout_equilibrium_v, 0.);
    close(s.envelope_initial_v, 2.);
    assert!(!s.meets_deadline);
    assert!(s.settling_bound_s > 4.6);
    let mid = conduct(&ns, &[phase(1., cfg)], &[0., 0.5]).unwrap();
    assert!(mid.samples[0].voltages_v.iter().sum::<f64>().abs() < 1e-12);
    assert!(mid.samples[1].voltages_v.iter().sum::<f64>() > 0.2);
}
#[test]
fn open_network_is_already_at_its_own_equilibrium() {
    let s = settle(
        &[node("a", 1., 3.), node("b", 1., 1.)],
        &link(0.),
        &weights(1., -1.),
        0.01,
        0.,
    )
    .unwrap();
    close(s.readout_equilibrium_v, 2.);
    close(s.settling_bound_s, 0.);
    assert!(s.meets_deadline);
}
#[test]
fn source_can_absorb_energy() {
    let r = conduct(&[node("a", 1., 3.)], &[phase(1., port(1.))], &[1.]).unwrap();
    let s = &r.samples[0];
    assert!(s.supplied_j < 0.);
    close(s.supplied_j, -2. * (1. - (-1_f64).exp()));
    close(s.dissipated_j, 2. * (1. - (-2_f64).exp()));
    assert!(s.balance_residual_j.abs() < 1e-12);
}
#[test]
fn permutation_invariance() {
    let a = conduct(
        &[node("a", 2., 3.), node("b", 1., 0.)],
        &[phase(1., link(2.))],
        &[1.],
    )
    .unwrap();
    let b = conduct(
        &[node("b", 1., 0.), node("a", 2., 3.)],
        &[phase(1., link(2.))],
        &[1.],
    )
    .unwrap();
    assert_eq!(a.node_order, b.node_order);
    close(a.samples[0].voltages_v[0], b.samples[0].voltages_v[0]);
}
#[test]
fn refuses_invalid_physical_inputs_and_times() {
    let ns = [node("a", 1., 3.), node("b", 1., 1.)];
    for c in [0., -1., f64::NAN, f64::INFINITY] {
        assert!(conduct(&[node("a", c, 0.)], &[phase(1., port(1.))], &[1.]).is_err());
    }
    assert!(conduct(&ns, &[phase(1., link(-1.))], &[1.]).is_err());
    assert!(conduct(&ns, &[phase(1., link(1.))], &[0.5, 0.5]).is_err());
    assert!(conduct(&ns, &[phase(1., link(1.))], &[2.]).is_err());
    assert!(conduct(
        &[node("a", 1., 0.), node("a", 1., 1.)],
        &[phase(1., port(1.))],
        &[1.]
    )
    .is_err());
    assert!(conduct(&[node("a", 1., 0.)], &[phase(1., link(1.))], &[1.]).is_err());
    assert!(settle(&ns, &link(1.), &weights(1., 0.), 0., 1.).is_err());
}
#[test]
fn tiny_positive_mode_is_not_declared_conserved() {
    let ns = [node("a", 1., 1.), node("b", 1., 1.)];
    let cfg = Configuration {
        edges: vec![],
        ports: vec![
            Port {
                node: "a".into(),
                conductance_s: 1.,
                voltage_v: 0.,
            },
            Port {
                node: "b".into(),
                conductance_s: 1e-15,
                voltage_v: 0.,
            },
        ],
    };
    assert!(settle(&ns, &cfg, &weights(0., 1.), 0.1, 1.)
        .unwrap_err()
        .contains("unresolved"));
}
#[test]
fn strict_serialization_rejects_guessed_keys() {
    assert!(serde_json::from_str::<Port>(
        r#"{"node":"a","conductance_s":1,"voltage_v":1,"power":5}"#
    )
    .is_err());
}

#[test]
fn very_early_charging_does_not_lose_the_transient_to_cancellation() {
    let r = conduct(
        &[node("a", 1., 0.)],
        &[phase(1., port(1.))],
        &[1e-15, 1e-12, 1e-9],
    )
    .unwrap();
    for s in r.samples {
        let expected = -(-s.time_s).exp_m1();
        assert!(
            (s.voltages_v[0] / expected - 1.).abs() < 1e-10,
            "{} vs {}",
            s.voltages_v[0],
            expected
        );
    }
}

#[test]
fn picofarad_energy_uses_a_relative_not_one_joule_gate() {
    let mut cfg = port(1.);
    cfg.ports[0].conductance_s = 1e-6;
    let r = conduct(&[node("a", 1e-12, 0.)], &[phase(1e-5, cfg)], &[1e-6, 1e-5]).unwrap();
    for s in r.samples {
        let e = (-s.time_s / 1e-6).exp();
        let expected = 0.5e-12 * (1. - e).powi(2);
        assert!((s.stored_j / expected - 1.).abs() < 1e-10);
        assert!(s.balance_residual_j.abs() < 1e-22);
    }
}

#[test]
fn conductance_refusal_names_the_actual_requirement() {
    let error = conduct(
        &[node("a", 1., 3.), node("b", 1., 1.)],
        &[phase(1., link(-1.))],
        &[1.],
    )
    .unwrap_err();
    assert!(error.contains("conductance_s") && error.contains("finite value"));
}

#[test]
fn time_and_capacitance_scaling_preserve_the_trajectory() {
    let ns = [node("a", 2., 3.), node("b", 1., 0.)];
    let scaled = [node("a", 2e-6, 3.), node("b", 1e-6, 0.)];
    let first = conduct(&ns, &[phase(1., link(2.))], &[0.1, 1.]).unwrap();
    let second = conduct(&scaled, &[phase(1e-6, link(2.))], &[1e-7, 1e-6]).unwrap();
    for (a, b) in first.samples.iter().zip(&second.samples) {
        for (x, y) in a.voltages_v.iter().zip(&b.voltages_v) {
            close(*x, *y);
        }
        close(a.stored_j * 1e-6, b.stored_j);
        close(a.dissipated_j * 1e-6, b.dissipated_j);
    }
}

#[test]
fn resource_and_readout_limits_are_explicit() {
    let nodes: Vec<_> = (0..33).map(|i| node(&i.to_string(), 1., 0.)).collect();
    assert!(conduct(&nodes, &[phase(1., port(1.))], &[1.])
        .unwrap_err()
        .contains("1..32"));
    assert!(
        conduct(&[node("a", 1., 0.)], &vec![phase(1., port(1.)); 65], &[1.])
            .unwrap_err()
            .contains("1..64")
    );
    assert!(conduct(
        &[node("a", 1., 0.)],
        &[phase(1., port(1.))],
        &vec![0.; 2049]
    )
    .unwrap_err()
    .contains("2048"));
    assert!(settle(
        &[node("a", 1., 0.)],
        &port(1.),
        &BTreeMap::from([("unknown".into(), 1.)]),
        0.1,
        1.
    )
    .unwrap_err()
    .contains("unknown readout"));
    assert!(settle(
        &[node("a", 1., 0.)],
        &port(1.),
        &BTreeMap::from([("a".into(), 0.)]),
        0.1,
        1.
    )
    .unwrap_err()
    .contains("nonzero"));
}
