#![cfg(feature = "kahler")]

use gigi::geometry::{ClosedTwoForm, LineBundle, TwoForm};
use std::f64::consts::{PI, TAU};

fn form(b: f64) -> ClosedTwoForm {
    ClosedTwoForm::new_constant(TwoForm::new(vec![0.0, b, -b, 0.0], 2).unwrap())
}

#[test]
fn nonfinite_period_is_not_a_chern_measurement() {
    for value in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        let error = LineBundle::from_transition_data(value, 1e-10).unwrap_err();
        assert!(error.to_string().contains("g_alpha_beta"), "{error}");
    }
}

#[test]
fn tolerance_must_be_finite_nonnegative_and_below_half() {
    for value in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, -0.01, 0.5, 1.0] {
        let error = LineBundle::from_transition_data(TAU, value).unwrap_err();
        assert!(error.to_string().contains("tolerance"), "{error}");
    }
}

#[test]
fn unrepresentable_integer_is_refused_not_saturated() {
    for winding in [2.0_f64.powi(63), -2.0_f64.powi(64), 1e100] {
        let error = LineBundle::from_transition_data(TAU * winding, 0.0).unwrap_err();
        assert!(error.to_string().contains("winding"), "{error}");
    }
}

#[test]
fn constant_period_requires_positive_finite_area() {
    for value in [0.0, -0.0, -TAU, f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        let error = LineBundle::from_constant_two_form(&form(1.0), value, 1e-10)
            .unwrap_err();
        assert!(error.to_string().contains("loop_area"), "{error}");
    }
}

#[test]
fn nonfinite_coefficient_is_refused() {
    // Existing TwoForm accepts these; the period constructor must not trust it.
    for value in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        let error = LineBundle::from_constant_two_form(&form(value), 1.0, 1e-10)
            .unwrap_err();
        assert!(error.to_string().contains("coefficient"), "{error}");
    }
}

#[test]
fn finite_factors_with_overflowing_product_are_refused() {
    let error = LineBundle::from_constant_two_form(&form(1e200), 1e200, 1e-10)
        .unwrap_err();
    assert!(error.to_string().contains("g_alpha_beta"), "{error}");
}

#[test]
fn nonzero_period_must_not_underflow_to_zero_winding() {
    let error = LineBundle::from_transition_data(f64::from_bits(1), 0.0).unwrap_err();
    assert!(error.to_string().contains("g_alpha_beta"), "{error}");
}

#[test]
fn nonzero_constant_period_must_not_underflow_to_zero() {
    let error = LineBundle::from_constant_two_form(&form(1e-200), 1e-200, 0.0)
        .unwrap_err();
    assert!(error.to_string().contains("loop_area"), "{error}");
}

#[test]
fn signed_period_and_zero_are_preserved() {
    for integer in [-9, -3, -1, 0, 1, 3, 9] {
        let bundle = LineBundle::from_transition_data(TAU * integer as f64, 1e-12)
            .unwrap();
        assert_eq!(bundle.chern.0, integer);
        assert!((bundle.integral_value - integer as f64).abs() < 1e-12);
    }
}

#[test]
fn unique_nearest_integer_obeys_declared_tolerance() {
    let integral = TAU * 1.125;
    let measured = integral / TAU;
    let deviation = (measured - measured.round()).abs();
    assert_eq!(LineBundle::from_transition_data(integral, deviation).unwrap().chern.0, 1);
    assert!(LineBundle::from_transition_data(integral, deviation / 2.0).is_err());
    assert!(LineBundle::from_transition_data(PI, 0.499).is_err());
}

#[test]
fn valid_constant_period_preserves_orientation() {
    for (coefficient, expected) in [(-0.5, -1), (0.0, 0), (0.5, 1)] {
        let bundle = LineBundle::from_constant_two_form(&form(coefficient), 4.0 * PI, 1e-12)
            .unwrap();
        assert_eq!(bundle.chern.0, expected);
    }
}

#[test]
fn wu_yang_chart_difference_not_individual_loop_is_integer() {
    let north = PI;
    let south = -PI;
    assert!((north.cos() - south.cos()).abs() < 1e-14);
    assert!((north.sin() - south.sin()).abs() < 1e-14);
    assert!(LineBundle::from_transition_data(north, 1e-12).is_err());
    assert!(LineBundle::from_transition_data(south, 1e-12).is_err());
    assert_eq!(LineBundle::from_transition_data(north - south, 1e-12).unwrap().chern.0, 1);
    assert_eq!(LineBundle::from_transition_data(south - north, 1e-12).unwrap().chern.0, -1);
}
