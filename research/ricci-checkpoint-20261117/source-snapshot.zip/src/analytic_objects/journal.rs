//! Checksummed append-only transaction frames for the analytic registry.
use sha2::{Digest, Sha256};
use std::{
    fs::{File, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
    path::Path,
};

const MAGIC: &[u8; 8] = b"GGAOJ001";
const FRAME_HEADER: u64 = 48;
const MAX_FRAME: u64 = 2 * 1024 * 1024;

pub struct Journal {
    file: File,
    offsets: Vec<u64>,
    end: u64,
    quota: u64,
    healthy: bool,
}
impl Journal {
    pub fn open(path: &Path, quota: u64) -> io::Result<Self> {
        if quota < MAGIC.len() as u64 {
            return Err(io::Error::other("resource_limit: journal quota too small"));
        }
        let mut file = OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .open(path)?;
        file.try_lock()
            .map_err(|e| io::Error::other(format!("analytic journal is already open: {e}")))?;
        let mut end = file.metadata()?.len();
        if end > quota {
            return Err(io::Error::other(
                "resource_limit: existing journal exceeds quota",
            ));
        }
        if end == 0 {
            file.write_all(MAGIC)?;
            file.sync_all()?;
            end = MAGIC.len() as u64;
            #[cfg(unix)]
            File::open(path.parent().unwrap_or(Path::new(".")))?.sync_all()?;
        }
        let mut magic = [0u8; 8];
        file.seek(SeekFrom::Start(0))?;
        file.read_exact(&mut magic)?;
        if &magic != MAGIC {
            return Err(io::Error::other("unsupported_version: analytic journal"));
        }
        let mut log = Self {
            file,
            offsets: Vec::new(),
            end,
            quota,
            healthy: true,
        };
        let mut offset = MAGIC.len() as u64;
        while offset < end {
            if end - offset < FRAME_HEADER {
                break;
            }
            let length = log.frame_length(offset)?;
            if length > end - offset - FRAME_HEADER {
                break;
            }
            log.read_frame(offset, length)?;
            log.offsets.push(offset);
            offset += FRAME_HEADER + length;
        }
        if offset != end {
            log.file.set_len(offset)?;
            log.file.sync_all()?;
            log.end = offset;
        }
        Ok(log)
    }
    fn frame_length(&mut self, offset: u64) -> io::Result<u64> {
        self.file.seek(SeekFrom::Start(offset))?;
        let mut header = [0u8; 16];
        self.file.read_exact(&mut header)?;
        let length = u64::from_le_bytes(header[..8].try_into().unwrap());
        let inverse = u64::from_le_bytes(header[8..].try_into().unwrap());
        if length != !inverse || length == 0 || length > MAX_FRAME {
            return Err(io::Error::other(
                "corrupt_object: invalid analytic frame length",
            ));
        }
        Ok(length)
    }
    fn read_frame(&mut self, offset: u64, length: u64) -> io::Result<Vec<u8>> {
        self.file.seek(SeekFrom::Start(offset + 16))?;
        let mut stored = [0u8; 32];
        self.file.read_exact(&mut stored)?;
        let mut payload = vec![0u8; length as usize];
        self.file.read_exact(&mut payload)?;
        let actual: [u8; 32] = Sha256::digest(&payload).into();
        if actual != stored {
            return Err(io::Error::other("corrupt_object: analytic frame checksum"));
        }
        Ok(payload)
    }
    pub fn append(&mut self, payload: &[u8]) -> io::Result<u64> {
        if !self.healthy {
            return Err(io::Error::other(
                "journal requires recovery after an I/O failure",
            ));
        }
        let length = payload.len() as u64;
        let next = self
            .end
            .checked_add(FRAME_HEADER)
            .and_then(|v| v.checked_add(length));
        if length == 0 || length > MAX_FRAME || next.is_none_or(|end| end > self.quota) {
            return Err(io::Error::other(
                "resource_limit: analytic journal transaction/quota",
            ));
        }
        let offset = self.end;
        let result = (|| {
            self.file.seek(SeekFrom::Start(offset))?;
            self.file.write_all(&length.to_le_bytes())?;
            self.file.write_all(&(!length).to_le_bytes())?;
            self.file.write_all(&Sha256::digest(payload))?;
            self.file.write_all(payload)?;
            self.file.sync_all()
        })();
        if let Err(error) = result {
            self.healthy = false;
            return Err(error);
        }
        self.end = next.unwrap();
        self.offsets.push(offset);
        Ok(offset)
    }
    pub fn read(&mut self, offset: u64) -> io::Result<Vec<u8>> {
        if self.offsets.binary_search(&offset).is_err() {
            return Err(io::Error::other("not_found: analytic frame"));
        }
        let length = self.frame_length(offset)?;
        self.read_frame(offset, length)
    }
    pub fn offsets(&self) -> &[u64] {
        &self.offsets
    }
    pub fn bytes(&self) -> u64 {
        self.end
    }
}
