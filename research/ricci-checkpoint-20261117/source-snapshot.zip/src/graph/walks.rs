//! Exact walk counts for finite undirected multigraphs.
//!
//! A walk may revisit vertices or edges. Each positive multiplicity counts
//! that many independent choices of edge. A loop contributes its multiplicity
//! once to the diagonal, and a walk of length zero stays at its start.

use std::collections::BTreeMap;

use num_bigint::BigUint;
use thiserror::Error;

type Row = BTreeMap<usize, BigUint>;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum WalkError {
    #[error("a walk graph must have at least one vertex")]
    EmptyGraph,
    #[error("vertex {0} was declared more than once")]
    DuplicateVertex(u64),
    #[error("vertex {0} is not declared in the walk graph")]
    UnknownVertex(u64),
    #[error("partition cell {0} is empty")]
    EmptyCell(usize),
    #[error("vertex {0} occurs more than once in the partition")]
    DuplicateMember(u64),
    #[error("vertex {0} is missing from the partition")]
    MissingMember(u64),
    #[error(
        "vertex {vertex} in cell {cell} has inconsistent edge multiplicity into cell {destination}"
    )]
    NonEquitable {
        vertex: u64,
        cell: usize,
        destination: usize,
    },
    #[error("target {vertex} belongs to a cell of size {size}; an individual target requires a singleton cell")]
    TargetNotSingleton { vertex: u64, size: usize },
}

/// Undirected multigraph with an explicit vertex list, including isolates.
#[derive(Debug, Clone)]
pub struct WeightedWalkGraph {
    vertex_index: BTreeMap<u64, usize>,
    vertices: Vec<u64>,
    rows: Vec<Row>,
}

impl WeightedWalkGraph {
    /// Each edge record is `(start, end, multiplicity)`. Repeated records
    /// add parallel edges, even when their endpoints are listed in reverse
    /// order. Zero multiplicities contribute no edge.
    pub fn from_edges(
        vertices: &[u64],
        edges: impl IntoIterator<Item = (u64, u64, u64)>,
    ) -> Result<Self, WalkError> {
        if vertices.is_empty() {
            return Err(WalkError::EmptyGraph);
        }
        let mut vertex_index = BTreeMap::new();
        for (index, &vertex) in vertices.iter().enumerate() {
            if vertex_index.insert(vertex, index).is_some() {
                return Err(WalkError::DuplicateVertex(vertex));
            }
        }
        let mut rows = vec![Row::new(); vertices.len()];
        for (u, v, multiplicity) in edges {
            let u = vertex_position(&vertex_index, u)?;
            let v = vertex_position(&vertex_index, v)?;
            if multiplicity != 0 {
                *rows[u].entry(v).or_default() += multiplicity;
                if u != v {
                    *rows[v].entry(u).or_default() += multiplicity;
                }
            }
        }
        Ok(Self {
            vertex_index,
            vertices: vertices.to_vec(),
            rows,
        })
    }

    /// Return the counts for lengths `0..=max_len`, in that order.
    pub fn counts_through(
        &self,
        source: u64,
        target: u64,
        max_len: usize,
    ) -> Result<Vec<BigUint>, WalkError> {
        let source = vertex_position(&self.vertex_index, source)?;
        let target = vertex_position(&self.vertex_index, target)?;
        Ok(counts_through(&self.rows, source, target, max_len))
    }

    /// Certify a partition and retain its smaller walk operator. For every
    /// vertex in a cell, check the total multiplicity into each destination
    /// cell. Equality of these row totals is exactly `AP = PB`, where
    /// `P` is the vertex-to-cell indicator matrix.
    pub fn equitable_quotient(&self, cells: &[&[u64]]) -> Result<EquitableWalkQuotient, WalkError> {
        let mut cell_of = vec![None; self.vertices.len()];
        let mut representatives = Vec::new();
        for (cell, members) in cells.iter().enumerate() {
            let first = members.first().ok_or(WalkError::EmptyCell(cell))?;
            representatives.push(vertex_position(&self.vertex_index, *first)?);
            for &vertex in *members {
                let index = vertex_position(&self.vertex_index, vertex)?;
                if cell_of[index].replace(cell).is_some() {
                    return Err(WalkError::DuplicateMember(vertex));
                }
            }
        }
        let cell_of: Vec<usize> = cell_of
            .into_iter()
            .zip(&self.vertices)
            .map(|(cell, &vertex)| cell.ok_or(WalkError::MissingMember(vertex)))
            .collect::<Result<_, _>>()?;

        let rows: Vec<Row> = representatives
            .iter()
            .map(|&index| cell_totals(&self.rows[index], &cell_of))
            .collect();
        for (index, &cell) in cell_of.iter().enumerate() {
            if index == representatives[cell] {
                continue;
            }
            let actual = cell_totals(&self.rows[index], &cell_of);
            let expected = &rows[cell];
            if actual != *expected {
                let destination = (0..cells.len())
                    .find(|destination| actual.get(destination) != expected.get(destination))
                    .expect("different rows have a differing cell");
                return Err(WalkError::NonEquitable {
                    vertex: self.vertices[index],
                    cell,
                    destination,
                });
            }
        }
        Ok(EquitableWalkQuotient {
            vertex_cells: self.vertices.iter().copied().zip(cell_of).collect(),
            cell_sizes: cells.iter().map(|members| members.len()).collect(),
            rows,
        })
    }
}

/// Certified smaller operator. A row describes the outgoing choices from
/// one vertex in that cell. The matrix may be asymmetric and may have
/// nonzero diagonal entries even when the original graph has no loops.
#[derive(Debug, Clone)]
pub struct EquitableWalkQuotient {
    vertex_cells: BTreeMap<u64, usize>,
    cell_sizes: Vec<usize>,
    rows: Vec<Row>,
}

impl EquitableWalkQuotient {
    /// Return the exact matrix in input cell order.
    pub fn matrix(&self) -> Vec<Vec<BigUint>> {
        self.rows
            .iter()
            .map(|row| {
                (0..self.rows.len())
                    .map(|cell| row.get(&cell).cloned().unwrap_or_default())
                    .collect()
            })
            .collect()
    }

    /// Count walks from any single source vertex to a singleton target.
    /// The certificate gives `A^k P = P B^k` for every length `k`, so
    /// an entry of `B^k` counts all walks into the target cell. For a
    /// singleton this is the count to the requested individual vertex.
    pub fn counts_through(
        &self,
        source: u64,
        target: u64,
        max_len: usize,
    ) -> Result<Vec<BigUint>, WalkError> {
        let source_cell = vertex_position(&self.vertex_cells, source)?;
        let target_cell = vertex_position(&self.vertex_cells, target)?;
        let size = self.cell_sizes[target_cell];
        if size != 1 {
            return Err(WalkError::TargetNotSingleton {
                vertex: target,
                size,
            });
        }
        Ok(counts_through(
            &self.rows,
            source_cell,
            target_cell,
            max_len,
        ))
    }
}

fn vertex_position(index: &BTreeMap<u64, usize>, vertex: u64) -> Result<usize, WalkError> {
    index
        .get(&vertex)
        .copied()
        .ok_or(WalkError::UnknownVertex(vertex))
}

fn cell_totals(row: &Row, cell_of: &[usize]) -> Row {
    let mut totals = Row::new();
    for (&destination, multiplicity) in row {
        *totals.entry(cell_of[destination]).or_default() += multiplicity;
    }
    totals
}

fn counts_through(rows: &[Row], source: usize, target: usize, max_len: usize) -> Vec<BigUint> {
    let mut current = vec![BigUint::default(); rows.len()];
    current[source] = 1_u64.into();
    let mut counts = Vec::new();
    for len in 0..=max_len {
        counts.push(current[target].clone());
        if len == max_len {
            break;
        }
        let mut next = vec![BigUint::default(); rows.len()];
        for (row, count) in rows.iter().zip(&current) {
            if count.bits() != 0 {
                for (&destination, multiplicity) in row {
                    next[destination] += count * multiplicity;
                }
            }
        }
        current = next;
    }
    counts
}
