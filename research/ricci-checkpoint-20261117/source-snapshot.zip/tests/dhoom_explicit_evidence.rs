#![cfg(feature = "kahler")]
use serde_json::json;

#[test]
fn independent_ledger_fields_and_empty_arrays_survive_exactly() {
    let record = json!({"samples":[
        {"time":0.,"stored":0.,"supplied":0.,"lost":0.,"edges":[]},
        {"time":0.5,"stored":0.07740906087308774,"supplied":0.39346934028736663,"lost":0.31606027941427883,"edges":[]},
        {"time":1.,"stored":0.19978820044686402,"supplied":0.6321205588285577,"lost":0.43233235838169365,"edges":[]}
    ],"text":"1.0","notes":["first\nsecond","a,b"],"truth":true,"absent":null});
    let encoded = gigi::dhoom::encode_explicit_record(&record, "evidence").unwrap();
    assert!(!encoded.lines().next().unwrap().contains('#'));
    let decoded = gigi::dhoom::decode(&encoded).unwrap();
    assert_eq!(decoded["evidence"][0], record);
}

#[test]
fn explicit_encoder_rejects_ambiguous_header_names() {
    for name in ["", "x,y", "x\ny", "x|0", "1field"] {
        assert!(gigi::dhoom::encode_explicit_record(&json!({"x":1}), name).is_err());
        assert!(gigi::dhoom::encode_explicit_record(&json!({name:1}), "evidence").is_err());
    }
    assert!(gigi::dhoom::encode_explicit_record(&json!({}), "evidence").is_err());
}

#[test]
fn finite_float_bits_survive_explicit_composite_cells() {
    let mut values = vec![
        0.,
        -0.,
        f64::MIN_POSITIVE,
        f64::from_bits(1),
        f64::MAX,
        -f64::MAX,
    ];
    let mut state = 20261113_u64;
    for _ in 0..2048 {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        let value = f64::from_bits(state);
        if value.is_finite() {
            values.push(value);
        }
    }
    let record = json!({"values":values});
    let encoded = gigi::dhoom::encode_explicit_record(&record, "evidence").unwrap();
    let decoded = gigi::dhoom::decode(&encoded).unwrap();
    let actual = decoded["evidence"][0]["values"].as_array().unwrap();
    assert_eq!(actual.len(), values.len());
    for (a, b) in actual.iter().zip(values) {
        assert_eq!(a.as_f64().unwrap().to_bits(), b.to_bits());
    }
}

#[test]
fn unsupported_root_unsigned_scalar_refuses_instead_of_rounding() {
    let error=gigi::dhoom::encode_explicit_record(&json!({"counter":u64::MAX}),"evidence").unwrap_err().to_string();
    assert!(error.contains("counter") && error.contains("JSON"));
    let nested=json!({"source":{"counter":u64::MAX}});
    let encoded=gigi::dhoom::encode_explicit_record(&nested,"evidence").unwrap();
    assert_eq!(gigi::dhoom::decode(&encoded).unwrap()["evidence"][0],nested);
}
