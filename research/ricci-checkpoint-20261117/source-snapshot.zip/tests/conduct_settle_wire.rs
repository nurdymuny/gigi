#![cfg(feature = "kahler")]

#[test]
#[ignore = "requires CONDUCT_SETTLE_RECEIPTS from the isolated live probe"]
fn captured_live_dhoom_matches_json() {
    let path = std::env::var("CONDUCT_SETTLE_RECEIPTS")
        .expect("set CONDUCT_SETTLE_RECEIPTS to the live receipts.json");
    let rows: serde_json::Value = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
    let rows = rows.as_array().unwrap();
    let mut checked = 0;
    for (i, row) in rows.iter().enumerate() {
        if row["accept"] != "application/dhoom" {
            continue;
        }
        assert_eq!(row["status"], 200);
        let decoded = gigi::dhoom::decode(row["response"].as_str().unwrap()).unwrap();
        let baseline = rows[..i]
            .iter()
            .rev()
            .find(|r| {
                r["path"] == row["path"]
                    && r["request"] == row["request"]
                    && r["accept"] == "application/json"
            })
            .expect("paired JSON receipt");
        assert_eq!(decoded["brain_response"][0], baseline["response"]);
        for receipt in [row, baseline] {
            let counter = receipt["headers"]
                .as_object()
                .unwrap()
                .iter()
                .find(|(name, _)| name.eq_ignore_ascii_case("x-bundle-mutation-counter"))
                .unwrap()
                .1
                .as_str()
                .unwrap()
                .parse::<u64>()
                .unwrap();
            assert_eq!(
                counter,
                baseline["response"]["source"]["revision"].as_u64().unwrap()
            );
        }
        checked += 1;
    }
    assert_eq!(
        checked, 2,
        "must exercise both CONDUCT and SETTLE wire shapes"
    );
}
