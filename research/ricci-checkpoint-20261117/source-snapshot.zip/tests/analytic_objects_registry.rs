#![cfg(feature = "kahler")]
use gigi::analytic_objects::{prepared::Prepared, registry::*};
use std::cell::Cell;

fn request() -> BuildRequest {
    BuildRequest {
        object_id: None,
        expected_head: None,
        sources: vec![SourceSnapshot {
            name: "measurements".into(),
            source: SourceRevision {
                bundle_id: "4bbd50a4-f478-42d1-a19e-d27601834bb4".into(),
                incarnation: "21cc3633-e53f-4649-aed5-d77c0ee482a4".into(),
                revision: 7,
                schema_digest: [1; 32],
            },
            content_digest: [2; 32],
            records: 3,
        }],
        coordinates: Coordinates {
            input_units: "dimensionless".into(),
            output_units: "relative_frequency".into(),
            meaning: "histogram generating-function coordinate".into(),
            chart: "unit_disk".into(),
            regime: "fixture".into(),
            normalization: "1/N".into(),
        },
        recipe: serde_json::json!({"kind":"fixed_histogram","edges":[0,1,2]}),
        numerical_policy: POLICY.into(),
    }
}
fn model() -> Result<Prepared, String> {
    Prepared::histogram(&[2, 1], 1.01)
}

#[test]
fn registry_exact_cache_hits_do_no_analytic_work_and_one_ulp_is_a_miss() {
    use gigi::geometry::analytic_work;
    let tmp = tempfile::tempdir().unwrap();
    let req = request();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let m = registry
        .prepare("bee", "one", &req, || Ok(current(&req)), model)
        .unwrap();
    let points: Vec<_> = (0..256).map(|i| [i as f64 / 300., 0.]).collect();
    let first = registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &points,
            None,
        )
        .unwrap();
    analytic_work::reset();
    let cached = registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &points,
            None,
        )
        .unwrap();
    assert_eq!(cached.execution_mode, "point_cache_hit");
    assert_eq!(analytic_work::read().recurrence_steps, 0);
    assert_eq!(
        serde_json::to_value(first.answers).unwrap(),
        serde_json::to_value(cached.answers).unwrap()
    );
    let z = f64::from_bits(points[100][0].to_bits() + 1);
    analytic_work::reset();
    let new = registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[z, 0.]],
            None,
        )
        .unwrap();
    assert_eq!(new.execution_mode, "prepared_evaluation");
    assert!(analytic_work::read().recurrence_steps > 0);
    analytic_work::reset();
    let zero = registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[-0., 0.]],
            None,
        )
        .unwrap();
    assert_eq!(zero.execution_mode, "point_cache_hit");
    assert_eq!(zero.answers[0].z[0].to_bits(), 0);
    assert_eq!(analytic_work::read().recurrence_steps, 0);
    let mut stale = current(&req);
    stale[0].revision += 1;
    assert!(registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::RequireCurrent,
            "value_and_derivatives",
            &points,
            Some(&stale)
        )
        .unwrap_err()
        .contains("stale_source"));
    assert!(registry
        .query(
            "other",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &points,
            None
        )
        .unwrap_err()
        .contains("forbidden"));
}

#[test]
fn registry_bounded_eviction_never_changes_answers_and_disabled_cache_stays_empty() {
    let tmp = tempfile::tempdir().unwrap();
    let req = request();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    registry.configure_caches(2 * 1024 * 1024, 1024).unwrap();
    let m = registry
        .prepare("bee", "one", &req, || Ok(current(&req)), model)
        .unwrap();
    for i in 0..32 {
        let x = i as f64 / 40.;
        let r = registry
            .query(
                "bee",
                &m.object_id,
                &m.version_id,
                Freshness::Pinned,
                "value_and_derivatives",
                &[[x, 0.]],
                None,
            )
            .unwrap();
        assert!((r.answers[0].value[0] - (2. + x) / 3.).abs() < 1e-12);
        assert!(registry.cache_usage()[0].1 <= 2 * 1024 * 1024);
        assert!(registry.cache_usage()[1].1 <= 1024);
    }
    assert!(registry.cache_usage()[0].0 > 0);
    assert!(registry.cache_usage()[1].0 > 0);
    let first = registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0., 0.]],
            None,
        )
        .unwrap();
    assert_eq!(first.execution_mode, "prepared_evaluation");
    registry.configure_caches(0, 0).unwrap();
    for _ in 0..2 {
        let r = registry
            .query(
                "bee",
                &m.object_id,
                &m.version_id,
                Freshness::Pinned,
                "value_and_derivatives",
                &[[0., 0.]],
                None,
            )
            .unwrap();
        assert_eq!(r.execution_mode, "cold_object_load");
        assert_eq!(registry.cache_usage(), [(0, 0), (0, 0)]);
    }
}

#[test]
fn registry_failed_batch_publishes_no_new_point_cache_entries() {
    use gigi::geometry::analytic_work;
    let tmp = tempfile::tempdir().unwrap();
    let req = request();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let m = registry
        .prepare("bee", "one", &req, || Ok(current(&req)), model)
        .unwrap();
    assert!(registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0.2, 0.], [1., 0.]],
            None
        )
        .is_err());
    assert_eq!(registry.cache_usage()[1].0, 0);
    analytic_work::reset();
    registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0.2, 0.]],
            None,
        )
        .unwrap();
    assert!(analytic_work::read().recurrence_steps > 0);
}
fn current(r: &BuildRequest) -> Vec<SourceRevision> {
    r.sources.iter().map(|s| s.source.clone()).collect()
}

#[test]
fn registry_replays_immutable_version_and_idempotency_receipt_without_building() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("objects.log");
    let req = request();
    let first;
    {
        let mut registry = Registry::open(&path, 1024 * 1024).unwrap();
        first = registry
            .prepare("bee", "build-1", &req, || Ok(current(&req)), model)
            .unwrap();
    }
    let mut registry = Registry::open(&path, 1024 * 1024).unwrap();
    let repeated = registry
        .prepare(
            "bee",
            "build-1",
            &req,
            || Err::<Vec<SourceRevision>, String>("metadata offline".into()),
            || panic!("retry must not rebuild"),
        )
        .unwrap();
    assert_eq!(first.version_id, repeated.version_id);
    assert_eq!(first.object_id, repeated.object_id);
    let result = registry
        .query(
            "bee",
            &first.object_id,
            &first.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0.5, 0.]],
            None,
        )
        .unwrap();
    assert!((result.answers[0].value[0] - 5. / 6.).abs() < 1e-12);
    assert_eq!(result.sources[0].source.revision, 7);
    assert_eq!(result.freshness, "historical_snapshot");
    assert!(registry
        .query(
            "bee",
            &first.object_id,
            &first.version_id,
            Freshness::RequireCurrent,
            "value_and_derivatives",
            &[[0.5, 0.]],
            None
        )
        .unwrap_err()
        .contains("source_state_unavailable"));
}

#[test]
fn registry_source_lease_spans_durable_publication_but_not_mathematical_build() {
    use std::{cell::RefCell, path::PathBuf};
    struct Lease<'a> {
        sources: Vec<SourceRevision>,
        path: PathBuf,
        events: &'a RefCell<Vec<u64>>,
        active: &'a Cell<usize>,
    }
    impl SourceLease for Lease<'_> {
        fn revisions(&self) -> &[SourceRevision] {
            &self.sources
        }
    }
    impl Drop for Lease<'_> {
        fn drop(&mut self) {
            self.events
                .borrow_mut()
                .push(std::fs::metadata(&self.path).unwrap().len());
            self.active.set(self.active.get() - 1);
        }
    }
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("log");
    let req = request();
    let mut registry = Registry::open(&path, 1024 * 1024).unwrap();
    let empty = std::fs::metadata(&path).unwrap().len();
    let events = RefCell::new(vec![]);
    let active = Cell::new(0);
    registry
        .prepare(
            "bee",
            "lease",
            &req,
            || {
                active.set(active.get() + 1);
                Ok(Lease {
                    sources: current(&req),
                    path: path.clone(),
                    events: &events,
                    active: &active,
                })
            },
            || {
                assert_eq!(
                    active.get(),
                    0,
                    "do not hold source lock during mathematics"
                );
                model()
            },
        )
        .unwrap();
    assert_eq!(active.get(), 0);
    let events = events.borrow();
    assert_eq!(events.len(), 2);
    assert_eq!(events[0], empty);
    assert!(
        events[1] > empty,
        "final lease was released before durable publication"
    );
}

#[test]
fn registry_source_revision_incarnation_schema_and_deletion_have_separate_stale_cases() {
    let tmp = tempfile::tempdir().unwrap();
    let req = request();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let manifest = registry
        .prepare("bee", "one", &req, || Ok(current(&req)), model)
        .unwrap();
    registry
        .query(
            "bee",
            &manifest.object_id,
            &manifest.version_id,
            Freshness::RequireCurrent,
            "value_and_derivatives",
            &[[0., 0.]],
            Some(&current(&req)),
        )
        .unwrap();
    let mut replaced = current(&req);
    replaced[0].revision += 1;
    let mut recreated = current(&req);
    recreated[0].incarnation = "5e98aaf0-31d1-4681-972a-87cd44d275dc".into();
    let mut schema = current(&req);
    schema[0].schema_digest = [9; 32];
    for state in [replaced, recreated, schema, vec![]] {
        assert!(registry
            .query(
                "bee",
                &manifest.object_id,
                &manifest.version_id,
                Freshness::RequireCurrent,
                "value_and_derivatives",
                &[[0., 0.]],
                Some(&state)
            )
            .unwrap_err()
            .contains("stale_source"));
    }
}

#[test]
fn registry_rejects_publication_after_source_changed_during_build() {
    let tmp = tempfile::tempdir().unwrap();
    let req = request();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let changed = Cell::new(false);
    let builds = Cell::new(0);
    let result = registry.prepare(
        "bee",
        "race",
        &req,
        || {
            let mut s = current(&req);
            if changed.get() {
                s[0].revision += 1
            };
            Ok(s)
        },
        || {
            builds.set(builds.get() + 1);
            changed.set(true);
            model()
        },
    );
    assert_eq!(builds.get(), 1);
    assert!(result.unwrap_err().contains("stale_source"));
    registry
        .prepare(
            "bee",
            "race",
            &req,
            || Ok(current(&req)),
            || {
                builds.set(builds.get() + 1);
                model()
            },
        )
        .unwrap();
    assert_eq!(
        builds.get(),
        2,
        "failed publication did not leave a success receipt"
    );
}

#[test]
fn registry_new_head_does_not_overwrite_old_version_or_allow_wrong_retry() {
    let tmp = tempfile::tempdir().unwrap();
    let mut req = request();
    let mut registry = Registry::open(&tmp.path().join("log"), 1024 * 1024).unwrap();
    let original = registry
        .prepare("bee", "one", &req, || Ok(current(&req)), model)
        .unwrap();
    let mut wrong = req.clone();
    wrong.recipe["edges"] = serde_json::json!([0, 2, 4]);
    assert!(registry
        .prepare("bee", "one", &wrong, || Ok(current(&wrong)), model)
        .unwrap_err()
        .contains("idempotency_conflict"));
    req.object_id = Some(original.object_id.clone());
    req.expected_head = Some(original.version_id.clone());
    req.recipe["bound"] = 2.0.into();
    let next = registry
        .prepare(
            "bee",
            "two",
            &req,
            || Ok(current(&req)),
            || Prepared::histogram(&[1, 2], 2.),
        )
        .unwrap();
    assert_ne!(original.version_id, next.version_id);
    assert!(registry
        .query(
            "bee",
            &original.object_id,
            &original.version_id,
            Freshness::RequireCurrent,
            "value_and_derivatives",
            &[[0.5, 0.]],
            Some(&current(&req))
        )
        .unwrap_err()
        .contains("stale_head"));
    let old = registry
        .query(
            "bee",
            &original.object_id,
            &original.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0.5, 0.]],
            None,
        )
        .unwrap();
    assert!((old.answers[0].value[0] - 5. / 6.).abs() < 1e-12);
}

#[test]
fn registry_owner_and_tombstone_apply_after_restart_and_receipt_retries() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("log");
    let req = request();
    let mut registry = Registry::open(&path, 1024 * 1024).unwrap();
    let m = registry
        .prepare("bee", "one", &req, || Ok(current(&req)), model)
        .unwrap();
    assert!(registry
        .query(
            "other",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0., 0.]],
            None
        )
        .unwrap_err()
        .contains("forbidden"));
    assert!(registry
        .delete("other", &m.object_id)
        .unwrap_err()
        .contains("forbidden"));
    registry.delete("bee", &m.object_id).unwrap();
    drop(registry);
    let mut registry = Registry::open(&path, 1024 * 1024).unwrap();
    assert!(registry
        .query(
            "bee",
            &m.object_id,
            &m.version_id,
            Freshness::Pinned,
            "value_and_derivatives",
            &[[0., 0.]],
            None
        )
        .unwrap_err()
        .contains("gone"));
    assert!(registry
        .prepare(
            "bee",
            "one",
            &req,
            || Ok(current(&req)),
            || panic!("tombstone cannot rebuild")
        )
        .unwrap_err()
        .contains("gone"));
}
