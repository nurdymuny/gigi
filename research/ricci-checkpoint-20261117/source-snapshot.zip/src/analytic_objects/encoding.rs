//! Bounded canonical storage encoding. Digests detect corruption, not authority.
use serde_json::{Map, Number, Value};

pub const MAX_BYTES: usize = 2 * 1024 * 1024;
const HEADER: &[u8; 8] = b"GGAO\x01\x00\x00\x00";

pub fn encode(value: &Value) -> Result<Vec<u8>, String> {
    fn put(v: &Value, out: &mut Vec<u8>, depth: usize) -> Result<(), String> {
        if depth > 32 || out.len() > MAX_BYTES {
            return Err("resource_limit: analytic encoding".into());
        }
        let length = |n: usize, out: &mut Vec<u8>| -> Result<(), String> {
            let n = u32::try_from(n).map_err(|_| "resource_limit: encoding length")?;
            out.extend_from_slice(&n.to_le_bytes());
            Ok(())
        };
        match v {
            Value::Null => out.push(0),
            Value::Bool(false) => out.push(1),
            Value::Bool(true) => out.push(2),
            Value::Number(n) if n.is_f64() => {
                let x = n.as_f64().ok_or("invalid float")?;
                if !x.is_finite() {
                    return Err("nonfinite storage number".into());
                }
                out.push(5);
                out.extend_from_slice(&(if x == 0. { 0f64 } else { x }).to_bits().to_le_bytes());
            }
            Value::Number(n) if n.as_u64().is_some() => {
                out.push(4);
                out.extend_from_slice(&n.as_u64().unwrap().to_le_bytes());
            }
            Value::Number(n) => {
                out.push(3);
                out.extend_from_slice(&n.as_i64().ok_or("invalid integer")?.to_le_bytes());
            }
            Value::String(s) => {
                out.push(6);
                length(s.len(), out)?;
                out.extend_from_slice(s.as_bytes());
            }
            Value::Array(items) => {
                if items.len() > 65536 {
                    return Err("resource_limit: encoding array".into());
                }
                out.push(7);
                length(items.len(), out)?;
                for item in items {
                    put(item, out, depth + 1)?;
                }
            }
            Value::Object(items) => {
                if items.len() > 65536 {
                    return Err("resource_limit: encoding object".into());
                }
                out.push(8);
                length(items.len(), out)?;
                let mut keys: Vec<_> = items.keys().collect();
                keys.sort();
                for key in keys {
                    put(&Value::String(key.clone()), out, depth + 1)?;
                    put(&items[key], out, depth + 1)?;
                }
            }
        }
        if out.len() > MAX_BYTES {
            return Err("resource_limit: analytic encoding".into());
        }
        Ok(())
    }
    let mut out = HEADER.to_vec();
    put(value, &mut out, 0)?;
    Ok(out)
}

pub fn decode(bytes: &[u8]) -> Result<Value, String> {
    struct Reader<'a> {
        bytes: &'a [u8],
        pos: usize,
    }
    impl Reader<'_> {
        fn take(&mut self, n: usize) -> Result<&[u8], String> {
            let end = self
                .pos
                .checked_add(n)
                .ok_or("corrupt_object: length overflow")?;
            let part = self
                .bytes
                .get(self.pos..end)
                .ok_or("corrupt_object: truncated encoding")?;
            self.pos = end;
            Ok(part)
        }
        fn length(&mut self) -> Result<usize, String> {
            Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()) as usize)
        }
        fn value(&mut self, depth: usize) -> Result<Value, String> {
            if depth > 32 {
                return Err("corrupt_object: nesting limit".into());
            }
            Ok(match self.take(1)?[0] {
                0 => Value::Null,
                1 => false.into(),
                2 => true.into(),
                3 => i64::from_le_bytes(self.take(8)?.try_into().unwrap()).into(),
                4 => u64::from_le_bytes(self.take(8)?.try_into().unwrap()).into(),
                5 => Value::Number(
                    Number::from_f64(f64::from_bits(u64::from_le_bytes(
                        self.take(8)?.try_into().unwrap(),
                    )))
                    .ok_or("corrupt_object: nonfinite float")?,
                ),
                6 => {
                    let n = self.length()?;
                    String::from_utf8(self.take(n)?.to_vec())
                        .map_err(|_| "corrupt_object: UTF-8")?
                        .into()
                }
                7 => {
                    let n = self.length()?;
                    if n > 65536 {
                        return Err("corrupt_object: array limit".into());
                    }
                    let mut values = Vec::new();
                    for _ in 0..n {
                        values.push(self.value(depth + 1)?);
                    }
                    Value::Array(values)
                }
                8 => {
                    let n = self.length()?;
                    if n > 65536 {
                        return Err("corrupt_object: map limit".into());
                    }
                    let mut values = Map::new();
                    for _ in 0..n {
                        let key = self
                            .value(depth + 1)?
                            .as_str()
                            .ok_or("corrupt_object: non-string key")?
                            .to_owned();
                        let value = self.value(depth + 1)?;
                        if values.insert(key, value).is_some() {
                            return Err("corrupt_object: duplicate key".into());
                        }
                    }
                    Value::Object(values)
                }
                _ => return Err("corrupt_object: unknown value tag".into()),
            })
        }
    }
    if bytes.len() > MAX_BYTES {
        return Err("resource_limit: stored object too large".into());
    }
    if bytes.get(..8) != Some(HEADER.as_slice()) {
        return Err("unsupported_version: analytic encoding".into());
    }
    let mut reader = Reader { bytes, pos: 8 };
    let value = reader.value(0)?;
    if reader.pos != bytes.len() || encode(&value)? != bytes {
        return Err("corrupt_object: noncanonical encoding".into());
    }
    Ok(value)
}
