//! Strict framing evidence. Does not decode payloads or certify source freshness.
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::io::{self, Read, Seek, SeekFrom};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WalFrameEvidence {
    pub format_version: u8,
    pub frames: u64,
    pub bytes: u64,
    pub sha256: [u8; 32],
    pub opcode_counts: BTreeMap<u8, u64>,
}

/// Audit ALL framing/checksums; never resynchronize or return a salvaged prefix.
///
/// The caller must exclude concurrent writes (including same-length rewrites).
/// This does not decode payloads, check opcode support, establish fsync, or
/// certify that the WAL alone contains everything needed for source recovery.
pub fn audit_wal_frames<R: Read + Seek>(
    reader: &mut R,
    max_frame_bytes: u32,
) -> io::Result<WalFrameEvidence> {
    if max_frame_bytes == 0 || max_frame_bytes > 512 * 1024 * 1024 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "WAL audit frame limit must be in 1..=536870912 bytes",
        ));
    }
    let length = reader.seek(SeekFrom::End(0))?;
    reader.seek(SeekFrom::Start(0))?;
    let mut offset = 0u64;
    let mut frames = 0u64;
    let mut opcode_counts = BTreeMap::new();
    let mut hash = Sha256::new();
    let mut buffer = [0u8; 16384];
    while offset < length {
        let mut header = [0u8; 4];
        read_at(reader, &mut header, offset)?;
        let size = u32::from_le_bytes(header);
        if size == 0 || size > max_frame_bytes {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                format!(
                    "WAL audit at byte {offset}: frame length {size} outside 1..={max_frame_bytes}"
                ),
            ));
        }
        let frame_bytes = u64::from(size) + 8;
        if frame_bytes > length - offset {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                format!(
                    "WAL audit at byte {offset}: incomplete frame; require {frame_bytes} bytes"
                ),
            ));
        }
        hash.update(header);
        let mut remaining = size as usize;
        let mut crc = u32::MAX;
        let mut opcode = None;
        while remaining > 0 {
            let take = remaining.min(buffer.len());
            read_at(
                reader,
                &mut buffer[..take],
                offset + 4 + u64::from(size) - remaining as u64,
            )?;
            if opcode.is_none() {
                opcode = Some(buffer[0]);
            }
            crc = super::crc32_update(crc, &buffer[..take]);
            hash.update(&buffer[..take]);
            remaining -= take;
        }
        let mut checksum = [0u8; 4];
        read_at(reader, &mut checksum, offset + 4 + u64::from(size))?;
        if !crc != u32::from_le_bytes(checksum) {
            return Err(io::Error::new(io::ErrorKind::InvalidData,
                format!("WAL audit at byte {offset}: CRC mismatch; history cannot be certified complete")));
        }
        hash.update(checksum);
        *opcode_counts
            .entry(opcode.expect("nonempty frame"))
            .or_insert(0) += 1;
        frames += 1;
        offset += frame_bytes;
    }
    if reader.seek(SeekFrom::End(0))? != length {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "WAL audit length changed; retry only under writer exclusion",
        ));
    }
    Ok(WalFrameEvidence {
        format_version: 1,
        frames,
        bytes: offset,
        sha256: hash.finalize().into(),
        opcode_counts,
    })
}

fn read_at<R: Read>(reader: &mut R, bytes: &mut [u8], offset: u64) -> io::Result<()> {
    reader
        .read_exact(bytes)
        .map_err(|e| io::Error::new(e.kind(), format!("WAL audit at byte {offset}: {e}")))
}
