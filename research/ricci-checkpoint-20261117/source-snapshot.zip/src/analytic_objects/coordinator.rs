//! Bounded preparation coordination; mathematical builds run outside the registry lock.
use super::{
    prepared::Prepared,
    registry::{hash, BuildRequest, Manifest, Registry, SourceLease},
};
use std::{
    collections::HashMap,
    panic::{catch_unwind, AssertUnwindSafe},
    sync::{Arc, Condvar, Mutex, MutexGuard},
};

type Outcome = Result<Manifest, String>;
struct Flight {
    request_hash: [u8; 32],
    result: Mutex<Option<Outcome>>,
    ready: Condvar,
}
#[derive(Default)]
struct Flights {
    entries: HashMap<[u8; 32], Arc<Flight>>,
    waiters: usize,
}
pub struct Coordinator {
    registry: Mutex<Registry>,
    flights: Mutex<Flights>,
    capacity: usize,
}
struct Waiter<'a>(&'a Coordinator);
impl Drop for Waiter<'_> {
    fn drop(&mut self) {
        self.0
            .flights
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .waiters -= 1;
    }
}
struct Leader<'a> {
    owner: &'a Coordinator,
    key: [u8; 32],
    flight: Arc<Flight>,
}
impl Leader<'_> {
    fn finish(&self, outcome: Outcome) {
        let mut result = self.flight.result.lock().unwrap_or_else(|p| p.into_inner());
        if result.is_none() {
            *result = Some(outcome);
        }
        self.flight.ready.notify_all();
        drop(result);
        let mut flights = self.owner.flights.lock().unwrap_or_else(|p| p.into_inner());
        if flights
            .entries
            .get(&self.key)
            .is_some_and(|f| Arc::ptr_eq(f, &self.flight))
        {
            flights.entries.remove(&self.key);
            if flights.entries.is_empty() {
                flights.entries = HashMap::new();
            }
        }
    }
}
impl Drop for Leader<'_> {
    fn drop(&mut self) {
        self.finish(Err(
            "builder_cancelled: preparation ended before publication".into(),
        ));
    }
}
impl Coordinator {
    pub fn new(registry: Registry, capacity: usize) -> Result<Self, String> {
        if !(1..=64).contains(&capacity) {
            return Err("resource_limit: preparation capacity must be 1..64".into());
        }
        Ok(Self {
            registry: Mutex::new(registry),
            flights: Mutex::new(Flights::default()),
            capacity,
        })
    }
    fn registry(&self) -> Result<MutexGuard<'_, Registry>, String> {
        self.registry
            .lock()
            .map_err(|_| "registry_unavailable: recovery required after panic".into())
    }
    pub fn usage(&self) -> (usize, usize) {
        let flights = self.flights.lock().unwrap_or_else(|p| p.into_inner());
        (flights.entries.len(), flights.waiters)
    }
    pub fn prepare<L: SourceLease>(
        &self,
        principal: &str,
        key: &str,
        request: &BuildRequest,
        mut current: impl FnMut() -> Result<L, String>,
        build: impl FnOnce() -> Result<Prepared, String>,
    ) -> Outcome {
        Registry::validate_request(principal, key, request)?;
        if let Some(receipt) = self.registry()?.retry(principal, key, request)? {
            return Ok(receipt);
        }
        let flight_key = hash(&(principal, &request.object_id, key))?;
        let request_hash = hash(request)?;
        let (flight, leader) = {
            let mut flights = self
                .flights
                .lock()
                .map_err(|_| "coordination_unavailable")?;
            if let Some(flight) = flights.entries.get(&flight_key).cloned() {
                if flight.request_hash != request_hash {
                    return Err(
                        "idempotency_conflict: active key is bound to a different request".into(),
                    );
                }
                if flights.waiters >= 256 {
                    return Err("resource_limit: preparation waiter capacity".into());
                }
                flights.waiters += 1;
                (flight, false)
            } else {
                if flights.entries.len() >= self.capacity {
                    return Err("resource_limit: preparation capacity".into());
                }
                let flight = Arc::new(Flight {
                    request_hash,
                    result: Mutex::new(None),
                    ready: Condvar::new(),
                });
                flights.entries.insert(flight_key, Arc::clone(&flight));
                (flight, true)
            }
        };
        if !leader {
            let _waiter = Waiter(self);
            let mut result = flight
                .result
                .lock()
                .map_err(|_| "coordination_unavailable")?;
            while result.is_none() {
                result = flight
                    .ready
                    .wait(result)
                    .map_err(|_| "coordination_unavailable")?;
            }
            let outcome = result.as_ref().unwrap().clone();
            drop(result);
            outcome?;
            // A completed flight is not an authorization cache. Re-read the
            // durable receipt, including the current ownership/tombstone check.
            return self
                .registry()?
                .retry(principal, key, request)?
                .ok_or_else(|| "corrupt_object: completed flight lost its receipt".into());
        }
        let leader = Leader {
            owner: self,
            key: flight_key,
            flight,
        };
        let outcome = (|| {
            {
                let registry = self.registry()?;
                if let Some(receipt) = registry.retry(principal, key, request)? {
                    return Ok(receipt);
                }
                registry.begin(principal, request, &mut current)?;
            }
            let prepared = catch_unwind(AssertUnwindSafe(build))
                .map_err(|_| "builder_panicked: no version was published".to_string())??;
            self.registry()?
                .publish(principal, key, request, current, prepared)
        })();
        leader.finish(outcome.clone());
        outcome
    }
}
