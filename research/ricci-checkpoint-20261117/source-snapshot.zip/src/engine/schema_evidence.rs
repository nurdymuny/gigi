//! Preparation-time schema evidence, not source identity or freshness.
use crate::types::*;
use sha2::{Digest, Sha256};

const HEADER: &[u8] = b"GIGI-SOURCE-SCHEMA\x01";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SchemaEvidence {
    pub format_version: u8,
    pub sha256: [u8; 32],
    pub encoded_schema_bytes: u64,
}

/// Fingerprint exact plaintext declarations, excluding only the display name.
///
/// Does not establish semantic validity, durable identity, or freshness. Raw
/// encryption keys and encrypted schemas refuse until key-epoch binding exists.
/// Order and float bits are retained; no source records or environment values
/// are read. The caller must hold a consistent schema snapshot or read lease.
pub fn fingerprint_plain_schema(
    schema: &BundleSchema,
    max_bytes: usize,
) -> Result<SchemaEvidence, String> {
    if max_bytes == 0 || max_bytes > 16 * 1024 * 1024 {
        return Err("schema_evidence max_bytes must be in 1..=16777216".into());
    }
    // No '..': adding a native declaration must force an encoding review.
    let BundleSchema {
        name: _,
        base_fields,
        fiber_fields,
        indexed_fields,
        gauge_key,
        seed_source,
        order_field,
        retention,
        row_semantics,
        adjacencies,
        h1_threshold,
        invariants,
        #[cfg(feature = "kahler")]
        kahler,
    } = schema;
    if gauge_key.is_some() {
        return Err("schema_evidence gauge_key requires a durable key-epoch binding; encrypted sources unsupported".into());
    }
    if matches!(seed_source, EncryptionSeedSource::Hex(_)) {
        return Err("schema_evidence seed_source must not contain inline secret material".into());
    }
    let mut out = Encoder {
        state: Sha256::new(),
        bytes: 0,
        limit: max_bytes,
    };
    out.put(HEADER)?;
    out.fields(base_fields)?;
    out.fields(fiber_fields)?;
    out.strings(indexed_fields)?;
    out.tag(0)?; // Only absent gauge key is supported.
    match seed_source {
        EncryptionSeedSource::Random => out.tag(0)?,
        EncryptionSeedSource::Env(name) => {
            out.tag(2)?;
            out.string(name)?;
        }
        EncryptionSeedSource::Hex(_) => {
            return Err("schema_evidence seed_source unsupported".into())
        }
    }
    out.option_string(order_field)?;
    match retention {
        Retention::Undeclared => out.tag(0)?,
        Retention::Days(days) => {
            out.tag(1)?;
            out.put(&days.to_le_bytes())?;
        }
        Retention::Indefinite => out.tag(2)?,
    }
    out.tag(match row_semantics {
        RowSemantics::Unspecified => 0,
        RowSemantics::ClockSamples => 1,
        RowSemantics::DiscreteEvents => 2,
    })?;
    out.len(adjacencies.len())?;
    for adjacency in adjacencies {
        out.adjacency(adjacency)?;
    }
    out.float(*h1_threshold)?;
    out.len(invariants.len())?;
    for InvariantDef {
        expr_field,
        expected,
        tol,
    } in invariants
    {
        out.string(expr_field)?;
        out.float(*expected)?;
        out.float(*tol)?;
    }
    #[cfg(feature = "kahler")]
    match kahler {
        None => out.tag(0)?,
        Some(crate::geometry::KahlerStructure { j, b }) => {
            out.tag(1)?;
            out.len(j.dim())?;
            out.floats(j.matrix())?;
            out.len(b.dim())?;
            out.floats(b.form().matrix())?;
        }
    }
    #[cfg(not(feature = "kahler"))]
    out.tag(0)?;
    Ok(SchemaEvidence {
        format_version: 1,
        sha256: out.state.finalize().into(),
        encoded_schema_bytes: out.bytes as u64,
    })
}

struct Encoder {
    state: Sha256,
    bytes: usize,
    limit: usize,
}
impl Encoder {
    fn put(&mut self, bytes: &[u8]) -> Result<(), String> {
        let next = self
            .bytes
            .checked_add(bytes.len())
            .ok_or("schema_evidence encoded byte count overflow")?;
        if next > self.limit {
            return Err("schema_evidence encoded bytes exceed declared limit".into());
        }
        self.state.update(bytes);
        self.bytes = next;
        Ok(())
    }
    fn tag(&mut self, tag: u8) -> Result<(), String> {
        self.put(&[tag])
    }
    fn len(&mut self, len: usize) -> Result<(), String> {
        self.put(&(len as u64).to_le_bytes())
    }
    fn float(&mut self, value: f64) -> Result<(), String> {
        self.put(&value.to_bits().to_le_bytes())
    }
    fn blob(&mut self, bytes: &[u8]) -> Result<(), String> {
        self.len(bytes.len())?;
        self.put(bytes)
    }
    fn string(&mut self, text: &str) -> Result<(), String> {
        self.blob(text.as_bytes())
    }
    fn strings(&mut self, strings: &[String]) -> Result<(), String> {
        self.len(strings.len())?;
        for s in strings {
            self.string(s)?;
        }
        Ok(())
    }
    fn floats(&mut self, values: &[f64]) -> Result<(), String> {
        self.len(values.len())?;
        for v in values {
            self.float(*v)?;
        }
        Ok(())
    }
    fn option_string(&mut self, text: &Option<String>) -> Result<(), String> {
        match text {
            None => self.tag(0),
            Some(s) => {
                self.tag(1)?;
                self.string(s)
            }
        }
    }
    fn value(&mut self, value: &Value) -> Result<(), String> {
        match value {
            Value::Null => self.tag(0),
            Value::Integer(x) => {
                self.tag(1)?;
                self.put(&x.to_le_bytes())
            }
            Value::Float(x) => {
                self.tag(2)?;
                self.float(*x)
            }
            Value::Text(x) => {
                self.tag(3)?;
                self.string(x)
            }
            Value::Bool(x) => {
                self.tag(4)?;
                self.tag(u8::from(*x))
            }
            Value::Timestamp(x) => {
                self.tag(5)?;
                self.put(&x.to_le_bytes())
            }
            Value::Vector(x) => {
                self.tag(6)?;
                self.floats(x)
            }
            Value::Binary(x) => {
                self.tag(7)?;
                self.blob(x)
            }
        }
    }
    fn fields(&mut self, fields: &[FieldDef]) -> Result<(), String> {
        self.len(fields.len())?;
        for FieldDef {
            name,
            field_type,
            default,
            range,
            weight,
            encryption,
            encryption_group,
            unit,
        } in fields
        {
            if encryption.is_encrypted() {
                return Err(
                    "schema_evidence field encryption requires a durable key-epoch binding".into(),
                );
            }
            self.string(name)?;
            match field_type {
                FieldType::Numeric => self.tag(0)?,
                FieldType::Categorical => self.tag(1)?,
                FieldType::OrderedCat { order } => {
                    self.tag(2)?;
                    self.strings(order)?;
                }
                FieldType::Timestamp => self.tag(3)?,
                FieldType::Binary => self.tag(4)?,
                FieldType::Vector { dims } => {
                    self.tag(5)?;
                    self.len(*dims)?;
                }
            }
            self.value(default)?;
            match range {
                None => self.tag(0)?,
                Some(x) => {
                    self.tag(1)?;
                    self.float(*x)?;
                }
            }
            self.float(*weight)?;
            self.tag(0)?; // Only plaintext fields reach this point.
            self.option_string(encryption_group)?;
            self.option_string(unit)?;
        }
        Ok(())
    }
    fn adjacency(&mut self, adjacency: &AdjacencyDef) -> Result<(), String> {
        let AdjacencyDef { name, kind, weight } = adjacency;
        self.string(name)?;
        match kind {
            AdjacencyKind::Equality { field } => {
                self.tag(0)?;
                self.string(field)?;
            }
            AdjacencyKind::Metric { field, radius } => {
                self.tag(1)?;
                self.string(field)?;
                self.float(*radius)?;
            }
            AdjacencyKind::Threshold { field, threshold } => {
                self.tag(2)?;
                self.string(field)?;
                self.float(*threshold)?;
            }
            AdjacencyKind::Transform {
                source_field,
                target_field,
                transform,
            } => {
                self.tag(3)?;
                self.string(source_field)?;
                self.string(target_field)?;
                match transform {
                    TransformFn::Log10 => self.tag(0)?,
                    TransformFn::Scale { a, b } => {
                        self.tag(1)?;
                        self.float(*a)?;
                        self.float(*b)?;
                    }
                    TransformFn::Biofilm { lo, hi } => {
                        self.tag(2)?;
                        self.float(*lo)?;
                        self.float(*hi)?;
                    }
                }
            }
            AdjacencyKind::Morphism {
                source_bundle,
                join_field,
                quality,
            } => {
                self.tag(4)?;
                self.string(source_bundle)?;
                self.string(join_field)?;
                self.float(*quality)?;
            }
        }
        self.float(*weight)
    }
}
