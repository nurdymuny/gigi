//! Immutable analytic versions. Callers supply authoritative catalog snapshots.
use super::cache::ByteCache;
use super::{
    encoding,
    journal::Journal,
    prepared::{Answer, Prepared},
};
use base64::{engine::general_purpose::STANDARD, Engine as _};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{collections::HashMap, path::Path, sync::Arc};

pub const POLICY: &str = "gigi-analytic-binary64-v1";

/// An authoritative coherent catalog view. Engine adapters must hold their
/// read lock until this lease drops; owned vectors are for immutable catalogs.
pub trait SourceLease {
    fn revisions(&self) -> &[SourceRevision];
}
impl SourceLease for Vec<SourceRevision> {
    fn revisions(&self) -> &[SourceRevision] {
        self
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SourceRevision {
    pub bundle_id: String,
    pub incarnation: String,
    pub revision: u64,
    pub schema_digest: [u8; 32],
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SourceSnapshot {
    pub name: String,
    pub source: SourceRevision,
    pub content_digest: [u8; 32],
    pub records: u64,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Coordinates {
    pub input_units: String,
    pub output_units: String,
    pub meaning: String,
    pub chart: String,
    pub regime: String,
    pub normalization: String,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BuildRequest {
    pub object_id: Option<String>,
    pub expected_head: Option<String>,
    pub sources: Vec<SourceSnapshot>,
    pub coordinates: Coordinates,
    pub recipe: serde_json::Value,
    pub numerical_policy: String,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub format_version: u32,
    pub object_id: String,
    pub version_id: String,
    pub problem_hash: [u8; 32],
    pub representation_hash: [u8; 32],
    pub evidence_hash: [u8; 32],
    pub payload_hash: [u8; 32],
    pub sources: Vec<SourceSnapshot>,
    pub coordinates: Coordinates,
    pub recipe: serde_json::Value,
    pub numerical_policy: String,
    pub mathematical_status: String,
    pub information: super::prepared::InformationContract,
}
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Freshness {
    Pinned,
    RequireCurrent,
}
#[derive(Debug, Clone, Serialize)]
pub struct QueryReply {
    pub object_id: String,
    pub version_id: String,
    pub sources: Vec<SourceSnapshot>,
    pub freshness: String,
    pub mathematical_status: String,
    pub execution_mode: String,
    pub answers: Vec<Answer>,
}
#[derive(Serialize, Deserialize)]
#[serde(tag = "transaction", rename_all = "snake_case", deny_unknown_fields)]
enum Transaction {
    Publish {
        principal: String,
        key: String,
        request: BuildRequest,
        manifest: Manifest,
        payload: String,
    },
    Delete {
        principal: String,
        object_id: String,
    },
}
struct Object {
    principal: String,
    head: String,
    deleted: bool,
}
struct Version {
    manifest: Manifest,
    offset: u64,
}
struct Receipt {
    request_hash: [u8; 32],
    object: String,
    version: String,
}
pub struct Registry {
    journal: Journal,
    objects: HashMap<String, Object>,
    versions: HashMap<(String, String), Version>,
    receipts: HashMap<(String, String, String), Receipt>,
    representations: ByteCache<[u8; 32], Arc<Prepared>>,
    points: ByteCache<([u8; 32], [u64; 2]), Answer>,
}
fn canonical<T: Serialize>(value: &T) -> Result<Vec<u8>, String> {
    encoding::encode(&serde_json::to_value(value).map_err(|e| e.to_string())?)
}
pub(crate) fn hash<T: Serialize>(value: &T) -> Result<[u8; 32], String> {
    Ok(Sha256::digest(canonical(value)?).into())
}
fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

impl Registry {
    pub fn configure_caches(
        &mut self,
        representations: usize,
        points: usize,
    ) -> Result<(), String> {
        for size in [representations, points] {
            if size != 0 && size < 512 {
                return Err("resource_limit: nonzero cache budgets must be >=512 bytes".into());
            }
        }
        self.representations = ByteCache::new(representations);
        self.points = ByteCache::new(points);
        Ok(())
    }
    pub fn cache_usage(&self) -> [(usize, usize); 2] {
        [self.representations.usage(), self.points.usage()]
    }
    pub fn open(path: &Path, quota: u64) -> Result<Self, String> {
        let journal = Journal::open(path, quota).map_err(|e| e.to_string())?;
        let mut result = Self {
            journal,
            objects: HashMap::new(),
            versions: HashMap::new(),
            receipts: HashMap::new(),
            representations: ByteCache::new(64 * 1024 * 1024),
            points: ByteCache::new(16 * 1024 * 1024),
        };
        for offset in result.journal.offsets().to_vec() {
            let bytes = result.journal.read(offset).map_err(|e| e.to_string())?;
            let transaction: Transaction = serde_json::from_value(encoding::decode(&bytes)?)
                .map_err(|e| format!("corrupt_object: transaction: {e}"))?;
            result.apply(transaction, offset)?;
        }
        Ok(result)
    }
    pub(crate) fn validate_request(
        principal: &str,
        key: &str,
        request: &BuildRequest,
    ) -> Result<(), String> {
        if principal.is_empty() || principal.len() > 256 {
            return Err("invalid_principal".into());
        }
        if key.is_empty()
            || key.len() > 128
            || !key.is_ascii()
            || key.bytes().any(|b| b < 32 || b == 127)
        {
            return Err(
                "invalid_idempotency_key: provide 1..128 printable ASCII characters".into(),
            );
        }
        if request.numerical_policy != POLICY {
            return Err("unsupported_version: numerical_policy".into());
        }
        if request.sources.is_empty() || request.sources.len() > 8 {
            return Err("invalid_sources: provide 1..8 source snapshots".into());
        }
        for (index, source) in request.sources.iter().enumerate() {
            if source.name.is_empty()
                || source.name.len() > 256
                || uuid::Uuid::parse_str(&source.source.bundle_id).is_err()
                || uuid::Uuid::parse_str(&source.source.incarnation).is_err()
                || request.sources[..index]
                    .iter()
                    .any(|s| s.source.bundle_id == source.source.bundle_id)
            {
                return Err(
                    "invalid_sources: stable unique UUIDs and bounded names required".into(),
                );
            }
        }
        let c = &request.coordinates;
        for text in [
            &c.input_units,
            &c.output_units,
            &c.meaning,
            &c.chart,
            &c.regime,
            &c.normalization,
        ] {
            if text.is_empty() || text.len() > 256 {
                return Err(
                    "invalid_coordinates: nonempty metadata of at most 256 bytes required".into(),
                );
            }
        }
        if request.object_id.is_some() != request.expected_head.is_some() {
            return Err("invalid_head: new versions require object_id and expected_head".into());
        }
        if canonical(request)?.len() > 32 * 1024 {
            return Err("resource_limit: preparation metadata exceeds 32 KiB".into());
        }
        Ok(())
    }
    fn receipt_key(principal: &str, key: &str, request: &BuildRequest) -> (String, String, String) {
        (
            principal.into(),
            request.object_id.clone().unwrap_or_else(|| "new".into()),
            key.into(),
        )
    }
    fn authorize(&self, principal: &str, object: &str) -> Result<&Object, String> {
        let state = self
            .objects
            .get(object)
            .ok_or("not_found: analytic object")?;
        if state.principal != principal {
            return Err("forbidden: analytic object principal".into());
        }
        if state.deleted {
            return Err("gone: analytic object was deleted".into());
        }
        Ok(state)
    }
    fn check_head(&self, principal: &str, request: &BuildRequest) -> Result<(), String> {
        if let Some(id) = &request.object_id {
            let state = self.authorize(principal, id)?;
            if request.expected_head.as_ref() != Some(&state.head) {
                return Err("stale_head: expected head does not match".into());
            }
        }
        Ok(())
    }
    fn check_sources(expected: &[SourceSnapshot], actual: &[SourceRevision]) -> Result<(), String> {
        if expected.len() != actual.len() || expected.iter().any(|s| !actual.contains(&s.source)) {
            return Err(format!(
                "stale_source: expected {} ; current {}",
                serde_json::to_string(&expected.iter().map(|s| &s.source).collect::<Vec<_>>())
                    .unwrap(),
                serde_json::to_string(actual).unwrap()
            ));
        }
        Ok(())
    }
    fn manifest(
        object: String,
        request: &BuildRequest,
        prepared: &Prepared,
    ) -> Result<Manifest, String> {
        let problem_hash = hash(request)?;
        let representation_hash = prepared.representation_hash()?;
        let evidence_hash = hash(prepared.evidence())?;
        let payload_hash = Sha256::digest(prepared.encode()?).into();
        let version_id = hex(&hash(&(
            1u32,
            &object,
            problem_hash,
            representation_hash,
            evidence_hash,
        ))?);
        let manifest = Manifest {
            format_version: 1,
            object_id: object,
            version_id,
            problem_hash,
            representation_hash,
            evidence_hash,
            payload_hash,
            sources: request.sources.clone(),
            coordinates: request.coordinates.clone(),
            recipe: request.recipe.clone(),
            numerical_policy: POLICY.into(),
            mathematical_status: prepared.evidence()["status"]
                .as_str()
                .ok_or("invalid model status")?
                .into(),
            information: prepared.information().clone(),
        };
        if canonical(&manifest)?.len() > 64 * 1024 {
            return Err("resource_limit: manifest exceeds 64 KiB".into());
        }
        Ok(manifest)
    }
    fn apply(&mut self, transaction: Transaction, offset: u64) -> Result<(), String> {
        match transaction {
            Transaction::Publish {
                principal,
                key,
                request,
                manifest,
                payload,
            } => {
                Self::validate_request(&principal, &key, &request)?;
                self.check_head(&principal, &request)?;
                if uuid::Uuid::parse_str(&manifest.object_id).is_err()
                    || (request.object_id.is_none()
                        && self.objects.contains_key(&manifest.object_id))
                    || request
                        .object_id
                        .as_ref()
                        .is_some_and(|id| id != &manifest.object_id)
                {
                    return Err("corrupt_object: object identity".into());
                }
                let bytes = STANDARD
                    .decode(payload)
                    .map_err(|_| "corrupt_object: stored payload encoding")?;
                let model = Prepared::restore(&bytes, &manifest.payload_hash)?;
                let expected = Self::manifest(manifest.object_id.clone(), &request, &model)?;
                if canonical(&expected)? != canonical(&manifest)? {
                    return Err("corrupt_object: manifest and mathematical payload disagree".into());
                }
                let receipt_key = Self::receipt_key(&principal, &key, &request);
                let version_key = (manifest.object_id.clone(), manifest.version_id.clone());
                if self.receipts.contains_key(&receipt_key)
                    || self.versions.contains_key(&version_key)
                {
                    return Err("corrupt_object: duplicate publication".into());
                }
                self.receipts.insert(
                    receipt_key,
                    Receipt {
                        request_hash: hash(&request)?,
                        object: manifest.object_id.clone(),
                        version: manifest.version_id.clone(),
                    },
                );
                self.objects.insert(
                    manifest.object_id.clone(),
                    Object {
                        principal,
                        head: manifest.version_id.clone(),
                        deleted: false,
                    },
                );
                self.versions
                    .insert(version_key, Version { manifest, offset });
            }
            Transaction::Delete {
                principal,
                object_id,
            } => {
                self.authorize(&principal, &object_id)?;
                self.objects.get_mut(&object_id).unwrap().deleted = true;
            }
        }
        Ok(())
    }
    pub(crate) fn retry(
        &self,
        principal: &str,
        key: &str,
        request: &BuildRequest,
    ) -> Result<Option<Manifest>, String> {
        Self::validate_request(principal, key, request)?;
        if let Some(receipt) = self
            .receipts
            .get(&Self::receipt_key(principal, key, request))
        {
            self.authorize(principal, &receipt.object)?;
            if receipt.request_hash != hash(request)? {
                return Err("idempotency_conflict: key is bound to a different request".into());
            }
            return Ok(Some(
                self.versions
                    .get(&(receipt.object.clone(), receipt.version.clone()))
                    .ok_or("corrupt_object: lost receipt version")?
                    .manifest
                    .clone(),
            ));
        }
        Ok(None)
    }
    pub(crate) fn begin<L: SourceLease>(
        &self,
        principal: &str,
        request: &BuildRequest,
        mut current: impl FnMut() -> Result<L, String>,
    ) -> Result<(), String> {
        Self::check_sources(&request.sources, current()?.revisions())?;
        self.check_head(principal, request)
    }
    pub(crate) fn publish<L: SourceLease>(
        &mut self,
        principal: &str,
        key: &str,
        request: &BuildRequest,
        mut current: impl FnMut() -> Result<L, String>,
        prepared: Prepared,
    ) -> Result<Manifest, String> {
        if let Some(receipt) = self.retry(principal, key, request)? {
            return Ok(receipt);
        }
        let object = request
            .object_id
            .clone()
            .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
        let manifest = Self::manifest(object, request, &prepared)?;
        let payload = prepared.encode()?;
        Prepared::restore(&payload, &manifest.payload_hash)?;
        let transaction = Transaction::Publish {
            principal: principal.into(),
            key: key.into(),
            request: request.clone(),
            manifest: manifest.clone(),
            payload: STANDARD.encode(payload),
        };
        let transaction_bytes = canonical(&transaction)?;
        let publication_lease = current()?;
        Self::check_sources(&request.sources, publication_lease.revisions())?;
        self.check_head(principal, request)?;
        let offset = self
            .journal
            .append(&transaction_bytes)
            .map_err(|e| e.to_string())?;
        self.apply(transaction, offset)?;
        drop(publication_lease);
        Ok(manifest)
    }
    pub fn prepare<L: SourceLease>(
        &mut self,
        principal: &str,
        key: &str,
        request: &BuildRequest,
        mut current: impl FnMut() -> Result<L, String>,
        build: impl FnOnce() -> Result<Prepared, String>,
    ) -> Result<Manifest, String> {
        if let Some(receipt) = self.retry(principal, key, request)? {
            return Ok(receipt);
        }
        self.begin(principal, request, &mut current)?;
        let prepared = build()?;
        self.publish(principal, key, request, current, prepared)
    }
    pub fn query(
        &mut self,
        principal: &str,
        object: &str,
        version: &str,
        freshness: Freshness,
        operation: &str,
        points: &[[f64; 2]],
        current: Option<&[SourceRevision]>,
    ) -> Result<QueryReply, String> {
        let state = self.authorize(principal, object)?;
        let stored = self
            .versions
            .get(&(object.into(), version.into()))
            .ok_or("not_found: analytic version")?;
        if let Freshness::RequireCurrent = freshness {
            Self::check_sources(
                &stored.manifest.sources,
                current
                    .ok_or("source_state_unavailable: authoritative catalog metadata required")?,
            )?;
            if state.head != version {
                return Err("stale_head: requested version is not current".into());
            }
        }
        if !stored
            .manifest
            .information
            .operations
            .iter()
            .any(|name| name == operation)
        {
            return Err("unsupported_operation: not available for this model class".into());
        }
        let sources = stored.manifest.sources.clone();
        let mathematical_status = stored.manifest.mathematical_status.clone();
        let payload_hash = stored.manifest.payload_hash;
        let offset = stored.offset;
        Prepared::validate_points(points)?;
        let canonical_points: Vec<_> = points
            .iter()
            .map(|z| z.map(|x| if x == 0. { 0. } else { x }))
            .collect();
        // Operation and immutable version (which binds policy/coordinates) are
        // both hashed into this fixed-size exact-key prefix.
        let version_key = hash(&(version, operation))?;
        let keys: Vec<_> = canonical_points
            .iter()
            .map(|z| (version_key, z.map(f64::to_bits)))
            .collect();
        let mut answers: Vec<Option<Answer>> = keys
            .iter()
            .map(|key| self.points.get(key).cloned())
            .collect();
        let missing: Vec<_> = answers
            .iter()
            .enumerate()
            .filter_map(|(i, a)| a.is_none().then_some(i))
            .collect();
        let mut execution_mode = "point_cache_hit";
        if !missing.is_empty() {
            let prepared = if let Some(model) = self.representations.get(&version_key) {
                execution_mode = "prepared_evaluation";
                Arc::clone(model)
            } else {
                execution_mode = "cold_object_load";
                let transaction: Transaction = serde_json::from_value(encoding::decode(
                    &self.journal.read(offset).map_err(|e| e.to_string())?,
                )?)
                .map_err(|e| format!("corrupt_object: {e}"))?;
                let Transaction::Publish { payload, .. } = transaction else {
                    return Err("corrupt_object: wrong frame kind".into());
                };
                let bytes = STANDARD
                    .decode(payload)
                    .map_err(|_| "corrupt_object: payload encoding")?;
                let model = Arc::new(Prepared::restore(&bytes, &payload_hash)?);
                self.representations
                    .insert(version_key, Arc::clone(&model), model.heap_charge());
                model
            };
            let requested: Vec<_> = missing.iter().map(|&i| canonical_points[i]).collect();
            let resolved = prepared.query(&requested)?;
            // No point entry is published until the whole batch succeeds.
            for (index, answer) in missing.into_iter().zip(resolved) {
                self.points.insert(keys[index], answer.clone(), 0);
                answers[index] = Some(answer);
            }
        }
        let answers = answers
            .into_iter()
            .map(|a| a.expect("resolved or cached point"))
            .collect();
        Ok(QueryReply {
            object_id: object.into(),
            version_id: version.into(),
            sources,
            freshness: match freshness {
                Freshness::Pinned => "historical_snapshot",
                Freshness::RequireCurrent => "current_at_snapshot",
            }
            .into(),
            mathematical_status,
            execution_mode: execution_mode.into(),
            answers,
        })
    }
    pub fn delete(&mut self, principal: &str, object: &str) -> Result<(), String> {
        self.authorize(principal, object)?;
        let transaction = Transaction::Delete {
            principal: principal.into(),
            object_id: object.into(),
        };
        let offset = self
            .journal
            .append(&canonical(&transaction)?)
            .map_err(|e| e.to_string())?;
        self.apply(transaction, offset)
    }
}
