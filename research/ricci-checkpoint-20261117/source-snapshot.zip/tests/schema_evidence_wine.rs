//! Executed by verify_schema_evidence_wine.py with the pinned archive.
use gigi::engine::{
    schema_evidence::fingerprint_plain_schema,
    source_evidence::{fingerprint_records, ContentLimits},
    Engine,
};
use gigi::metric::FiberMetric;
use gigi::types::*;
use serde::Deserialize;
use serde_json::json;

#[derive(Deserialize)]
struct Input {
    fields: Vec<String>,
    ranges_bits: Vec<u64>,
    reference_id: String,
    rows: Vec<Row>,
}
#[derive(Deserialize)]
struct Row {
    id: String,
    kind: String,
    bits: Vec<u64>,
}
fn hex(x: &[u8]) -> String {
    x.iter().map(|b| format!("{b:02x}")).collect()
}
fn stage(engine: &Engine, reference: &str) -> serde_json::Value {
    let store = engine.heap_bundle("schema_wine").unwrap();
    let schema = &store.schema;
    let rows: Vec<_> = store.records().collect();
    let content = fingerprint_records(&rows, ContentLimits::default()).unwrap();
    let e = fingerprint_plain_schema(schema, 1024 * 1024).unwrap();
    let engine_map =
        fingerprint_plain_schema(engine.bundle_schema("schema_wine").unwrap(), 1024 * 1024)
            .unwrap();
    let source = rows
        .iter()
        .find(|r| r["id"] == Value::Text(reference.into()))
        .unwrap();
    let a: Vec<_> = schema
        .fiber_fields
        .iter()
        .map(|f| source[&f.name].clone())
        .collect();
    let mut distances: Vec<_> = rows
        .iter()
        .map(|row| {
            let b: Vec<_> = schema
                .fiber_fields
                .iter()
                .map(|f| row[&f.name].clone())
                .collect();
            (
                row["id"].as_str().unwrap().to_owned(),
                FiberMetric::distance(&schema.fiber_fields, &a, &b),
            )
        })
        .collect();
    distances.sort_by(|a, b| a.0.cmp(&b.0));
    json!({"schema_sha256": hex(&e.sha256), "schema_bytes": e.encoded_schema_bytes,
        "engine_schema_sha256": hex(&engine_map.sha256), "content_sha256": hex(&content.sha256),
        "records": rows.len(), "distances": distances})
}

#[test]
#[ignore = "requires pinned wine archive and independent schema/metric oracle"]
fn wine_schema_evidence_showcase() {
    let input: Input = serde_json::from_reader(
        std::fs::File::open(std::env::var("GIGI_SCHEMA_INPUT").unwrap()).unwrap(),
    )
    .unwrap();
    assert_eq!(input.rows.len(), 6497);
    assert_eq!(input.fields.len(), 12);
    let temp = tempfile::tempdir().unwrap();
    let mut engine = Engine::open(temp.path()).unwrap();
    engine.compaction_policy_mut().disabled = true;
    let mut schema = BundleSchema::new("schema_wine")
        .base(FieldDef::categorical("id"))
        .fiber(FieldDef::categorical("kind"));
    for (name, bits) in input.fields.iter().zip(&input.ranges_bits) {
        let mut field = FieldDef::numeric(name).with_range(f64::from_bits(*bits));
        if name == "alcohol" {
            field.unit = Some("% vol".into());
        }
        schema = schema.fiber(field);
    }
    let original_schema = schema.clone();
    engine.create_bundle(schema).unwrap();
    let rows: Vec<Record> = input
        .rows
        .iter()
        .map(|row| {
            let mut record: Record = [
                ("id".into(), Value::Text(row.id.clone())),
                ("kind".into(), Value::Text(row.kind.clone())),
            ]
            .into_iter()
            .collect();
            for (name, bits) in input.fields.iter().zip(&row.bits) {
                record.insert(name.clone(), Value::Float(f64::from_bits(*bits)));
            }
            record
        })
        .collect();
    engine.batch_insert("schema_wine", &rows).unwrap();
    engine.checkpoint().unwrap();
    let original = stage(&engine, &input.reference_id);
    let alcohol = original_schema.fiber_field_index("alcohol").unwrap();
    engine
        .heap_bundle_mut("schema_wine")
        .unwrap()
        .schema
        .fiber_fields[alcohol]
        .weight = 4.0;
    let weighted = stage(&engine, &input.reference_id);
    engine.heap_bundle_mut("schema_wine").unwrap().schema = original_schema.clone();
    engine
        .heap_bundle_mut("schema_wine")
        .unwrap()
        .schema
        .fiber_fields[alcohol]
        .range = Some(original_schema.fiber_fields[alcohol].range.unwrap() / 2.0);
    let scaled = stage(&engine, &input.reference_id);
    engine.heap_bundle_mut("schema_wine").unwrap().schema = original_schema.clone();
    engine
        .heap_bundle_mut("schema_wine")
        .unwrap()
        .schema
        .fiber_fields[alcohol]
        .unit = Some("fraction".into());
    let unit_only = stage(&engine, &input.reference_id);
    engine.heap_bundle_mut("schema_wine").unwrap().schema = original_schema.clone();
    {
        let store = engine.heap_bundle_mut("schema_wine").unwrap();
        store.schema.h1_threshold = 2.5;
        store.schema.adjacencies.push(AdjacencyDef {
            name: "same_kind".into(),
            kind: AdjacencyKind::Equality {
                field: "kind".into(),
            },
            weight: 0.75,
        });
    }
    let geometric = stage(&engine, &input.reference_id);
    // Direct edits above were deliberately not journaled. Do not snapshot them.
    drop(engine);
    let engine = Engine::open(temp.path()).unwrap();
    let reopened = stage(&engine, &input.reference_id);
    assert_eq!(original, reopened);
    for changed in [&weighted, &scaled, &unit_only, &geometric] {
        assert_eq!(original["content_sha256"], changed["content_sha256"]);
        assert_ne!(original["schema_sha256"], changed["schema_sha256"]);
        assert_eq!(original["schema_sha256"], changed["engine_schema_sha256"]);
    }
    let output = json!({"original": original, "weighted": weighted, "scaled": scaled,
        "unit_only": unit_only, "geometric": geometric, "reopened": reopened});
    std::fs::write(
        std::env::var("GIGI_SCHEMA_REPORT").unwrap(),
        serde_json::to_vec(&output).unwrap(),
    )
    .unwrap();
}
