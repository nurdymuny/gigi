//! Explicit SI passive RC networks. See docs/CONDUCT_SETTLE_SPEC.md.
use crate::sheaf::laplacian::{build_laplacian, SheafEdge};
use nalgebra::{DMatrix, DVector};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Node {
    pub id: String,
    pub capacitance_f: f64,
    pub voltage_v: f64,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Edge {
    pub source: String,
    pub target: String,
    pub conductance_s: f64,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Port {
    pub node: String,
    pub conductance_s: f64,
    pub voltage_v: f64,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Configuration {
    pub edges: Vec<Edge>,
    pub ports: Vec<Port>,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Phase {
    pub duration_s: f64,
    pub configuration: Configuration,
}
#[derive(Clone, Debug, Serialize)]
pub struct Sample {
    pub time_s: f64,
    pub phase_index: usize,
    pub voltages_v: Vec<f64>,
    pub edge_currents_a: Vec<f64>,
    pub port_currents_a: Vec<f64>,
    pub stored_j: f64,
    pub dissipated_j: f64,
    pub supplied_j: f64,
    pub dissipated_w: f64,
    pub supplied_w: f64,
    pub balance_residual_j: f64,
}
#[derive(Clone, Debug, Serialize)]
pub struct ConductResult {
    pub node_order: Vec<String>,
    pub initial_stored_j: f64,
    pub samples: Vec<Sample>,
    pub method: &'static str,
}
#[derive(Clone, Debug, Serialize)]
pub struct SettleResult {
    pub node_order: Vec<String>,
    pub equilibrium_v: Vec<f64>,
    pub readout_equilibrium_v: f64,
    pub envelope_initial_v: f64,
    pub envelope_at_deadline_v: f64,
    pub settling_bound_s: f64,
    pub meets_deadline: bool,
    pub positive_rates_per_s: Vec<f64>,
    pub method: &'static str,
    pub guarantee: &'static str,
}

fn finite_range(x: f64, lo: f64, hi: f64, name: &str) -> Result<(), String> {
    if !x.is_finite() || x < lo || x > hi {
        return Err(format!("{name} requires a finite value in [{lo}, {hi}]; provide SI measurements within the numerical operating range"));
    }
    Ok(())
}

fn canonical(nodes: &[Node]) -> Result<Vec<Node>, String> {
    if nodes.is_empty() || nodes.len() > 32 {
        return Err("provide 1..32 storage nodes; no sampling is performed".into());
    }
    let mut nodes = nodes.to_vec();
    nodes.sort_by(|a, b| a.id.cmp(&b.id));
    for (i, node) in nodes.iter().enumerate() {
        if node.id.is_empty() || node.id.len() > 128 || (i > 0 && nodes[i - 1].id == node.id) {
            return Err("node IDs must be unique nonempty strings of at most 128 bytes".into());
        }
        finite_range(node.capacitance_f, 1e-15, 1e6, "capacitance_f")?;
        finite_range(node.voltage_v, -1e6, 1e6, "voltage_v")?;
    }
    Ok(nodes)
}

struct Prepared {
    initial: DVector<f64>,
    rates: Vec<f64>,
    equilibrium: DVector<f64>,
    modes: DMatrix<f64>,
    edges: Vec<(usize, usize, f64)>,
    ports: Vec<(usize, f64, f64)>,
}

impl Prepared {
    fn new(nodes: &[Node], config: &Configuration, initial: &DVector<f64>) -> Result<Self, String> {
        let n = nodes.len();
        if config.edges.len() > 128 || config.ports.len() > 128 {
            return Err("limit each configuration to 128 edges and 128 ports".into());
        }
        let index = |id: &str| {
            nodes
                .iter()
                .position(|node| node.id == id)
                .ok_or_else(|| format!("unknown node '{id}'; use an ID present in the node bundle"))
        };
        let mut edges = vec![];
        let mut ports = vec![];
        let mut sheaf = vec![];
        let mut adjacency = vec![vec![]; n];
        let mut anchored = vec![false; n];
        for edge in &config.edges {
            let i = index(&edge.source)?;
            let j = index(&edge.target)?;
            if i == j {
                return Err("self edges are not supported; remove the edge".into());
            }
            finite_range(edge.conductance_s, 0., 1e12, "conductance_s")?;
            edges.push((i, j, edge.conductance_s));
            sheaf.push(SheafEdge {
                src: i,
                tgt: j,
                weight: edge.conductance_s,
                restriction: 1.,
            });
            if edge.conductance_s > 0. {
                adjacency[i].push(j);
                adjacency[j].push(i);
            }
        }
        let mut k = build_laplacian(n, &sheaf);
        let mut f = DVector::zeros(n);
        for port in &config.ports {
            let i = index(&port.node)?;
            finite_range(port.conductance_s, 0., 1e12, "conductance_s")?;
            finite_range(port.voltage_v, -1e6, 1e6, "source voltage_v")?;
            k[(i, i)] += port.conductance_s;
            f[i] += port.conductance_s * port.voltage_v;
            anchored[i] |= port.conductance_s > 0.;
            ports.push((i, port.conductance_s, port.voltage_v));
        }
        // Topology fixes the nullity. A slow physical mode is never rounded away.
        let mut visited = vec![false; n];
        let mut nullity = 0;
        for start in 0..n {
            if visited[start] {
                continue;
            }
            visited[start] = true;
            let mut stack = vec![start];
            let mut has_port = false;
            while let Some(i) = stack.pop() {
                has_port |= anchored[i];
                for &j in &adjacency[i] {
                    if !visited[j] {
                        visited[j] = true;
                        stack.push(j);
                    }
                }
            }
            if !has_port {
                nullity += 1;
            }
        }
        let inv_sqrt =
            DVector::from_iterator(n, nodes.iter().map(|node| 1. / node.capacitance_f.sqrt()));
        let a = DMatrix::from_fn(n, n, |i, j| k[(i, j)] * inv_sqrt[i] * inv_sqrt[j]);
        let a_norm = a.norm();
        let eig = nalgebra::linalg::SymmetricEigen::try_new(a.clone(), f64::EPSILON, 10000)
            .ok_or("numerically unresolved spectrum; rescale or simplify the network")?;
        let mut order: Vec<_> = (0..n).collect();
        order.sort_by(|&i, &j| eig.eigenvalues[i].total_cmp(&eig.eigenvalues[j]));
        let max_rate = eig.eigenvalues.iter().copied().fold(0_f64, f64::max);
        let forcing = f.component_mul(&inv_sqrt);
        let initial_q = initial.component_div(&inv_sqrt);
        let mut equilibrium = DVector::zeros(n);
        let mut mode_columns = vec![];
        let mut rates = vec![];
        for (rank, &j) in order.iter().enumerate() {
            let lambda = eig.eigenvalues[j];
            let q = eig.eigenvectors.column(j).into_owned();
            if !lambda.is_finite()
                || (&a * &q - &q * lambda).norm() > 1e-10 * a_norm.max(f64::MIN_POSITIVE)
            {
                return Err(
                    "numerically unresolved eigenpair; reduce the network condition number".into(),
                );
            }
            let q0 = q.dot(&initial_q);
            let projected = q.dot(&forcing);
            if rank < nullity {
                if lambda.abs() > 1e-10 * max_rate || projected.abs() > 1e-10 * forcing.norm() {
                    return Err("numerically unresolved conserved mode".into());
                }
                equilibrium += q.component_mul(&inv_sqrt) * q0;
            } else {
                if lambda <= 1e-12 * max_rate {
                    return Err(
                        "numerically unresolved positive mode; do not interpret it as conserved"
                            .into(),
                    );
                }
                let eq = projected / lambda;
                equilibrium += q.component_mul(&inv_sqrt) * eq;
                mode_columns.push(q.component_mul(&inv_sqrt) * (q0 - eq));
                rates.push(lambda);
            }
        }
        let modes = if mode_columns.is_empty() {
            DMatrix::zeros(n, 0)
        } else {
            DMatrix::from_columns(&mode_columns)
        };
        let reconstructed = &equilibrium + &modes * DVector::from_element(rates.len(), 1.);
        if (&reconstructed - initial).norm()
            > 1e-10 * initial.norm().max(equilibrium.norm()).max(1e-300)
            || (&k * &equilibrium - &f).norm()
                > 1e-9 * (k.norm() * equilibrium.norm() + f.norm()).max(1e-300)
            || !equilibrium
                .iter()
                .chain(modes.iter())
                .all(|x| x.is_finite())
        {
            return Err(
                "numerically unresolved initial state or equilibrium; rescale the network".into(),
            );
        }
        Ok(Self {
            initial: initial.clone(),
            rates,
            equilibrium,
            modes,
            edges,
            ports,
        })
    }

    fn at(&self, t: f64) -> DVector<f64> {
        // Preserve tiny transients and exact initial values without subtracting
        // nearly equal equilibrium-sized numbers. Use the equilibrium form late.
        if self.rates.iter().all(|rate| rate * t <= 0.5) {
            return &self.initial
                + &self.modes
                    * DVector::from_iterator(
                        self.rates.len(),
                        self.rates.iter().map(|l| (-l * t).exp_m1()),
                    );
        }
        &self.equilibrium
            + &self.modes
                * DVector::from_iterator(
                    self.rates.len(),
                    self.rates.iter().map(|l| (-l * t).exp()),
                )
    }
    fn integrals(&self, t: f64) -> (f64, f64) {
        let mut dissipated = 0.;
        let mut supplied = 0.;
        for &(i, j, g) in &self.edges {
            let d = self.equilibrium[i] - self.equilibrium[j];
            let modes: Vec<_> = (0..self.rates.len())
                .map(|a| self.modes[(i, a)] - self.modes[(j, a)])
                .collect();
            dissipated += g * integral_square(d, &modes, &self.rates, t);
        }
        for &(i, g, u) in &self.ports {
            let d = u - self.equilibrium[i];
            let modes: Vec<_> = (0..self.rates.len()).map(|a| -self.modes[(i, a)]).collect();
            dissipated += g * integral_square(d, &modes, &self.rates, t);
            supplied += u
                * g
                * (d * t
                    + modes
                        .iter()
                        .zip(&self.rates)
                        .map(|(m, l)| m * decay_integral(*l, t))
                        .sum::<f64>());
        }
        (dissipated, supplied)
    }
}

fn decay_integral(rate: f64, t: f64) -> f64 {
    if rate == 0. {
        t
    } else {
        -(-rate * t).exp_m1() / rate
    }
}
fn integral_square(constant: f64, modes: &[f64], rates: &[f64], t: f64) -> f64 {
    let mut result = constant * constant * t;
    for (i, &a) in modes.iter().enumerate() {
        result += 2. * constant * a * decay_integral(rates[i], t);
        for (j, &b) in modes.iter().enumerate() {
            result += a * b * decay_integral(rates[i] + rates[j], t);
        }
    }
    result
}
fn energy(nodes: &[Node], v: &DVector<f64>) -> f64 {
    nodes
        .iter()
        .zip(v.iter())
        .map(|(n, x)| 0.5 * n.capacitance_f * x * x)
        .sum()
}

pub fn conduct(nodes: &[Node], phases: &[Phase], times: &[f64]) -> Result<ConductResult, String> {
    let nodes = canonical(nodes)?;
    if phases.is_empty() || phases.len() > 64 || times.is_empty() || times.len() > 2048 {
        return Err("provide 1..64 phases and 1..2048 strictly increasing output times".into());
    }
    let mut ends = vec![];
    let mut total = 0.;
    for p in phases {
        finite_range(p.duration_s, 1e-15, 1e9, "duration_s")?;
        let next = total + p.duration_s;
        if next <= total || next > 1e9 {
            return Err(
                "phase boundaries must be distinguishable and total duration <=1e9 seconds".into(),
            );
        }
        total = next;
        ends.push(total);
    }
    for (i, &t) in times.iter().enumerate() {
        finite_range(t, 0., total, "sample_times_s")?;
        if i > 0 && t <= times[i - 1] {
            return Err(
                "sample_times_s must be strictly increasing; remove duplicate or reversed times"
                    .into(),
            );
        }
    }
    let initial = DVector::from_iterator(nodes.len(), nodes.iter().map(|n| n.voltage_v));
    let initial_stored_j = energy(&nodes, &initial);
    let mut v = initial;
    let mut start = 0.;
    let mut lost = 0.;
    let mut input = 0.;
    let mut prepared = vec![];
    // Prepare every event, including those after the last requested output, so
    // invalid later configurations cannot hide behind an early sample request.
    for (index, p) in phases.iter().enumerate() {
        let model = Prepared::new(&nodes, &p.configuration, &v)?;
        let (d, w) = model.integrals(p.duration_s);
        v = model.at(p.duration_s);
        prepared.push((start, lost, input, model));
        lost += d;
        input += w;
        start = ends[index];
        if !lost.is_finite() || !input.is_finite() {
            return Err(
                "nonfinite energy integral; shorten duration or rescale the circuit".into(),
            );
        }
    }
    let mut samples = vec![];
    for &time in times {
        let index = ends.iter().position(|&end| time <= end).unwrap();
        let (start, d0, w0, model) = &prepared[index];
        let t = time - start;
        let v = model.at(t);
        let (d, w) = model.integrals(t);
        let dissipated_j = d0 + d;
        let supplied_j = w0 + w;
        let stored_j = energy(&nodes, &v);
        let edge_currents_a: Vec<_> = model
            .edges
            .iter()
            .map(|&(i, j, g)| g * (v[i] - v[j]))
            .collect();
        let port_currents_a: Vec<_> = model
            .ports
            .iter()
            .map(|&(i, g, u)| g * (u - v[i]))
            .collect();
        let dissipated_w = model
            .edges
            .iter()
            .map(|&(i, j, g)| g * (v[i] - v[j]).powi(2))
            .sum::<f64>()
            + model
                .ports
                .iter()
                .map(|&(i, g, u)| g * (u - v[i]).powi(2))
                .sum::<f64>();
        let supplied_w = model
            .ports
            .iter()
            .map(|&(i, g, u)| u * g * (u - v[i]))
            .sum();
        let balance_residual_j = stored_j - initial_stored_j + dissipated_j - supplied_j;
        let scale = stored_j.abs() + initial_stored_j.abs() + dissipated_j.abs() + supplied_j.abs();
        if balance_residual_j.abs() > 1e-8 * scale.max(1e-300)
            || dissipated_j < -1e-10 * scale.max(1e-300)
        {
            return Err(
                "numerically unresolved energy balance; rescale the circuit or shorten phases"
                    .into(),
            );
        }
        if !v
            .iter()
            .chain(edge_currents_a.iter())
            .chain(port_currents_a.iter())
            .chain([
                &stored_j,
                &dissipated_j,
                &supplied_j,
                &dissipated_w,
                &supplied_w,
                &balance_residual_j,
            ])
            .all(|x| x.is_finite())
        {
            return Err("nonfinite physical result; rescale the circuit".into());
        }
        samples.push(Sample {
            time_s: time,
            phase_index: index,
            voltages_v: v.as_slice().to_vec(),
            edge_currents_a,
            port_currents_a,
            stored_j,
            dissipated_j,
            supplied_j,
            dissipated_w,
            supplied_w,
            balance_residual_j,
        });
    }
    Ok(ConductResult {
        node_order: nodes.iter().map(|n| n.id.clone()).collect(),
        initial_stored_j,
        samples,
        method: "passive_rc_modal_v1",
    })
}

pub fn settle(
    nodes: &[Node],
    config: &Configuration,
    readout: &BTreeMap<String, f64>,
    tolerance: f64,
    deadline: f64,
) -> Result<SettleResult, String> {
    let nodes = canonical(nodes)?;
    finite_range(tolerance, 1e-12, 1e6, "tolerance_v")?;
    finite_range(deadline, 0., 1e9, "deadline_s")?;
    if readout.is_empty() || readout.len() > 32 {
        return Err("provide a nonzero readout with at most 32 node weights".into());
    }
    let mut c = DVector::zeros(nodes.len());
    for (id, &weight) in readout {
        finite_range(weight, -1e6, 1e6, "readout weight")?;
        let i = nodes
            .iter()
            .position(|n| n.id == *id)
            .ok_or_else(|| format!("unknown readout node '{id}'; use a node in the bundle"))?;
        c[i] = weight;
    }
    if c.norm() == 0. {
        return Err("readout must contain a nonzero weight".into());
    }
    let initial = DVector::from_iterator(nodes.len(), nodes.iter().map(|n| n.voltage_v));
    let model = Prepared::new(&nodes, config, &initial)?;
    let amplitudes: Vec<_> = (0..model.rates.len())
        .map(|i| c.dot(&model.modes.column(i)).abs())
        .collect();
    let envelope = |t: f64| {
        amplitudes
            .iter()
            .zip(&model.rates)
            .map(|(a, l)| a * (-l * t).exp())
            .sum::<f64>()
    };
    let envelope_initial_v = envelope(0.);
    let envelope_at_deadline_v = envelope(deadline);
    let mut upper = 0.;
    if envelope_initial_v > tolerance {
        let min_rate = model.rates.iter().copied().fold(f64::INFINITY, f64::min);
        upper = (envelope_initial_v / tolerance).ln() / min_rate;
        if !upper.is_finite() {
            return Err("numerically unresolved settling time".into());
        }
        // An upward slack keeps the upper bracket on the satisfying side.
        upper = upper * (1. + 1e-12) + f64::MIN_POSITIVE;
        let mut lower = 0.;
        for _ in 0..100 {
            let mid = lower + (upper - lower) / 2.;
            if envelope(mid) > tolerance {
                lower = mid;
            } else {
                upper = mid;
            }
        }
    }
    Ok(SettleResult{node_order:nodes.iter().map(|n|n.id.clone()).collect(),equilibrium_v:model.equilibrium.as_slice().to_vec(),readout_equilibrium_v:c.dot(&model.equilibrium),envelope_initial_v,envelope_at_deadline_v,settling_bound_s:upper,meets_deadline:envelope_at_deadline_v<=tolerance,positive_rates_per_s:model.rates,method:"absolute_modal_envelope_v1",guarantee:"Numerical evaluation of an all-future bound for this fixed passive RC model only; not an interval certificate, observed settling time, or guarantee after another switch."})
}
