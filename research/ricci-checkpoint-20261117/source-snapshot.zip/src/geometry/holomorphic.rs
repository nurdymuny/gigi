//! Bounded scalar holomorphic interpolation on the disk. See the scoped spec.
use nalgebra::{Complex, DMatrix, SymmetricEigen};
use serde::Serialize;

type C = Complex<f64>;
const TOL: f64 = 1e-10;
const MARGIN: f64 = 1e-8;
fn c(p: Point) -> C {
    C::new(p[0], p[1])
}
fn p(z: C) -> Point {
    [z.re, z.im]
}
fn finite(z: C) -> bool {
    z.re.is_finite() && z.im.is_finite()
}
fn phi(a: C, z: C) -> C {
    (z - a) / (C::new(1., 0.) - a.conj() * z)
}

pub type Point = [f64; 2];

#[derive(Debug, Clone, Copy, Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Observation {
    pub z: Point,
    pub value: Point,
}

#[derive(Debug, Clone, Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SchurStep {
    pub node: Point,
    pub parameter: Point,
}

#[derive(Debug, Clone, Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Representation {
    pub steps: Vec<SchurStep>,
    pub terminal: Point,
    pub free_terminal: bool,
    pub bound: f64,
}

impl Representation {
    /// Check a stored Schur certificate, not a new Pick feasibility solve.
    pub(crate) fn validate(&self, observations: &[Observation]) -> Result<(), String> {
        let invalid = || "corrupt_object: invalid Schur certificate".to_string();
        if !self.bound.is_finite() || self.bound <= 0. || observations.is_empty()
            || observations.len() > 64 || self.steps.len() > 64 { return Err(invalid()); }
        let mut remaining: Vec<(C, C)> = Vec::new();
        for o in observations {
            let (z, w) = (c(o.z), c(o.value) / self.bound);
            if !finite(z) || z.norm() > 1. - MARGIN || !finite(w) { return Err(invalid()); }
            if let Some((_, old)) = remaining.iter().find(|(node, _)| *node == z) {
                if *old != w { return Err(invalid()); }
            } else { remaining.push((z, w)); }
        }
        for step in &self.steps {
            let (a, b) = (c(step.node), c(step.parameter));
            if !finite(a) || !finite(b) || b.norm_sqr() >= 1. - TOL { return Err(invalid()); }
            let index = remaining.iter().position(|(z, _)| *z == a).ok_or_else(invalid)?;
            let (_, expected) = remaining.remove(index);
            if expected != b { return Err(invalid()); }
            for (z, w) in &mut remaining {
                let divisor = phi(a, *z) * (C::new(1., 0.) - b.conj() * *w);
                if divisor.norm() < 1e-14 { return Err(invalid()); }
                *w = (*w - b) / divisor;
            }
        }
        let terminal = c(self.terminal);
        if self.free_terminal {
            if !remaining.is_empty() || self.terminal != [0., 0.] { return Err(invalid()); }
        } else if remaining.is_empty()
            || !((terminal.re.abs() == 1. && terminal.im == 0.) || (terminal.im.abs() == 1. && terminal.re == 0.))
            || remaining.iter().any(|(_, w)| *w != terminal) { return Err(invalid()); }
        for o in observations {
            let actual = self.evaluate(o.z).ok_or_else(invalid)?;
            if (c(actual) / self.bound - c(o.value) / self.bound).norm() > 1e-8 { return Err(invalid()); }
        }
        Ok(())
    }
    /// Evaluate one prepared point without repeating the Pick feasibility test.
    pub(crate) fn query(&self, z: Point, observations: &[Observation]) -> Result<QueryValue, String> {
        if !finite(c(z)) || c(z).norm() > 1. - MARGIN {
            return Err("query must be finite and have modulus <=1-1e-8".into());
        }
        let w = self.evaluate(z).ok_or("numerically_unresolved: unsafe representative evaluation")?;
        let disk = if let Some(o) = observations.iter().find(|o| o.z == z) {
            Some((o.value, 0.))
        } else {
            self.value_disk(z)
        };
        let (center, radius) = disk.ok_or("numerically_unresolved: unsafe value disk evaluation")?;
        if !radius.is_finite() || radius < 0.
            || c(center).norm() / self.bound + radius / self.bound > 1. + 1e-8
            || (c(w) / self.bound - c(center) / self.bound).norm() > radius / self.bound + 1e-8
        {
            return Err("numerically_unresolved: query disk failed the bound/containment check; use higher precision".into());
        }
        Ok(QueryValue { z, representative: w, center, radius })
    }

    pub fn evaluate(&self, z: Point) -> Option<Point> {
        let z = c(z);
        if !finite(z) || z.norm() >= 1. || !self.bound.is_finite() || self.bound <= 0. {
            return None;
        }
        let mut value = c(self.terminal);
        for step in self.steps.iter().rev() {
            super::analytic_work::record(|w| w.recurrence_steps += 1);
            let b = c(step.parameter);
            let t = phi(c(step.node), z) * value;
            let den = C::new(1., 0.) + b.conj() * t;
            if den.norm() < 1e-14 {
                return None;
            }
            value = (b + t) / den;
        }
        value *= self.bound;
        finite(value).then(|| p(value))
    }

    fn value_disk(&self, z: Point) -> Option<(Point, f64)> {
        if !self.free_terminal {
            return self.evaluate(z).map(|w| (w, 0.));
        }
        let one = C::new(1., 0.);
        let zero = C::new(0., 0.);
        let (mut a, mut b, mut cc, mut d) = (one, zero, zero, one);
        // Product of fractional-linear maps: every free terminal value in the
        // disk is attainable by a constant Schur function at this single query.
        for step in &self.steps {
            super::analytic_work::record(|w| w.recurrence_steps += 1);
            let t = phi(c(step.node), c(z));
            let beta = c(step.parameter);
            let next = (
                a * t + b * beta.conj() * t,
                a * beta + b,
                cc * t + d * beta.conj() * t,
                cc * beta + d,
            );
            let scale = next
                .0
                .norm()
                .max(next.1.norm())
                .max(next.2.norm())
                .max(next.3.norm());
            if !scale.is_finite() || scale == 0. {
                return None;
            }
            (a, b, cc, d) = (
                next.0 / scale,
                next.1 / scale,
                next.2 / scale,
                next.3 / scale,
            );
        }
        let den = d.norm_sqr() - cc.norm_sqr();
        if den <= 1e-14 {
            return None;
        }
        let center = (b * d.conj() - a * cc.conj()) / den * self.bound;
        let radius = (a * d - b * cc).norm() / den * self.bound;
        (finite(center) && radius.is_finite()).then(|| (p(center), radius))
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct QueryValue {
    pub z: Point,
    pub representative: Point,
    pub center: Point,
    pub radius: f64,
}

#[derive(Debug, Clone, Serialize)]
pub struct Completion {
    pub status: &'static str,
    pub reason: String,
    pub min_pick_eigenvalue: Option<f64>,
    pub pick_tolerance: f64,
    pub max_interpolation_error: Option<f64>,
    pub representation: Option<Representation>,
    pub queries: Vec<QueryValue>,
    pub notes: Vec<String>,
}

fn outcome(status: &'static str, reason: impl Into<String>) -> Completion {
    Completion {
        status, reason: reason.into(), min_pick_eigenvalue: None,
        pick_tolerance: TOL, max_interpolation_error: None,
        representation: None, queries: vec![],
        notes: vec![
            "floating_point_not_formal_proof; exact interpolation model, not a noise fit".into(),
            "Bounded holomorphic on the unit disk by Schur construction; real and imaginary parts are harmonic".into(),
            "Value disks are marginal admissible sets, not confidence probabilities; independent selections need not share a function".into(),
            "A compatible function does not prove the observations' physical source is holomorphic".into(),
        ],
    }
}

pub fn complete(
    observations: &[Observation],
    bound: f64,
    queries: &[Point],
) -> Result<Completion, String> {
    super::analytic_work::record(|w| w.preparations += 1);
    if !bound.is_finite() || bound <= 0. {
        return Err(
            "bound must be finite and positive; provide the declared magnitude limit".into(),
        );
    }
    if observations.is_empty() || observations.len() > 64 {
        return Err("provide 1..64 observations; split the problem explicitly rather than silently sampling".into());
    }
    if queries.len() > 256 {
        return Err("provide at most 256 query points".into());
    }
    let check_node = |z: Point, label: &str| -> Result<(), String> {
        if !finite(c(z)) || c(z).norm() > 1. - MARGIN {
            return Err(format!("{label} must be finite and inside the unit disk with modulus <= {}; boundary interpolation is unsupported",1.-MARGIN));
        }
        Ok(())
    };
    for (i, o) in observations.iter().enumerate() {
        check_node(o.z, &format!("observation {i} input"))?;
        if !finite(c(o.value)) {
            return Err(format!("observation {i} value must contain finite measurements; no imputation is performed"));
        }
    }
    for (i, &z) in queries.iter().enumerate() {
        check_node(z, &format!("query {i}"))?;
    }
    let mut rows = observations.to_vec();
    rows.sort_by(|a, b| a.z[0].total_cmp(&b.z[0]).then(a.z[1].total_cmp(&b.z[1])));
    let mut distinct: Vec<Observation> = vec![];
    for o in rows {
        if let Some(previous) = distinct.last() {
            if previous.z == o.z {
                if previous.value != o.value {
                    return Ok(outcome("infeasible","conflicting duplicate input coordinates; correct the observations or explicitly specify a noise model"));
                }
                continue;
            }
        }
        distinct.push(o);
    }
    let mut remaining: Vec<(C, C)> = distinct
        .iter()
        .map(|o| (c(o.z), c(o.value) / bound))
        .collect();
    if remaining
        .iter()
        .any(|(_, w)| !finite(*w) || w.norm() > 1. + TOL)
    {
        return Ok(outcome("infeasible","an observation exceeds the declared magnitude bound; check the value or the justified bound"));
    }
    for i in 0..remaining.len() {
        for j in 0..i {
            if phi(remaining[i].0, remaining[j].0).norm() < 1e-7 {
                return Ok(outcome("numerically_unresolved","distinct input coordinates are too close for this numerical policy; separate nodes or use higher-precision analysis"));
            }
        }
    }
    // Real symmetric representation of a Hermitian Pick matrix. Each eigenvalue
    // occurs twice; this uses the existing tested real symmetric eigensolver.
    let n = remaining.len();
    let mut matrix = DMatrix::<f64>::zeros(2 * n, 2 * n);
    for i in 0..n {
        for j in 0..n {
            let (zi, wi) = remaining[i];
            let (zj, wj) = remaining[j];
            let entry = (C::new(1., 0.) - wi * wj.conj()) / (C::new(1., 0.) - zi * zj.conj());
            matrix[(i, j)] = entry.re;
            matrix[(i, j + n)] = -entry.im;
            matrix[(i + n, j)] = entry.im;
            matrix[(i + n, j + n)] = entry.re;
        }
    }
    super::analytic_work::record(|w| w.eigensolves += 1);
    let eigen = SymmetricEigen::new(matrix);
    let min = eigen
        .eigenvalues
        .iter()
        .copied()
        .fold(f64::INFINITY, f64::min);
    let scale = eigen.eigenvalues.iter().map(|v| v.abs()).fold(1., f64::max);
    let mut result=outcome("numerically_unresolved","numerical feasibility/evaluation not established; use higher precision or better-separated interior nodes");
    result.min_pick_eigenvalue = Some(min);
    result.pick_tolerance = TOL * scale;
    if min < -result.pick_tolerance {
        result.status = "infeasible";
        result.reason="Pick matrix has a negative eigenvalue beyond tolerance; observations cannot share a function with the declared bound".into();
        return Ok(result);
    }
    let mut model = Representation {
        steps: vec![],
        terminal: [0., 0.],
        free_terminal: true,
        bound,
    };
    while !remaining.is_empty() {
        // Smallest parameter magnitude first reduces amplification. Coordinates
        // break ties deterministically, independently of storage iteration order.
        remaining.sort_by(|a, b| {
            a.1.norm_sqr()
                .total_cmp(&b.1.norm_sqr())
                .then(a.0.re.total_cmp(&b.0.re))
                .then(a.0.im.total_cmp(&b.0.im))
        });
        let (a, b) = remaining.remove(0);
        let size = b.norm_sqr();
        if !size.is_finite() || size > 1. + TOL {
            result.reason =
                "Schur reduction disagrees with the numerical Pick test; use higher precision"
                    .into();
            return Ok(result);
        }
        if (1. - size).abs() < TOL {
            // A rounded norm of one is not a boundary certificate. These axial
            // binary64 values are exactly on the circle without a norm calculation.
            let exact_axis = (b.re.abs() == 1. && b.im == 0.) || (b.im.abs() == 1. && b.re == 0.);
            if exact_axis && remaining.iter().all(|(_, w)| *w == b) {
                model.terminal = p(b);
                model.free_terminal = false;
                break;
            }
            result.reason="Schur parameter is near the unit boundary; uniqueness cannot be resolved at this precision".into();
            return Ok(result);
        }
        model.steps.push(SchurStep {
            node: p(a),
            parameter: p(b),
        });
        for (z, w) in &mut remaining {
            let divisor = phi(a, *z) * (C::new(1., 0.) - b.conj() * (*w));
            if divisor.norm() < 1e-14 {
                result.reason="Schur reduction denominator is unsafe; use better-separated observations or higher precision".into();
                return Ok(result);
            }
            *w = (*w - b) / divisor;
        }
    }
    if model.free_terminal && min <= result.pick_tolerance {
        result.reason =
            "Pick spectrum is too close to singular to certify a family; use higher precision"
                .into();
        return Ok(result);
    }
    let mut max_error = 0.0_f64;
    for o in observations {
        let Some(w) = model.evaluate(o.z) else {
            return Ok(result);
        };
        max_error = max_error.max((c(w) / bound - c(o.value) / bound).norm());
    }
    result.max_interpolation_error = Some(max_error);
    if max_error > 1e-8 {
        result.reason =
            "constructed function fails the interpolation residual gate; use higher precision"
                .into();
        return Ok(result);
    }
    let mut answers = vec![];
    for &z in queries {
        match model.query(z, observations) {
            Ok(answer) => answers.push(answer),
            Err(reason) => {
                result.reason = reason;
                return Ok(result);
            }
        }
    }
    result.status = if model.free_terminal {
        "feasible_family"
    } else {
        "feasible_unique"
    };
    result.reason=if model.free_terminal {"Compatible bounded functions exist; the zero-terminal representative is one choice, not a unique recovered truth"}
        else {"The exact interpolation model is numerically unique; this is not an exact-arithmetic proof"}.into();
    result.representation = Some(model);
    result.queries = answers;
    Ok(result)
}
