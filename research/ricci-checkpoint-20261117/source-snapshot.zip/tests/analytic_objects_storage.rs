#![cfg(feature = "kahler")]
use gigi::analytic_objects::{journal::Journal, prepared::Prepared};
use sha2::{Digest, Sha256};
use std::io::{Read, Seek, SeekFrom, Write};

#[test]
fn ao06_acknowledged_model_and_evidence_reopen_without_original_values() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("objects.log");
    let payload = Prepared::histogram_from_values(&[0.1, 0.2, 1.2], &[0., 1., 2.], 1.01)
        .unwrap()
        .encode()
        .unwrap();
    let digest: [u8; 32] = Sha256::digest(&payload).into();
    let offset;
    {
        let mut log = Journal::open(&path, 1024 * 1024).unwrap();
        offset = log.append(&payload).unwrap();
        assert!(log.bytes() > payload.len() as u64);
    }
    let mut log = Journal::open(&path, 1024 * 1024).unwrap();
    assert_eq!(log.offsets(), &[offset]);
    let model = Prepared::restore(&log.read(offset).unwrap(), &digest).unwrap();
    let answer = model.query(&[[0.5, 0.]]).unwrap();
    assert!((answer[0].value[0] - 5. / 6.).abs() < 1e-12);
    assert_eq!(
        model.evidence()["integer_counts"],
        serde_json::json!([2, 1])
    );
}

#[test]
fn ao06_every_torn_frame_prefix_preserves_acknowledged_prefix_and_allows_retry() {
    let tmp = tempfile::tempdir().unwrap();
    let full = tmp.path().join("full.log");
    let first_end;
    {
        let mut log = Journal::open(&full, 10000).unwrap();
        log.append(b"acknowledged").unwrap();
        first_end = log.bytes();
        log.append(b"not_yet_acknowledged").unwrap();
    }
    let bytes = std::fs::read(&full).unwrap();
    for cut in first_end..bytes.len() as u64 {
        let path = tmp.path().join(format!("cut-{cut}.log"));
        std::fs::write(&path, &bytes[..cut as usize]).unwrap();
        let mut log = Journal::open(&path, 10000).unwrap();
        assert_eq!(log.offsets().len(), 1, "cut {cut}");
        assert_eq!(log.read(log.offsets()[0]).unwrap(), b"acknowledged");
        let retry = log.append(b"retry").unwrap();
        drop(log);
        let mut log = Journal::open(&path, 10000).unwrap();
        assert_eq!(log.offsets().len(), 2);
        assert_eq!(log.read(retry).unwrap(), b"retry");
    }
}

#[test]
fn ao07_complete_corrupt_frame_is_not_misclassified_as_uncommitted_tail() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("objects.log");
    {
        let mut log = Journal::open(&path, 10000).unwrap();
        log.append(b"acknowledged").unwrap();
    }
    let mut file = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(&path)
        .unwrap();
    file.seek(SeekFrom::End(-1)).unwrap();
    let mut byte = [0];
    file.read_exact(&mut byte).unwrap();
    file.seek(SeekFrom::End(-1)).unwrap();
    file.write_all(&[byte[0] ^ 1]).unwrap();
    file.sync_all().unwrap();
    drop(file);
    assert!(Journal::open(&path, 10000)
        .err()
        .unwrap()
        .to_string()
        .contains("corrupt_object"));
}

#[test]
fn ao09_quota_refusal_cannot_append_half_a_transaction() {
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("objects.log");
    let mut log = Journal::open(&path, 128).unwrap();
    log.append(b"one").unwrap();
    let size = log.bytes();
    assert!(log
        .append(&[1; 128])
        .unwrap_err()
        .to_string()
        .contains("resource_limit"));
    assert_eq!(log.bytes(), size);
    assert_eq!(std::fs::metadata(&path).unwrap().len(), size);
}
