//! FIFO eviction keeps hits O(1); retained container capacity is charged too.
use std::{
    collections::{HashMap, VecDeque},
    hash::Hash,
    mem::size_of,
};

pub(crate) struct ByteCache<K, V> {
    map: HashMap<K, (V, usize)>,
    order: VecDeque<K>,
    heap: usize,
    limit: usize,
}
impl<K: Copy + Eq + Hash, V> ByteCache<K, V> {
    pub fn new(limit: usize) -> Self {
        Self {
            map: HashMap::new(),
            order: VecDeque::new(),
            heap: 0,
            limit,
        }
    }
    pub fn get(&self, key: &K) -> Option<&V> {
        self.map.get(key).map(|(v, _)| v)
    }
    pub fn usage(&self) -> (usize, usize) {
        if self.limit == 0 {
            return (0, 0);
        }
        // Hash-table capacity excludes control bytes and padding. Round up to
        // buckets and include a control group; keys here have no heap storage.
        let table = if self.map.capacity() == 0 {
            0
        } else {
            (self.map.capacity() + 1).next_power_of_two() * (size_of::<(K, (V, usize))>() + 1) + 16
        };
        (
            self.map.len(),
            size_of::<Self>() + table + self.order.capacity() * size_of::<K>() + self.heap,
        )
    }
    pub fn insert(&mut self, key: K, value: V, heap: usize) {
        if self.limit == 0
            || heap.saturating_add(size_of::<Self>()) > self.limit
            || self.map.contains_key(&key)
        {
            return;
        }
        if self.map.try_reserve(1).is_err() || self.order.try_reserve(1).is_err() {
            self.clear();
            return;
        }
        self.map.insert(key, (value, heap));
        self.order.push_back(key);
        self.heap += heap;
        while self.usage().1 > self.limit {
            let Some(old) = self.order.pop_front() else {
                self.clear();
                break;
            };
            if let Some((_, bytes)) = self.map.remove(&old) {
                self.heap -= bytes;
            }
            self.map.shrink_to_fit();
            self.order.shrink_to_fit();
            if self.map.is_empty() {
                self.clear();
                break;
            }
        }
    }
    pub fn clear(&mut self) {
        self.map = HashMap::new();
        self.order = VecDeque::new();
        self.heap = 0;
    }
}
