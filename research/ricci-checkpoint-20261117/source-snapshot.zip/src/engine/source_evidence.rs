//! Preparation-time input evidence, not identity, currentness, or authorization.
use crate::types::{Record, Value};
use sha2::{Digest, Sha256};

const ROW_HEADER: &[u8] = b"GIGI-SOURCE-ROW\x01";
const SET_HEADER: &[u8] = b"GIGI-SOURCE-SET\x01";

#[derive(Debug, Clone, Copy)]
pub struct ContentLimits {
    pub max_records: usize,
    pub max_record_bytes: usize,
}

impl Default for ContentLimits {
    fn default() -> Self {
        Self {
            max_records: 1_048_576,
            max_record_bytes: 2 * 1024 * 1024,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ContentEvidence {
    pub format_version: u8,
    pub sha256: [u8; 32],
    pub records_read: u64,
    pub encoded_record_bytes: u64,
}

/// Hash a multiset of exact native records, including duplicate multiplicity.
///
/// Intended for preparation under an external snapshot/read lease. Reads every
/// supplied record; it is not a point-query freshness check or a schema digest.
/// Nonfinite values retain their bits, not an implied analytic acceptance.
pub fn fingerprint_records<'a>(
    records: impl IntoIterator<Item = &'a Record>,
    limits: ContentLimits,
) -> Result<ContentEvidence, String> {
    if limits.max_records == 0
        || limits.max_records > 1_048_576
        || limits.max_record_bytes == 0
        || limits.max_record_bytes > 16 * 1024 * 1024
    {
        return Err(
            "source_evidence limits must be positive: records <= 1048576, record bytes <= 16777216"
                .into(),
        );
    }
    let mut hashes: Vec<[u8; 32]> = Vec::new();
    let mut encoded_record_bytes = 0u64;
    for record in records {
        if hashes.len() == limits.max_records {
            return Err("source_evidence record count exceeds declared limit".into());
        }
        let size = record_size(record, limits.max_record_bytes)?;
        let mut bytes = Vec::new();
        bytes
            .try_reserve_exact(size)
            .map_err(|_| "source_evidence allocation limit")?;
        bytes.extend_from_slice(ROW_HEADER);
        put_len(record.len(), &mut bytes);
        let mut fields: Vec<_> = record.iter().collect();
        fields.sort_unstable_by(|a, b| a.0.cmp(b.0));
        for (name, value) in fields {
            put_blob(name.as_bytes(), &mut bytes);
            put_value(value, &mut bytes);
        }
        debug_assert_eq!(bytes.len(), size);
        hashes
            .try_reserve(1)
            .map_err(|_| "source_evidence allocation limit")?;
        hashes.push(Sha256::digest(&bytes).into());
        encoded_record_bytes += size as u64;
    }
    hashes.sort_unstable();
    let mut state = Sha256::new();
    state.update(SET_HEADER);
    state.update((hashes.len() as u64).to_le_bytes());
    for hash in &hashes {
        state.update(hash);
    }
    Ok(ContentEvidence {
        format_version: 1,
        sha256: state.finalize().into(),
        records_read: hashes.len() as u64,
        encoded_record_bytes,
    })
}

fn record_size(record: &Record, limit: usize) -> Result<usize, String> {
    let mut size = ROW_HEADER.len() + 8;
    let error = || "source_evidence record bytes exceed declared limit".to_string();
    for (name, value) in record {
        let payload = match value {
            Value::Null => 0,
            Value::Bool(_) => 1,
            Value::Integer(_) | Value::Float(_) | Value::Timestamp(_) => 8,
            Value::Text(s) => s.len().checked_add(8).ok_or_else(error)?,
            Value::Binary(b) => b.len().checked_add(8).ok_or_else(error)?,
            Value::Vector(v) => v
                .len()
                .checked_mul(8)
                .and_then(|n| n.checked_add(8))
                .ok_or_else(error)?,
        };
        size = size
            .checked_add(9)
            .and_then(|n| n.checked_add(name.len()))
            .and_then(|n| n.checked_add(payload))
            .ok_or_else(error)?;
        if size > limit {
            return Err(error());
        }
    }
    if size > limit {
        return Err(error());
    }
    Ok(size)
}

fn put_len(n: usize, out: &mut Vec<u8>) {
    out.extend_from_slice(&(n as u64).to_le_bytes());
}
fn put_blob(bytes: &[u8], out: &mut Vec<u8>) {
    put_len(bytes.len(), out);
    out.extend_from_slice(bytes);
}
fn put_value(value: &Value, out: &mut Vec<u8>) {
    match value {
        Value::Null => out.push(0),
        Value::Integer(x) => {
            out.push(1);
            out.extend_from_slice(&x.to_le_bytes());
        }
        Value::Float(x) => {
            out.push(2);
            out.extend_from_slice(&x.to_bits().to_le_bytes());
        }
        Value::Text(s) => {
            out.push(3);
            put_blob(s.as_bytes(), out);
        }
        Value::Bool(x) => {
            out.push(4);
            out.push(u8::from(*x));
        }
        Value::Timestamp(x) => {
            out.push(5);
            out.extend_from_slice(&x.to_le_bytes());
        }
        Value::Vector(v) => {
            out.push(6);
            put_len(v.len(), out);
            for x in v {
                out.extend_from_slice(&x.to_bits().to_le_bytes());
            }
        }
        Value::Binary(b) => {
            out.push(7);
            put_blob(b, out);
        }
    }
}
