//! Memory-mapped DHOOM bundles (Feature #11).
//!
//! Maps a DHOOM snapshot file into virtual memory so the OS page cache
//! manages record residency. Only actively queried pages consume RSS,
//! giving ~20× memory reduction for typical query workloads (Thm 11.1).

use std::collections::HashSet;
use std::fs::File;
use std::io;
use std::path::Path;
use std::sync::{OnceLock, RwLock};

use memmap2::Mmap;
use serde_json::Value as JsonValue;

use crate::bundle::{matches_filter, AnomalyRecord, BundleStats, BundleStore, CurvatureStats, FieldStats, QueryCondition, QueryPlan, TransactionOp, TransactionResult, VectorMetric};
use crate::curvature;
use crate::join;
use crate::metric;
use crate::spectral;
use crate::dhoom::{parse_fiber, DhoomRecordParser, Fiber, Modifier};
use crate::types::{BasePoint, BundleSchema, FieldDef, Record, Value};

/// Memory-mapped DHOOM bundle — records parsed on demand from OS page cache.
pub struct MmapBundle {
    /// Memory-mapped file bytes.
    mmap: Mmap,
    /// Shared record parser (uses Fiber internally).
    parser: DhoomRecordParser,
    /// Bundle/collection name.
    name: String,
    /// Byte offset of each record line start in the mmap.
    line_offsets: Vec<usize>,
    /// Byte offset where the records region begins (after header + pools).
    _data_start: usize,
}

impl MmapBundle {
    /// Open a DHOOM file as memory-mapped.
    pub fn open(path: &Path) -> io::Result<Self> {
        let file = File::open(path)?;
        let mmap = unsafe { Mmap::map(&file)? };
        Self::from_mmap(mmap)
    }

    /// Build from raw mmap bytes (also usable in tests).
    pub fn from_mmap(mmap: Mmap) -> io::Result<Self> {
        let text = std::str::from_utf8(&mmap)
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;

        // Find header end marker '}:'
        let header_end = text
            .find("}:")
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Missing DHOOM header"))?
            + 2; // include '}:'

        let header = text[..header_end].trim();
        let fiber = parse_fiber(&header[..header.len() - 1]) // strip trailing ':'
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e.to_string()))?;

        // Reject delta-encoded files (stateful — incompatible with random access)
        for fd in &fiber.fields {
            if matches!(fd.modifier, Some(Modifier::Delta)) {
                return Err(io::Error::new(
                    io::ErrorKind::Unsupported,
                    format!("Delta-encoded field '{}' not supported in mmap mode", fd.name),
                ));
            }
        }

        let name = fiber.name.clone().unwrap_or_default();
        let parser = DhoomRecordParser::new(fiber);

        // Skip pool lines (start with '&') before records.
        // Empty lines in the data section ARE valid records (all fields arithmetic/default).
        let body = &text[header_end..];
        let mut line_offsets = Vec::new();
        let mut pos = header_end;
        let mut in_pools = true;
        let mut saw_pool = false;
        let mut data_start = header_end;

        for line in body.lines() {
            let trimmed = line.trim();
            let line_byte_len = line.len() + 1; // +1 for newline (approximate)

            if in_pools {
                if trimmed.starts_with('&') {
                    saw_pool = true;
                    pos += line_byte_len;
                    continue;
                }
                // Blank lines are pool separators only if we've seen at least one '&' line
                if trimmed.is_empty() && saw_pool {
                    pos += line_byte_len;
                    continue;
                }
                // Skip leading blank line right after header (before any data)
                if trimmed.is_empty() && pos == header_end {
                    pos += line_byte_len;
                    continue;
                }
                in_pools = false;
                data_start = pos;
            }

            // Every non-pool line is a record (including empty lines = all-default records)
            line_offsets.push(pos);
            pos += line_byte_len;
        }

        Ok(Self {
            mmap,
            parser,
            name,
            line_offsets,
            _data_start: data_start,
        })
    }

    /// Bundle name.
    pub fn name(&self) -> &str {
        &self.name
    }

    /// Number of records.
    pub fn len(&self) -> usize {
        self.line_offsets.len()
    }

    /// True if empty.
    pub fn is_empty(&self) -> bool {
        self.line_offsets.is_empty()
    }

    /// Read a single record by ordinal index (0-based).
    /// Parses the DHOOM line on demand from mmap'd bytes.
    pub fn get(&self, index: usize) -> Option<JsonValue> {
        if index >= self.line_offsets.len() {
            return None;
        }
        let start = self.line_offsets[index];
        let end = if index + 1 < self.line_offsets.len() {
            self.line_offsets[index + 1]
        } else {
            self.mmap.len()
        };
        let raw = std::str::from_utf8(&self.mmap[start..end]).ok()?;
        let line = raw.lines().next().unwrap_or("").trim();
        Some(self.parser.decode_line(line, index))
    }

    /// Sequential scan over all records.
    pub fn scan(&self) -> MmapScanIter<'_> {
        MmapScanIter {
            bundle: self,
            index: 0,
        }
    }

    /// Access the raw mmap (for advise calls).
    #[cfg(unix)]
    pub fn advise_sequential(&self) {
        self.mmap.advise(memmap2::Advice::Sequential).ok();
    }

    #[cfg(unix)]
    pub fn advise_random(&self) {
        self.mmap.advise(memmap2::Advice::Random).ok();
    }

    /// Access the raw fiber schema.
    pub fn fiber(&self) -> &Fiber {
        self.parser.fiber()
    }
}

/// Iterator over mmap'd records.
pub struct MmapScanIter<'a> {
    bundle: &'a MmapBundle,
    index: usize,
}

impl<'a> Iterator for MmapScanIter<'a> {
    type Item = JsonValue;

    fn next(&mut self) -> Option<Self::Item> {
        let rec = self.bundle.get(self.index)?;
        self.index += 1;
        Some(rec)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let remaining = self.bundle.len().saturating_sub(self.index);
        (remaining, Some(remaining))
    }
}

impl<'a> ExactSizeIterator for MmapScanIter<'a> {}

// ── OverlayBundle ───────────────────────────────────────────────────────────

/// Overlay bundle: mmap base + BundleStore overlay with full index support.
///
/// The overlay is a real `BundleStore`, so Feature #4's hash index acceleration
/// works on recently-written records. The base is read-only mmap.
/// Interior mutability via `RwLock<BundleStore>` allows concurrent reads with
/// occasional writes — reads take a shared lock, writes take an exclusive lock.
///
/// Tombstones are tracked inside the overlay's RwLock to keep the critical
/// section atomic (delete = tombstone + remove from overlay in one lock).
pub struct OverlayBundle {
    /// Mmap-backed snapshot data (immutable, shared across readers).
    base: MmapBundle,
    /// In-memory overlay with full BundleStore (indexes, stats, etc).
    overlay: RwLock<BundleStore>,
    /// Deleted keys from the base (tombstones). Inside the same RwLock
    /// would require a custom struct; we use a separate RwLock for simplicity.
    tombstones: RwLock<HashSet<String>>,
    /// Schema cached outside the RwLock for lock-free access.
    bundle_schema: BundleSchema,
    /// Rows the last `bulk_delete` matched and could not address, because a
    /// tombstone IS a primary key and theirs is unreadable. Kept so the caller
    /// can report doing less than it was asked rather than a bare success.
    unaddressable_last_bulk_delete: std::sync::atomic::AtomicUsize,
    /// Live merged-view statistics, stamped with the overlay revision.
    base_stats: RwLock<Option<(u64, std::collections::HashMap<String, crate::bundle::FieldStats>)>>,
    /// **#106 fix.** Lazily-computed set of primary-key strings present
    /// in the mmap base. Used by `len()` (and any other dedup-needing
    /// caller) to count overlay-shadowing-base records *exactly once*
    /// instead of double-counting them. Built in O(base) on first
    /// access; subsequent calls are O(1). The base is immutable so the
    /// set is too.
    base_pk_set: OnceLock<HashSet<String>>,
}

impl OverlayBundle {
    /// Create an overlay on top of an mmap'd bundle.
    pub fn new(base: MmapBundle, schema: BundleSchema) -> Self {
        Self {
            base,
            overlay: RwLock::new(BundleStore::new(schema.clone())),
            tombstones: RwLock::new(HashSet::new()),
            bundle_schema: schema,
            unaddressable_last_bulk_delete: std::sync::atomic::AtomicUsize::new(0),
            base_stats: RwLock::new(None),
            base_pk_set: OnceLock::new(),
        }
    }

    /// Lazily build (or retrieve) the set of base primary-key strings.
    ///
    /// Walks every record in the mmap base once, extracts its PK using
    /// `pk_field()`, and caches the resulting `HashSet<String>`. The
    /// initial cost is O(base records); subsequent calls are O(1).
    /// Returns an empty set if the schema has no detectable PK field.
    ///
    /// **#106 fix** — used by `len()` to count overlay records that
    /// shadow base records (same PK) only once.
    fn base_pk_set(&self) -> &HashSet<String> {
        self.base_pk_set.get_or_init(|| {
            let pk_field = match self.pk_field() {
                Some(f) => f.to_string(),
                None => return HashSet::new(),
            };
            let mut set = HashSet::with_capacity(self.base.len());
            for i in 0..self.base.len() {
                if let Some(jv) = self.base.get(i) {
                    // Convert through json_to_record so the PK format
                    // matches the overlay path. The overlay stores
                    // `GigiValue` (e.g. `Integer(2)`), whereas raw
                    // `serde_json::Value::Number` debug-formats as
                    // `Number(2)`. Mismatch would defeat the shadow-
                    // dedup intersection in `len()`. The conversion is
                    // O(record) — only done once per record at cache
                    // build time, then never again.
                    let rec = Self::json_to_record(&jv);
                    if let Some(pk) = rec.get(pk_field.as_str()) {
                        set.insert(pk.key_repr());
                    }
                }
            }
            set
        })
    }

    /// Insert a record into the overlay (acquires write lock).
    ///
    /// **#165 fix (post-#106 follow-up):** the tombstone-lift now
    /// extracts the PK by *name* via `tombstone_key()`, instead of the
    /// pre-fix `record.values().next()` which picked an arbitrary
    /// `HashMap` iteration-order entry. Because Rust's `HashMap` is
    /// randomized by default (SipHash with a per-process seed), the
    /// old code would non-deterministically pick a non-PK field as the
    /// "key" and try to remove a tombstone keyed by that value — which
    /// of course wouldn't match the real tombstone, leaving it in
    /// place. After a delete-then-reinsert sequence, the tombstone
    /// would leak alongside the new overlay entry, causing `len()` /
    /// `records()` accounting drift (the #106 invariant property
    /// test caught this). The fix uses the schema's declared PK
    /// field, matching what `delete()` / `tombstone_key()` use.
    pub fn insert(&self, record: &Record) {
        let pk_str = self.tombstone_key(record);
        if let Ok(mut ts) = self.tombstones.write() {
            if let Some(ref k) = pk_str {
                ts.remove(k);
            }
        }
        if let Ok(mut store) = self.overlay.write() {
            store.insert(record);
        }
    }

    /// Update a record in the overlay.
    pub fn update(&self, key: &Record, patches: &Record) -> bool {
        if let Ok(mut store) = self.overlay.write() {
            store.update(key, patches)
        } else {
            false
        }
    }

    /// Mark a key as deleted (tombstone hides base record).
    ///
    /// **2026-08-13 tombstone key unification.** The tombstone set is read
    /// through `tombstone_key` / `base_pk_set`, both of which key on the PK
    /// field's value alone — `Integer(1)`. Callers were passing
    /// `Engine::pk_string`, which renders every base field as a sorted debug
    /// list — `[("id", Integer(1))]`. The two never matched, so a delete
    /// against an mmap-backed bundle filed a tombstone under a name nothing
    /// looked it up by: the row stayed hidden only while the overlay's own
    /// `delete` held it, and came back on the next restart even with a
    /// perfectly intact WAL. `point_query` appeared correct throughout
    /// because it consults the overlay separately.
    ///
    /// So the key is now derived here, from the record, whenever one is
    /// supplied — the type that owns the set decides how the set is keyed,
    /// and no call site can disagree with it. The `key` string remains the
    /// fallback for callers that have no record to offer.
    pub fn delete(&self, key: &str, key_record: Option<&Record>) {
        let canonical = key_record
            .and_then(|r| self.tombstone_key(r))
            .unwrap_or_else(|| key.to_string());
        if let Ok(mut ts) = self.tombstones.write() {
            ts.insert(canonical);
        }
        // Also remove from overlay if present
        if let Some(kr) = key_record {
            if let Ok(mut store) = self.overlay.write() {
                if !store.delete(kr) {
                    // A base-only tombstone still changes the visible population.
                    store.mark_mutated();
                }
            }
        }
    }

    /// Point lookup in overlay (acquires read lock).
    pub fn point_query_overlay(&self, key: &Record) -> Option<Record> {
        if let Ok(store) = self.overlay.read() {
            store.point_query(key)
        } else {
            None
        }
    }

    /// Check if a key is tombstoned.
    ///
    /// Takes the *already-encoded* key. Prefer [`Self::is_record_tombstoned`]
    /// when you hold the record — it cannot disagree with the encoding the
    /// set is actually keyed by.
    pub fn is_tombstoned(&self, key: &str) -> bool {
        self.tombstones.read().map_or(false, |ts| ts.contains(key))
    }

    /// Is this record hidden by a tombstone?
    ///
    /// The canonical read. Callers outside this type used to encode the key
    /// themselves — `Engine` reached for `pk_string`, which renders every base
    /// field as a sorted debug list, while the set has always been keyed by
    /// the PK value alone. Both sides were internally consistent, so a delete
    /// looked correct through `Engine::point_query` and was invisible to
    /// `is_visible`, `len()`, `records()` and the snapshot merge — which is
    /// how a deleted row got written back into a fresh `.dhoom` and returned
    /// after restart.
    ///
    /// Deriving the key here means no caller can hold a different opinion
    /// about it.
    pub fn is_record_tombstoned(&self, record: &Record) -> bool {
        self.tombstone_key(record)
            .map_or(false, |k| self.is_tombstoned(&k))
    }

    /// Get the mmap base bundle.
    pub fn base(&self) -> &MmapBundle {
        &self.base
    }

    /// Number of overlay entries (acquires read lock).
    pub fn overlay_len(&self) -> usize {
        self.overlay.read().map_or(0, |s| s.len())
    }

    /// Number of tombstones.
    pub fn tombstone_len(&self) -> usize {
        self.tombstones.read().map_or(0, |ts| ts.len())
    }

    /// Access overlay BundleStore for queries (acquires read lock).
    /// The caller can use `filtered_query()` etc on the overlay store.
    pub fn with_overlay<F, R>(&self, f: F) -> Option<R>
    where
        F: FnOnce(&BundleStore) -> R,
    {
        self.overlay.read().ok().map(|store| f(&*store))
    }

    /// **#107 fix.** Materialize the merged view (mmap base − tombstones +
    /// overlay) into a fresh heap-resident `BundleStore`. Used by brain
    /// endpoints as a one-shot promotion so existing `&BundleStore`-typed
    /// fit + sample machinery can read overlay bundles without a deep
    /// refactor.
    ///
    /// Cost: O(N) walk + N inserts. ~10ms for Marcella's 10k bundle.
    /// Caller should cache the result if calling repeatedly — this
    /// re-walks every time.
    ///
    /// Correctness: uses `self.records()` which already applies the
    /// tombstone mask and merges overlay-on-top-of-base. The resulting
    /// store has identical record set to what reads see.
    pub fn to_temp_heap_store(&self) -> BundleStore {
        let mut store = BundleStore::new(self.bundle_schema.clone());
        for record in self.records() {
            store.insert(&record);
        }
        // Derived caches key the source revision, not the number of copied rows.
        store.mutation_counter.store(self.mutation_counter(), std::sync::atomic::Ordering::Relaxed);
        store.cache_identity = self.overlay.read().unwrap().cache_identity();
        store
    }

    /// Clear overlay and tombstones (after compaction to new mmap).
    pub fn clear_overlay(&self) {
        if let Ok(mut store) = self.overlay.write() {
            // Re-create with same schema
            let schema = store.schema.clone();
            let revision = store.mutation_counter().wrapping_add(1);
            *store = BundleStore::new(schema);
            store.mutation_counter.store(revision, std::sync::atomic::Ordering::Relaxed);
        }
        if let Ok(mut ts) = self.tombstones.write() {
            ts.clear();
        }
        *self.base_stats.write().unwrap() = None;
    }

    /// Swap the base mmap to a new snapshot file (after compaction).
    pub fn rebase(&mut self, new_base: MmapBundle, schema: BundleSchema) {
        self.base = new_base;
        self.bundle_schema = schema.clone();
        self.base_pk_set.take();
        if let Ok(mut store) = self.overlay.write() {
            let revision = store.mutation_counter().wrapping_add(1);
            *store = BundleStore::new(schema);
            store.mutation_counter.store(revision, std::sync::atomic::Ordering::Relaxed);
        }
        if let Ok(mut ts) = self.tombstones.write() {
            ts.clear();
        }
        *self.base_stats.write().unwrap() = None;
    }

    // ── Schema & Stats (lock-free) ─────────────────────────────────────────

    /// Schema for this bundle (lock-free — stored outside RwLock).
    pub fn schema(&self) -> &BundleSchema {
        &self.bundle_schema
    }

    /// Curvature statistics (from overlay BundleStore).
    pub fn curvature_stats(&self) -> CurvatureStats {
        self.overlay
            .read()
            .map_or(CurvatureStats::default(), |s| s.curvature_stats.clone())
    }

    // ── Internal helpers ───────────────────────────────────────────────────

    /// Primary key field name (first base field).
    fn pk_field(&self) -> Option<&str> {
        self.bundle_schema
            .base_fields
            .first()
            .map(|f| f.name.as_str())
    }

    /// Extract tombstone key string from a Record.
    fn tombstone_key(&self, record: &Record) -> Option<String> {
        self.pk_field()
            .and_then(|f| record.get(f))
            .map(|v| v.key_repr())
    }

    /// All PK strings currently in the overlay (for dedup during base scan).
    fn overlay_pk_set(&self) -> HashSet<String> {
        let pk = match self.pk_field() {
            Some(f) => f.to_string(),
            None => return HashSet::new(),
        };
        self.overlay.read().map_or(HashSet::new(), |s| {
            s.records()
                .filter_map(|r| r.get(&pk).map(|v| v.key_repr()))
                .collect()
        })
    }

    /// Convert a serde_json::Value (from MmapBundle) into a GIGI Record.
    fn json_to_record(jv: &serde_json::Value) -> Record {
        match jv {
            serde_json::Value::Object(map) => map
                .iter()
                .map(|(k, v)| (k.clone(), Self::json_val(v)))
                .collect(),
            _ => Record::new(),
        }
    }

    fn json_val(v: &serde_json::Value) -> Value {
        match v {
            serde_json::Value::Number(n) => {
                if let Some(i) = n.as_i64() {
                    Value::Integer(i)
                } else {
                    Value::Float(n.as_f64().unwrap_or(0.0))
                }
            }
            serde_json::Value::String(s) => {
                if let Some(encoded) = s.strip_prefix("b64:") {
                    use base64::Engine as _;
                    match base64::engine::general_purpose::STANDARD.decode(encoded) {
                        Ok(bytes) => Value::Binary(bytes),
                        Err(_) => Value::Text(s.clone()),
                    }
                } else {
                    Value::Text(s.clone())
                }
            }
            serde_json::Value::Bool(b) => Value::Bool(*b),
            serde_json::Value::Array(arr) => {
                let floats: Vec<f64> = arr.iter().filter_map(|x| x.as_f64()).collect();
                if floats.len() == arr.len() && !arr.is_empty() {
                    Value::Vector(floats)
                } else {
                    Value::Null
                }
            }
            _ => Value::Null,
        }
    }

    /// Check if a base record is visible (not tombstoned, not overridden by overlay).
    fn is_visible(
        record: &Record,
        pk_field: Option<&str>,
        tombstones: &Option<std::sync::RwLockReadGuard<'_, HashSet<String>>>,
        overlay_keys: &HashSet<String>,
    ) -> bool {
        if let Some(pk) = pk_field.and_then(|f| record.get(f)) {
            let key_str = pk.key_repr();
            if let Some(ref ts) = tombstones {
                if ts.contains(&key_str) {
                    return false;
                }
            }
            if overlay_keys.contains(&key_str) {
                return false;
            }
        }
        true
    }

    // ── Merged Metadata ────────────────────────────────────────────────────

    /// Total record count.
    ///
    /// Mirrors `records()`'s deduplication contract: a base record is
    /// hidden iff its PK is in `tombstones` OR `overlay_keys`. So:
    ///
    ///   visible_base = |base| − |base ∩ (tombstones ∪ overlay_keys)|
    ///   total       = visible_base + |overlay|
    ///
    /// Since `tombstones` and `overlay_keys` are mutually exclusive by
    /// the insert/delete invariants (insert removes from tombstones,
    /// delete removes from overlay), the intersection with base
    /// decomposes cleanly into two non-overlapping counts.
    ///
    /// **#106 fix** — pre-fix `len()` did `|base| − |tombstones| +
    /// |overlay|`, which (a) ignored that an overlay record shadowing
    /// a base record should subtract from the base count (double-
    /// counting on updates), and (b) over-subtracted when a tombstone
    /// referenced a key that wasn't in the base. `records()` was
    /// already correct (line ~959); `len()` now matches that contract.
    pub fn len(&self) -> usize {
        let pk_field = match self.pk_field() {
            Some(f) => f.to_string(),
            // No detectable PK → no dedup machinery; fall back to the
            // (still-imperfect, but compatible) old behavior.
            None => {
                let ts_count = self.tombstones.read().map_or(0, |ts| ts.len());
                return self.base.len().saturating_sub(ts_count) + self.overlay_len();
            }
        };
        let base_keys = self.base_pk_set();

        // Count tombstones whose key is actually in the base — these
        // hide a real base record. Tombstones for keys not in base are
        // no-ops for counting (the key was overlay-only and got
        // removed; that removal already showed up in overlay.len()).
        // Collect the *union* of tombstones and overlay keys that
        // exist in the base. `records()`'s base-filter uses an OR
        // (skip if in tombstones OR in overlay_keys), so a base key
        // present in BOTH should only count once toward hiding the
        // base record. The previous formulation
        // `|base ∩ ts| + |base ∩ overlay_keys|` double-subtracted when
        // the sets overlapped (which can happen due to the existing
        // `OverlayBundle::insert` HashMap-order tombstone-lift bug
        // where the wrong field is used to identify the tombstone to
        // clear). Use a HashSet to compute the union correctly.
        let mut hidden_base: HashSet<String> = HashSet::new();
        if let Ok(ts) = self.tombstones.read() {
            for k in ts.iter() {
                if base_keys.contains(k) {
                    hidden_base.insert(k.clone());
                }
            }
        }
        if !base_keys.is_empty() {
            if let Ok(store) = self.overlay.read() {
                for r in store.records() {
                    if let Some(k) = r.get(pk_field.as_str()).map(|v| v.key_repr()) {
                        if base_keys.contains(&k) {
                            hidden_base.insert(k);
                        }
                    }
                }
            }
        }
        let hidden_base_count = hidden_base.len();

        self.base
            .len()
            .saturating_sub(hidden_base_count)
            + self.overlay_len()
    }

    pub fn is_empty_bundle(&self) -> bool {
        self.len() == 0
    }

    /// All field names from schema.
    pub fn field_names(&self) -> Vec<String> {
        self.bundle_schema
            .base_fields
            .iter()
            .chain(self.bundle_schema.fiber_fields.iter())
            .map(|f| f.name.clone())
            .collect()
    }

    pub fn storage_mode(&self) -> &'static str {
        "mmap+overlay"
    }

    /// **#107 fix.** Mutation counter for the overlay portion of the
    /// bundle. The mmap base is immutable by construction (snapshot
    /// data) so its mutation count is constant; the overlay tracks
    /// mutations since reload. Brain endpoints use this for cache
    /// invalidation just as they do on heap-only bundles.
    ///
    /// Note: an overlay starts at counter=0 immediately after
    /// reload. Consumers that cached a fit against a higher counter
    /// from before the restart will see the overlay's lower value
    /// and correctly treat their cached fit as stale (the cache
    /// key is keyed on bundle name + counter, so a "lower" counter
    /// is a miss, which is the right behavior — the base data IS
    /// the same but we don't know what the consumer's fit assumed).
    pub fn mutation_counter(&self) -> u64 {
        self.overlay.read().map_or(0, |s| s.mutation_counter())
    }

    pub fn next_auto_id(&self) -> i64 {
        self.overlay.write().map_or(0, |mut s| s.next_auto_id())
    }

    /// Summarize the visible population, not base plus shadowing overlay rows.
    pub fn field_stats(&self) -> std::collections::HashMap<String, FieldStats> {
        let revision = self.mutation_counter();
        let mut cached = self.base_stats.write().unwrap();
        if let Some((at, stats)) = &*cached {
            if *at == revision { return stats.clone(); }
        }
        let mut stats = std::collections::HashMap::<String, FieldStats>::new();
        for record in self.records() {
            for field in &self.bundle_schema.fiber_fields {
                if let Some(x) = record.get(&field.name).and_then(crate::types::Value::as_f64) {
                    stats.entry(field.name.clone()).or_default().update(x);
                }
            }
        }
        *cached = Some((revision, stats.clone()));
        stats
    }

    // ── Merged Query Methods ───────────────────────────────────────────────

    pub fn filtered_query(
        &self,
        conditions: &[QueryCondition],
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> Vec<Record> {
        self.filtered_query_ex(conditions, None, sort_by, sort_desc, limit, offset)
    }

    pub fn filtered_query_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> Vec<Record> {
        // TIMESTAMP ergonomics — same rewrite the heap store applies;
        // the direct mmap scan below must see coerced literals too.
        let coerced =
            crate::bundle::coerce_conditions_to_schema(self.schema(), conditions);
        let conditions: &[QueryCondition] = coerced.as_deref().unwrap_or(conditions);

        let pk_field = self.pk_field();

        // Phase 1: Query overlay (has indexes → fast).
        let overlay_results = self
            .overlay
            .read()
            .ok()
            .map(|s| s.filtered_query_ex(conditions, or_conditions, sort_by, sort_desc, None, None))
            .unwrap_or_default();

        let overlay_keys: HashSet<String> = overlay_results
            .iter()
            .filter_map(|r| pk_field.and_then(|f| r.get(f)).map(|v| v.key_repr()))
            .collect();

        let tombstones = self.tombstones.read().ok();

        // ── Fast-path: no sort → streaming with early termination ──
        if sort_by.is_none() {
            let start = offset.unwrap_or(0);
            let take = limit.unwrap_or(usize::MAX);
            let need = start.saturating_add(take);

            let mut results = overlay_results;

            if results.len() < need {
                for i in 0..self.base.len() {
                    if let Some(jv) = self.base.get(i) {
                        let record = Self::json_to_record(&jv);
                        if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                            continue;
                        }
                        if matches_filter(&record, conditions, or_conditions) {
                            results.push(record);
                            if results.len() >= need {
                                break;
                            }
                        }
                    }
                }
            }

            return results.into_iter().skip(start).take(take).collect();
        }

        // ── Sorted path: buffer all matches (capped) ──
        let max_rows: usize = std::env::var("GIGI_QUERY_MAX_ROWS")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(10_000_000);

        let mut results = overlay_results;

        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                    continue;
                }
                if matches_filter(&record, conditions, or_conditions) {
                    results.push(record);
                    if results.len() > max_rows {
                        break;
                    }
                }
            }
        }

        let field = sort_by.unwrap().to_string();
        results.sort_by(|a, b| {
            let va = a.get(&field).unwrap_or(&Value::Null);
            let vb = b.get(&field).unwrap_or(&Value::Null);
            if sort_desc {
                vb.cmp(va)
            } else {
                va.cmp(vb)
            }
        });

        let start = offset.unwrap_or(0);
        if start > 0 {
            results = results.into_iter().skip(start).collect();
        }
        if let Some(lim) = limit {
            results.truncate(lim);
        }
        results
    }

    pub fn filtered_query_projected(
        &self,
        conditions: &[QueryCondition],
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
        fields: Option<&[&str]>,
    ) -> (Vec<Record>, usize) {
        let sort_fields: Option<Vec<(&str, bool)>> = sort_by.map(|f| vec![(f, sort_desc)]);
        self.filtered_query_projected_ex(
            conditions,
            None,
            sort_fields.as_deref(),
            limit,
            offset,
            fields,
        )
    }

    pub fn filtered_query_projected_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_fields: Option<&[(&str, bool)]>,
        limit: Option<usize>,
        offset: Option<usize>,
        fields: Option<&[&str]>,
    ) -> (Vec<Record>, usize) {
        let pk_field = self.pk_field();

        // Phase 1: Overlay matches (no limit — need total count).
        let overlay_all = self
            .overlay
            .read()
            .ok()
            .map(|s| {
                s.filtered_query_ex(
                    conditions,
                    or_conditions,
                    None,  // no sort yet
                    false,
                    None,
                    None,
                )
            })
            .unwrap_or_default();

        let overlay_keys: HashSet<String> = overlay_all
            .iter()
            .filter_map(|r| pk_field.and_then(|f| r.get(f)).map(|v| v.key_repr()))
            .collect();

        let tombstones = self.tombstones.read().ok();
        let max_rows: usize = std::env::var("GIGI_QUERY_MAX_ROWS")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(10_000_000);

        // Phase 2: Base matches.
        let mut base_matches: Vec<Record> = Vec::new();
        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                    continue;
                }
                if matches_filter(&record, conditions, or_conditions) {
                    base_matches.push(record);
                    if base_matches.len() > max_rows {
                        break;
                    }
                }
            }
        }

        let total = overlay_all.len() + base_matches.len();
        let mut results = overlay_all;
        results.extend(base_matches);

        // Sort (multi-field).
        if let Some(sorts) = sort_fields {
            results.sort_by(|a, b| {
                for &(field, desc) in sorts {
                    let va = a.get(field).unwrap_or(&Value::Null);
                    let vb = b.get(field).unwrap_or(&Value::Null);
                    let ord = if desc { vb.cmp(va) } else { va.cmp(vb) };
                    if ord != std::cmp::Ordering::Equal {
                        return ord;
                    }
                }
                std::cmp::Ordering::Equal
            });
        }

        // Offset + Limit.
        let start = offset.unwrap_or(0);
        let mut paged: Vec<Record> = results.into_iter().skip(start).collect();
        if let Some(lim) = limit {
            paged.truncate(lim);
        }

        // Project fields.
        if let Some(fields) = fields {
            let field_set: HashSet<&str> = fields.iter().copied().collect();
            for r in &mut paged {
                r.retain(|k, _| field_set.contains(k.as_str()));
            }
        }

        (paged, total)
    }

    pub fn count_where(&self, conditions: &[QueryCondition]) -> usize {
        self.count_where_ex(conditions, None)
    }

    pub fn count_where_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
    ) -> usize {
        let pk_field = self.pk_field();

        let (overlay_count, overlay_keys) = self.overlay.read().map_or(
            (0, HashSet::new()),
            |s| {
                let count = s.count_where_ex(conditions, or_conditions);
                let pk = pk_field.unwrap_or("");
                let keys: HashSet<String> = s
                    .records()
                    .filter_map(|r| r.get(pk).map(|v| v.key_repr()))
                    .collect();
                (count, keys)
            },
        );

        let tombstones = self.tombstones.read().ok();

        let mut base_count = 0usize;
        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                    continue;
                }
                if matches_filter(&record, conditions, or_conditions) {
                    base_count += 1;
                }
            }
        }

        overlay_count + base_count
    }

    pub fn exists(&self, conditions: &[QueryCondition]) -> bool {
        self.exists_ex(conditions, None)
    }

    pub fn exists_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
    ) -> bool {
        if self
            .overlay
            .read()
            .map_or(false, |s| s.exists_ex(conditions, or_conditions))
        {
            return true;
        }

        let pk_field = self.pk_field();
        let overlay_keys = self.overlay_pk_set();
        let tombstones = self.tombstones.read().ok();

        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                    continue;
                }
                if matches_filter(&record, conditions, or_conditions) {
                    return true;
                }
            }
        }
        false
    }

    /// Point lookup: overlay first (indexed), then base scan.
    pub fn point_query(&self, key: &Record) -> Option<Record> {
        // Check overlay first.
        if let Ok(store) = self.overlay.read() {
            if let Some(rec) = store.point_query(key) {
                return Some(rec);
            }
        }

        // Check tombstones.
        let pk_field = self.pk_field()?;
        let key_val = key.get(pk_field)?;
        let key_str = key_val.key_repr();
        if self.is_tombstoned(&key_str) {
            return None;
        }

        // Linear scan base for matching key.
        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if record.get(pk_field) == Some(key_val) {
                    return Some(record);
                }
            }
        }
        None
    }

    /// Range query: merge overlay + base.
    pub fn range_query(&self, field: &str, values: &[Value]) -> Vec<Record> {
        let pk_field = self.pk_field();

        let overlay_results = self
            .overlay
            .read()
            .map_or(Vec::new(), |s| s.range_query(field, values));
        let overlay_keys: HashSet<String> = overlay_results
            .iter()
            .filter_map(|r| pk_field.and_then(|f| r.get(f)).map(|v| v.key_repr()))
            .collect();

        let tombstones = self.tombstones.read().ok();
        let value_set: HashSet<&Value> = values.iter().collect();

        let mut results = overlay_results;
        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                    continue;
                }
                if let Some(val) = record.get(field) {
                    if value_set.contains(val) {
                        results.push(record);
                    }
                }
            }
        }
        results
    }

    /// Merged record iterator: overlay records first, then visible base records.
    pub fn records(&self) -> Box<dyn Iterator<Item = Record> + '_> {
        let pk_field = self.pk_field().map(|s| s.to_string());
        let overlay_records: Vec<Record> = self
            .overlay
            .read()
            .map_or(Vec::new(), |s| s.records().collect());

        let overlay_keys: HashSet<String> = overlay_records
            .iter()
            .filter_map(|r| {
                pk_field
                    .as_deref()
                    .and_then(|f| r.get(f))
                    .map(|v| v.key_repr())
            })
            .collect();

        let base_len = self.base.len();
        let tombstones: HashSet<String> = self
            .tombstones
            .read()
            .map_or(HashSet::new(), |ts| ts.clone());

        // Chain overlay then base.
        let overlay_iter = overlay_records.into_iter();
        let base_iter = (0..base_len).filter_map(move |i| {
            let jv = self.base.get(i)?;
            let record = Self::json_to_record(&jv);
            if let Some(ref pk_f) = pk_field {
                if let Some(pk) = record.get(pk_f.as_str()) {
                    let key_str = pk.key_repr();
                    if tombstones.contains(&key_str) || overlay_keys.contains(&key_str) {
                        return None;
                    }
                }
            }
            Some(record)
        });

        Box::new(overlay_iter.chain(base_iter))
    }

    /// One field's values in `records()` order, without building a `Record` per
    /// row.
    ///
    /// `records()` on an overlay pays twice per stored row: `decode_line` yields
    /// a `serde_json` map, and `json_to_record` copies that into a
    /// `HashMap<String, Value>` whose keys are freshly allocated strings. A scan
    /// that wants one field pays both taxes for every field it is going to throw
    /// away. This reads the decoded line and takes only the requested field, plus
    /// the primary key when one is needed to honour tombstones and overlay
    /// shadowing.
    ///
    /// Order, shadowing and tombstones match `records()` exactly — overlay rows
    /// first, then base rows that are neither deleted nor superseded — so two
    /// columns of the same bundle can be zipped row-wise.
    ///
    /// Returns `None` if the field is not in the schema.
    pub fn column(&self, field: &str) -> Option<Vec<Value>> {
        let in_schema = self
            .bundle_schema
            .base_fields
            .iter()
            .chain(self.bundle_schema.fiber_fields.iter())
            .any(|f| f.name == field);
        if !in_schema {
            return None;
        }

        let pk_field = self.pk_field().map(|s| s.to_string());
        let overlay_records: Vec<Record> = self
            .overlay
            .read()
            .map_or(Vec::new(), |s| s.records().collect());
        let overlay_keys: HashSet<String> = overlay_records
            .iter()
            .filter_map(|r| {
                pk_field
                    .as_deref()
                    .and_then(|f| r.get(f))
                    .map(|v| v.key_repr())
            })
            .collect();
        let tombstones: HashSet<String> = self
            .tombstones
            .read()
            .map_or(HashSet::new(), |ts| ts.clone());

        let mut out: Vec<Value> = Vec::with_capacity(overlay_records.len() + self.base.len());
        for r in &overlay_records {
            out.push(r.get(field).cloned().unwrap_or(Value::Null));
        }

        // A base row is only skipped on the strength of its primary key, so when
        // nothing can shadow it the key never has to be materialised.
        let needs_key = pk_field.is_some() && !(overlay_keys.is_empty() && tombstones.is_empty());
        for i in 0..self.base.len() {
            let Some(jv) = self.base.get(i) else { continue };
            let serde_json::Value::Object(map) = &jv else {
                continue;
            };
            if needs_key {
                if let Some(pk_f) = pk_field.as_deref() {
                    if let Some(pk) = map.get(pk_f).map(Self::json_val) {
                        let key_str = pk.key_repr();
                        if tombstones.contains(&key_str) || overlay_keys.contains(&key_str) {
                            continue;
                        }
                    }
                }
            }
            out.push(map.get(field).map(Self::json_val).unwrap_or(Value::Null));
        }
        Some(out)
    }

    /// `column`, restricted to numeric values.
    ///
    /// Returns `None` if the field is absent from the schema, or if any stored
    /// value in it is not numeric — including `Null`. It does not substitute a
    /// placeholder for a value it could not read.
    pub fn numeric_column(&self, field: &str) -> Option<Vec<f64>> {
        let vals = self.column(field)?;
        let mut out = Vec::with_capacity(vals.len());
        for v in vals {
            out.push(v.as_f64()?);
        }
        Some(out)
    }

    /// Several fields at once, each returned in `records()` order.
    ///
    /// Prefer this over calling `column` per field. The stored rows are
    /// line-oriented, so every read decodes a line; asking for `k` fields one at
    /// a time decodes the whole bundle `k` times. This decodes each line once and
    /// takes every requested field from it, which is what makes a column read
    /// cheaper than `records()` rather than more expensive.
    ///
    /// Returns `None` if any requested field is absent from the schema. The
    /// returned vectors are parallel and row-aligned with each other.
    pub fn columns(&self, fields: &[&str]) -> Option<Vec<Vec<Value>>> {
        for f in fields {
            let known = self
                .bundle_schema
                .base_fields
                .iter()
                .chain(self.bundle_schema.fiber_fields.iter())
                .any(|d| d.name == *f);
            if !known {
                return None;
            }
        }

        let pk_field = self.pk_field().map(|s| s.to_string());
        let overlay_records: Vec<Record> = self
            .overlay
            .read()
            .map_or(Vec::new(), |s| s.records().collect());
        let overlay_keys: HashSet<String> = overlay_records
            .iter()
            .filter_map(|r| {
                pk_field
                    .as_deref()
                    .and_then(|f| r.get(f))
                    .map(|v| v.key_repr())
            })
            .collect();
        let tombstones: HashSet<String> = self
            .tombstones
            .read()
            .map_or(HashSet::new(), |ts| ts.clone());

        let cap = overlay_records.len() + self.base.len();
        let mut out: Vec<Vec<Value>> = fields.iter().map(|_| Vec::with_capacity(cap)).collect();

        for r in &overlay_records {
            for (c, f) in fields.iter().enumerate() {
                out[c].push(r.get(*f).cloned().unwrap_or(Value::Null));
            }
        }

        let needs_key = pk_field.is_some() && !(overlay_keys.is_empty() && tombstones.is_empty());
        for i in 0..self.base.len() {
            let Some(jv) = self.base.get(i) else { continue };
            let serde_json::Value::Object(map) = &jv else {
                continue;
            };
            if needs_key {
                if let Some(pk_f) = pk_field.as_deref() {
                    if let Some(pk) = map.get(pk_f).map(Self::json_val) {
                        let key_str = pk.key_repr();
                        if tombstones.contains(&key_str) || overlay_keys.contains(&key_str) {
                            continue;
                        }
                    }
                }
            }
            for (c, f) in fields.iter().enumerate() {
                out[c].push(map.get(*f).map(Self::json_val).unwrap_or(Value::Null));
            }
        }
        Some(out)
    }

    /// `columns`, restricted to numeric values; `None` if any field is absent or
    /// carries a value that is not numeric.
    pub fn numeric_columns(&self, fields: &[&str]) -> Option<Vec<Vec<f64>>> {
        let cols = self.columns(fields)?;
        let mut out = Vec::with_capacity(cols.len());
        for col in cols {
            let mut c = Vec::with_capacity(col.len());
            for v in col {
                c.push(v.as_f64()?);
            }
            out.push(c);
        }
        Some(out)
    }

    /// Distinct values for a field (merged).
    pub fn distinct(&self, field: &str) -> Vec<Value> {
        let mut seen: HashSet<Value> = HashSet::new();

        // Overlay values.
        if let Ok(store) = self.overlay.read() {
            for v in store.distinct(field) {
                seen.insert(v);
            }
        }

        // Base values (skip tombstoned/overridden records).
        let pk_field = self.pk_field();
        let overlay_keys = self.overlay_pk_set();
        let tombstones = self.tombstones.read().ok();

        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones, &overlay_keys) {
                    continue;
                }
                if let Some(val) = record.get(field) {
                    seen.insert(val.clone());
                }
            }
        }

        seen.into_iter().collect()
    }

    /// Indexed values for a field (from overlay; base has no index).
    pub fn indexed_values(&self, field: &str) -> Vec<Value> {
        self.overlay
            .read()
            .map_or(Vec::new(), |s| s.indexed_values(field))
    }

    /// Anomaly detection — delegates to overlay only (base lacks BaseStorage internals).
    pub fn compute_anomalies(
        &self,
        n_sigma: f64,
        pre_filter: Option<&[QueryCondition]>,
        limit: usize,
    ) -> Vec<AnomalyRecord> {
        self.overlay
            .read()
            .map_or(Vec::new(), |s| s.compute_anomalies(n_sigma, pre_filter, limit))
    }

    /// Vector search — delegates to overlay only.
    pub fn vector_search(
        &self,
        field: &str,
        query: &[f64],
        top_k: usize,
        metric: VectorMetric,
        pre_filter: &[QueryCondition],
    ) -> Vec<(f64, Record)> {
        self.overlay
            .read()
            .map_or(Vec::new(), |s| s.vector_search(field, query, top_k, metric, pre_filter))
    }

    // ── Merged Write Methods ───────────────────────────────────────────────

    pub fn batch_insert(&self, records: &[Record]) -> usize {
        if let Ok(mut store) = self.overlay.write() {
            if let Ok(mut ts) = self.tombstones.write() {
                let pk = self.pk_field();
                for r in records {
                    if let Some(key_str) = pk.and_then(|f| r.get(f)).map(|v| v.key_repr()) {
                        ts.remove(&key_str);
                    }
                }
            }
            store.batch_insert(records)
        } else {
            0
        }
    }

    pub fn upsert(&self, record: &Record) -> bool {
        if let Ok(mut ts) = self.tombstones.write() {
            if let Some(key_str) = self.tombstone_key(record) {
                ts.remove(&key_str);
            }
        }
        self.overlay
            .write()
            .map_or(false, |mut s| s.upsert(record))
    }

    pub fn update_returning(&self, key: &Record, patches: &Record) -> Option<Record> {
        self.overlay
            .write()
            .ok()
            .and_then(|mut s| s.update_returning(key, patches))
    }

    pub fn update_versioned(
        &self,
        key: &Record,
        patches: &Record,
        expected_version: i64,
    ) -> Result<i64, &'static str> {
        self.overlay
            .write()
            .map_err(|_| "lock poisoned")
            .and_then(|mut s| s.update_versioned(key, patches, expected_version))
    }

    pub fn increment(&self, key: &Record, field: &str, amount: f64) -> bool {
        self.overlay
            .write()
            .map_or(false, |mut s| s.increment(key, field, amount))
    }

    pub fn bulk_delete(&self, conditions: &[QueryCondition]) -> usize {
        // Find matching records in overlay + base, tombstone base keys.
        let pk_field = self.pk_field();

        // Delete from overlay.
        let overlay_deleted = self
            .overlay
            .write()
            .map_or(0, |mut s| s.bulk_delete(conditions));

        // Tombstone matching base records.
        let tombstones_guard = self.tombstones.read().ok();
        let overlay_keys = self.overlay_pk_set();
        let mut base_deleted = 0usize;
        let mut unaddressable = 0usize;
        let mut new_tombstones: Vec<String> = Vec::new();

        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if !Self::is_visible(&record, pk_field, &tombstones_guard, &overlay_keys) {
                    continue;
                }
                if conditions.iter().all(|c: &QueryCondition| c.matches(&record)) {
                    match pk_field.and_then(|f| record.get(f)).map(|v| v.key_repr()) {
                        Some(key_str) => {
                            new_tombstones.push(key_str);
                            base_deleted += 1;
                        }
                        // A tombstone IS the primary key, so a base row whose
                        // key column is unreadable cannot be tombstoned at all.
                        // It used to be dropped here silently and not even
                        // counted: the caller got a success and a number that
                        // described a different set of rows than the one its
                        // predicate matched. Counted now, and surfaced by the
                        // caller, so a repair can see it did less than it
                        // asked. Found 2026-09-20 by the Marcella corpus
                        // repair against a short-header bundle.
                        None => unaddressable += 1,
                    }
                }
            }
        }
        drop(tombstones_guard);

        if !new_tombstones.is_empty() {
            if let Ok(mut ts) = self.tombstones.write() {
                for k in new_tombstones {
                    ts.insert(k);
                }
            }
        }

        self.unaddressable_last_bulk_delete
            .store(unaddressable, std::sync::atomic::Ordering::Relaxed);
        overlay_deleted + base_deleted
    }

    /// Rows the last `bulk_delete` matched and could not address, because their
    /// primary-key column is not readable. Zero on a healthy bundle.
    pub fn unaddressable_last_bulk_delete(&self) -> usize {
        self.unaddressable_last_bulk_delete
            .load(std::sync::atomic::Ordering::Relaxed)
    }

    pub fn delete_returning(&self, key: &Record) -> Option<Record> {
        // Try overlay first.
        if let Ok(mut store) = self.overlay.write() {
            if let Some(old) = store.delete_returning(key) {
                return Some(old);
            }
        }
        // Tombstone in base + return the record.
        let pk_field = self.pk_field()?;
        let key_val = key.get(pk_field)?;
        let key_str = key_val.key_repr();
        if self.is_tombstoned(&key_str) {
            return None;
        }
        // Scan base.
        for i in 0..self.base.len() {
            if let Some(jv) = self.base.get(i) {
                let record = Self::json_to_record(&jv);
                if record.get(pk_field) == Some(key_val) {
                    if let Ok(mut ts) = self.tombstones.write() {
                        ts.insert(key_str);
                    }
                    return Some(record);
                }
            }
        }
        None
    }

    // ── Schema Mutation ────────────────────────────────────────────────────

    pub fn drop_field(&self, field_name: &str) -> bool {
        self.overlay
            .write()
            .map_or(false, |mut s| s.drop_field(field_name))
    }

    pub fn add_field(&self, field_def: FieldDef) {
        if let Ok(mut store) = self.overlay.write() {
            store.add_field(field_def);
        }
    }

    /// Declare an index on this overlay bundle.
    ///
    /// **The index covers the overlay only.** The mmap base contributes no
    /// entries — `indexed_values` says as much in its own doc comment — so on
    /// any bundle whose records have been snapshotted, this builds a *partial*
    /// index and returns [`IndexCoverage::OverlayOnly`] saying how many records
    /// it missed.
    ///
    /// TDD-IDX F-4. The full fix — an overlay-level index addressing both mmap
    /// rows and overlay records — is deliberately **not** built, because it has
    /// no consumer: `field_index_graph` takes `&BundleStore`, `/spectral_gap`
    /// returns 501 for mmap-resident bundles, and `DEPTH` refuses for them as
    /// of W-IDX-3. A partial index therefore cannot produce a wrong geometry
    /// answer today, because no geometry answer is produced at all.
    ///
    /// What it *can* do is become wrong silently the day someone lifts the
    /// λ-verbs onto `BundleRef`. Hence the `#[must_use]` return: that lift
    /// cannot wire the index through without the compiler making them look at
    /// the gap. Same move as F-6 — a future silent divergence turned into a
    /// present loud one, rather than a note somebody is supposed to remember.
    pub fn add_index(&self, field_name: &str) -> IndexCoverage {
        if let Ok(mut store) = self.overlay.write() {
            store.add_index(field_name);
        }
        let base_records = self.base.len();
        if base_records == 0 {
            IndexCoverage::Complete
        } else {
            IndexCoverage::OverlayOnly { base_records }
        }
    }

    pub fn truncate(&self) -> usize {
        let base_count = self.base.len();
        // Tombstone ALL base records.
        if let Ok(mut ts) = self.tombstones.write() {
            ts.clear();
            for i in 0..base_count {
                if let Some(jv) = self.base.get(i) {
                    let record = Self::json_to_record(&jv);
                    if let Some(pk_field) = self.pk_field() {
                        if let Some(pk) = record.get(pk_field) {
                            ts.insert(pk.key_repr());
                        }
                    }
                }
            }
        }
        let overlay_count = self
            .overlay
            .write()
            .map_or(0, |mut s| s.truncate());
        base_count + overlay_count
    }

    pub fn bulk_update(&self, conditions: &[QueryCondition], patches: &Record) -> usize {
        self.overlay
            .write()
            .map_or(0, |mut s| s.bulk_update(conditions, patches))
    }

    pub fn expire_ttl(&self, now_epoch_ms: i64) -> usize {
        self.overlay
            .write()
            .map_or(0, |mut s| s.expire_ttl(now_epoch_ms))
    }
}

// ── BundleRef: Unified read-only access to heap or mmap bundles ────────────

/// Enum dispatch for read-only bundle access.
/// Returned by `Engine::bundle()`.
/// Non-null coverage of one declared field over the sampled records.
#[derive(Debug, Clone)]
pub struct FieldCoverage {
    pub field: String,
    /// `"base"` or `"fiber"`.
    pub role: &'static str,
    /// Records in the sample carrying a present, non-`Null` value.
    pub non_null: usize,
    /// `non_null / sampled`. A LOWER BOUND on the bundle when
    /// `complete_scan` is false.
    pub coverage_in_sample: f64,
}

/// Result of [`BundleRef::field_coverage`].
#[derive(Debug, Clone)]
pub struct FieldCoverageReport {
    pub records: usize,
    pub sampled: usize,
    /// True when every record was read, so a zero coverage is established
    /// rather than merely unobserved.
    pub complete_scan: bool,
    pub fields_declared: usize,
    pub fields_non_empty: usize,
    /// Declared fields carrying no value in the sample. On a `complete_scan`
    /// these are empty in the bundle; otherwise they are empty in the window.
    pub fields_empty_in_sample: Vec<String>,
    pub per_field: Vec<FieldCoverage>,
}

pub enum BundleRef<'a> {
    Heap(&'a BundleStore),
    Overlay(&'a OverlayBundle),
}

impl<'a> BundleRef<'a> {
    /// Downcast to heap BundleStore (for analytics that need internal BaseStorage).
    pub fn as_heap(&self) -> Option<&BundleStore> {
        match self {
            BundleRef::Heap(s) => Some(s),
            BundleRef::Overlay(_) => None,
        }
    }

    pub fn schema(&self) -> &BundleSchema {
        match self {
            BundleRef::Heap(s) => &s.schema,
            BundleRef::Overlay(o) => o.schema(),
        }
    }

    pub fn curvature_stats(&self) -> CurvatureStats {
        match self {
            BundleRef::Heap(s) => s.curvature_stats.clone(),
            BundleRef::Overlay(o) => o.curvature_stats(),
        }
    }

    pub fn len(&self) -> usize {
        match self {
            BundleRef::Heap(s) => s.len(),
            BundleRef::Overlay(o) => o.len(),
        }
    }

    pub fn storage_mode(&self) -> &'static str {
        match self {
            BundleRef::Heap(s) => s.storage_mode(),
            BundleRef::Overlay(o) => o.storage_mode(),
        }
    }

    /// **#107 fix.** Polymorphic mutation counter. Heap bundles
    /// return their own; overlay bundles return the overlay-portion
    /// counter (the mmap base is immutable so its mutations are 0).
    pub fn mutation_counter(&self) -> u64 {
        match self {
            BundleRef::Heap(s) => s.mutation_counter(),
            BundleRef::Overlay(o) => o.mutation_counter(),
        }
    }

    pub fn field_names(&self) -> Vec<String> {
        match self {
            BundleRef::Heap(s) => s.schema.base_fields.iter()
                .chain(s.schema.fiber_fields.iter())
                .map(|f| f.name.clone())
                .collect(),
            BundleRef::Overlay(o) => o.field_names(),
        }
    }

    pub fn field_stats(&self) -> std::collections::HashMap<String, FieldStats> {
        match self {
            BundleRef::Heap(s) => s.field_stats().clone(),
            BundleRef::Overlay(o) => o.field_stats(),
        }
    }

    /// Per-field non-null coverage over a bounded sample of records.
    ///
    /// Motivated by the 2026-09-13 Halcyon report: `marcella_source_embeddings_bge_v2`
    /// served 30,356 records whose entire 384-field vector space read back
    /// `Null`, and `/health` reported `curvature 0.0, confidence 1.0` for weeks
    /// because a bundle with no measurable variance is indistinguishable, at
    /// that surface, from a bundle with no data in it. Coverage is the
    /// distinguishing measurement: it asks whether a declared field carries a
    /// value at all, before anything tries to compute over it.
    ///
    /// `max_sample == 0` scans every record. Otherwise the first `max_sample`
    /// records are read and `complete_scan` is false — in which case a zero
    /// coverage is a statement about the SAMPLE, not about the bundle. The
    /// field names say so, deliberately: a field populated only beyond the
    /// sample window would read as empty here, and reporting that as an
    /// established zero would be the same class of mistake this check exists
    /// to catch.
    pub fn field_coverage(&self, max_sample: usize) -> FieldCoverageReport {
        let schema = self.schema();
        let declared: Vec<(String, &'static str)> = schema
            .base_fields
            .iter()
            .map(|f| (f.name.clone(), "base"))
            .chain(schema.fiber_fields.iter().map(|f| (f.name.clone(), "fiber")))
            .collect();

        let total = self.len();
        let mut non_null: std::collections::HashMap<String, usize> =
            declared.iter().map(|(n, _)| (n.clone(), 0usize)).collect();

        let mut sampled = 0usize;
        for rec in self.records() {
            if max_sample > 0 && sampled >= max_sample {
                break;
            }
            sampled += 1;
            for (name, _) in &declared {
                if matches!(rec.get(name), Some(v) if !matches!(v, Value::Null)) {
                    if let Some(c) = non_null.get_mut(name) {
                        *c += 1;
                    }
                }
            }
        }

        let per_field: Vec<FieldCoverage> = declared
            .iter()
            .map(|(name, role)| {
                let n = non_null.get(name).copied().unwrap_or(0);
                FieldCoverage {
                    field: name.clone(),
                    role,
                    non_null: n,
                    coverage_in_sample: if sampled == 0 {
                        0.0
                    } else {
                        n as f64 / sampled as f64
                    },
                }
            })
            .collect();

        // Sorted so the list is deterministic and readable. Schema field order
        // is not reliable here: a bundle created over HTTP has its `fields`
        // object parsed into a HashMap, so declaration order is already lost
        // before this sees it.
        let mut empty: Vec<String> = per_field
            .iter()
            .filter(|f| f.non_null == 0)
            .map(|f| f.field.clone())
            .collect();
        empty.sort();

        FieldCoverageReport {
            records: total,
            sampled,
            complete_scan: max_sample == 0 || sampled >= total,
            fields_declared: declared.len(),
            fields_non_empty: declared.len() - empty.len(),
            fields_empty_in_sample: empty,
            per_field,
        }
    }

    pub fn filtered_query(
        &self,
        conditions: &[QueryCondition],
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> Vec<Record> {
        match self {
            BundleRef::Heap(s) => s.filtered_query(conditions, sort_by, sort_desc, limit, offset),
            BundleRef::Overlay(o) => {
                o.filtered_query(conditions, sort_by, sort_desc, limit, offset)
            }
        }
    }

    pub fn filtered_query_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> Vec<Record> {
        match self {
            BundleRef::Heap(s) => {
                s.filtered_query_ex(conditions, or_conditions, sort_by, sort_desc, limit, offset)
            }
            BundleRef::Overlay(o) => {
                o.filtered_query_ex(conditions, or_conditions, sort_by, sort_desc, limit, offset)
            }
        }
    }

    /// COVER … NEAR (f1=v1, …) WITHIN r [METRIC euclidean|cosine]
    ///
    /// Delegates to `BundleStore::cover_near` for heap bundles;
    /// for overlay bundles falls back to the same linear scan using records().
    pub fn cover_near(
        &self,
        query_point: &[(String, f64)],
        radius: f64,
        metric: Option<&str>,
    ) -> Vec<(Record, f64)> {
        match self {
            BundleRef::Heap(s) => s.cover_near(query_point, radius, metric),
            BundleRef::Overlay(_) => {
                // Generic fallback: linear scan using BundleRef::records()
                crate::bundle::BundleStore::cover_near_records(
                    self.records(),
                    self.schema(),
                    query_point,
                    radius,
                    metric,
                )
            }
        }
    }

    pub fn filtered_query_projected(
        &self,
        conditions: &[QueryCondition],
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
        fields: Option<&[&str]>,
    ) -> (Vec<Record>, usize) {
        match self {
            BundleRef::Heap(s) => {
                s.filtered_query_projected(conditions, sort_by, sort_desc, limit, offset, fields)
            }
            BundleRef::Overlay(o) => {
                o.filtered_query_projected(conditions, sort_by, sort_desc, limit, offset, fields)
            }
        }
    }

    pub fn filtered_query_projected_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_fields: Option<&[(&str, bool)]>,
        limit: Option<usize>,
        offset: Option<usize>,
        fields: Option<&[&str]>,
    ) -> (Vec<Record>, usize) {
        match self {
            BundleRef::Heap(s) => s.filtered_query_projected_ex(
                conditions,
                or_conditions,
                sort_fields,
                limit,
                offset,
                fields,
            ),
            BundleRef::Overlay(o) => o.filtered_query_projected_ex(
                conditions,
                or_conditions,
                sort_fields,
                limit,
                offset,
                fields,
            ),
        }
    }

    pub fn count_where(&self, conditions: &[QueryCondition]) -> usize {
        match self {
            BundleRef::Heap(s) => s.count_where(conditions),
            BundleRef::Overlay(o) => o.count_where(conditions),
        }
    }

    pub fn count_where_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
    ) -> usize {
        match self {
            BundleRef::Heap(s) => s.count_where_ex(conditions, or_conditions),
            BundleRef::Overlay(o) => o.count_where_ex(conditions, or_conditions),
        }
    }

    pub fn exists(&self, conditions: &[QueryCondition]) -> bool {
        match self {
            BundleRef::Heap(s) => s.exists(conditions),
            BundleRef::Overlay(o) => o.exists(conditions),
        }
    }

    pub fn exists_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
    ) -> bool {
        match self {
            BundleRef::Heap(s) => s.exists_ex(conditions, or_conditions),
            BundleRef::Overlay(o) => o.exists_ex(conditions, or_conditions),
        }
    }

    pub fn point_query(&self, key: &Record) -> Option<Record> {
        match self {
            BundleRef::Heap(s) => s.point_query(key),
            BundleRef::Overlay(o) => o.point_query(key),
        }
    }

    pub fn range_query(&self, field: &str, values: &[Value]) -> Vec<Record> {
        match self {
            BundleRef::Heap(s) => s.range_query(field, values),
            BundleRef::Overlay(o) => o.range_query(field, values),
        }
    }

    pub fn records(&self) -> Box<dyn Iterator<Item = Record> + '_> {
        match self {
            BundleRef::Heap(s) => s.records(),
            BundleRef::Overlay(o) => o.records(),
        }
    }

    /// One field's values in `records()` order, without building a `Record` per
    /// row. Available whether the bundle is heap-resident or memory-mapped, so a
    /// caller does not have to know which it holds. Two columns of the same
    /// bundle are row-aligned and can be zipped.
    pub fn column(&self, field: &str) -> Option<Vec<Value>> {
        match self {
            BundleRef::Heap(s) => s.column(field),
            BundleRef::Overlay(o) => o.column(field),
        }
    }

    /// `column`, restricted to numeric values; `None` if the field is absent or
    /// any stored value in it is not numeric.
    pub fn numeric_column(&self, field: &str) -> Option<Vec<f64>> {
        match self {
            BundleRef::Heap(s) => s.numeric_column(field),
            BundleRef::Overlay(o) => o.numeric_column(field),
        }
    }

    /// Several fields at once, row-aligned, in `records()` order. Prefer this to
    /// repeated `column` calls: stored rows are decoded once per read, so asking
    /// for fields one at a time decodes the bundle once per field.
    pub fn columns(&self, fields: &[&str]) -> Option<Vec<Vec<Value>>> {
        match self {
            BundleRef::Heap(s) => s.columns(fields),
            BundleRef::Overlay(o) => o.columns(fields),
        }
    }

    /// `columns`, restricted to numeric values.
    pub fn numeric_columns(&self, fields: &[&str]) -> Option<Vec<Vec<f64>>> {
        match self {
            BundleRef::Heap(s) => s.numeric_columns(fields),
            BundleRef::Overlay(o) => o.numeric_columns(fields),
        }
    }

    pub fn distinct(&self, field: &str) -> Vec<Value> {
        match self {
            BundleRef::Heap(s) => s.distinct(field),
            BundleRef::Overlay(o) => o.distinct(field),
        }
    }

    pub fn indexed_values(&self, field: &str) -> Vec<Value> {
        match self {
            BundleRef::Heap(s) => s.indexed_values(field),
            BundleRef::Overlay(o) => o.indexed_values(field),
        }
    }

    pub fn compute_anomalies(
        &self,
        n_sigma: f64,
        pre_filter: Option<&[QueryCondition]>,
        limit: usize,
    ) -> Vec<AnomalyRecord> {
        match self {
            BundleRef::Heap(s) => s.compute_anomalies(n_sigma, pre_filter, limit),
            BundleRef::Overlay(o) => o.compute_anomalies(n_sigma, pre_filter, limit),
        }
    }

    pub fn vector_search(
        &self,
        field: &str,
        query: &[f64],
        top_k: usize,
        metric: VectorMetric,
        pre_filter: &[QueryCondition],
    ) -> Vec<(f64, Record)> {
        match self {
            BundleRef::Heap(s) => s.vector_search(field, query, top_k, metric, pre_filter),
            BundleRef::Overlay(o) => o.vector_search(field, query, top_k, metric, pre_filter),
        }
    }

    // ── Convenience aliases / analytics helpers ────────────────────────────

    pub fn get_field_stats(&self) -> std::collections::HashMap<String, FieldStats> {
        self.field_stats()
    }

    pub fn stats(&self) -> BundleStats {
        match self {
            BundleRef::Heap(s) => s.stats(),
            BundleRef::Overlay(_) => BundleStats {
                name: self.schema().name.clone(),
                record_count: self.len(),
                base_fields: self.schema().base_fields.len(),
                fiber_fields: self.schema().fiber_fields.len(),
                indexed_fields: self.schema().indexed_fields.clone(),
                storage_mode: self.storage_mode().to_string(),
                index_sizes: Vec::new(),
                field_cardinalities: Vec::new(),
            },
        }
    }

    pub fn explain(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_fields: Option<&[(&str, bool)]>,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> QueryPlan {
        match self {
            BundleRef::Heap(s) => s.explain(conditions, or_conditions, sort_fields, limit, offset),
            BundleRef::Overlay(_) => QueryPlan {
                scan_type: "overlay_merge_scan".to_string(),
                total_records: self.len(),
                index_scans: Vec::new(),
                full_scan_conditions: conditions.iter().map(|c| format!("{:?}", c)).collect(),
                or_group_count: or_conditions.map_or(0, |g| g.len()),
                has_sort: sort_fields.is_some(),
                has_limit: limit.is_some(),
                has_offset: offset.is_some(),
                storage_mode: "mmap+overlay".to_string(),
                #[cfg(feature = "kahler")]
                commutativity_class: None,
            },
        }
    }

    pub fn scalar_curvature(&self) -> f64 {
        match self {
            BundleRef::Heap(s) => curvature::scalar_curvature(s),
            BundleRef::Overlay(o) => o.curvature_stats().mean(),
        }
    }

    pub fn base_point(&self, key: &Record) -> BasePoint {
        match self {
            BundleRef::Heap(s) => s.base_point(key),
            BundleRef::Overlay(_) => Default::default(),
        }
    }

    pub fn holonomy(&self, loop_keys: &[Record]) -> f64 {
        match self {
            BundleRef::Heap(s) => curvature::holonomy(s, loop_keys),
            BundleRef::Overlay(_) => 0.0,
        }
    }

    pub fn betti_numbers(&self) -> (usize, usize) {
        match self {
            BundleRef::Heap(s) => spectral::betti_numbers(s),
            BundleRef::Overlay(_) => (0, 0),
        }
    }

    pub fn entropy(&self) -> f64 {
        match self {
            BundleRef::Heap(s) => spectral::entropy(s),
            BundleRef::Overlay(_) => 0.0,
        }
    }

    pub fn spectral_gap(&self) -> f64 {
        match self {
            BundleRef::Heap(s) => spectral::spectral_gap(s).or_zero(),
            BundleRef::Overlay(_) => 0.0,
        }
    }

    pub fn free_energy(&self, tau: f64) -> f64 {
        match self {
            BundleRef::Heap(s) => curvature::free_energy(s, tau),
            BundleRef::Overlay(_) => 0.0,
        }
    }

    pub fn thermodynamic_profile(&self, taus: &[f64]) -> Vec<curvature::ThermoPoint> {
        match self {
            BundleRef::Heap(s) => curvature::thermodynamic_profile(s, taus),
            BundleRef::Overlay(_) => vec![],
        }
    }

    pub fn pullback_curvature(
        &self,
        right: &BundleRef<'_>,
        left_field: &str,
        right_field: &str,
    ) -> Result<join::PullbackReport, String> {
        match (self, right) {
            (BundleRef::Heap(l), BundleRef::Heap(r)) => {
                Ok(join::pullback_curvature(l, r, left_field, right_field))
            }
            _ => Err("pullback curvature requires heap mode (not overlay)".into()),
        }
    }

    pub fn geodesic_distance(
        &self,
        bp_a: crate::types::BasePoint,
        bp_b: crate::types::BasePoint,
        max_hops: usize,
    ) -> Option<f64> {
        match self {
            BundleRef::Heap(s) => spectral::geodesic_distance(s, bp_a, bp_b, max_hops),
            BundleRef::Overlay(_) => None,
        }
    }

    pub fn geodesic_path(
        &self,
        bp_a: crate::types::BasePoint,
        bp_b: crate::types::BasePoint,
        max_hops: usize,
    ) -> Option<Vec<crate::types::BasePoint>> {
        match self {
            BundleRef::Heap(s) => spectral::geodesic_path(s, bp_a, bp_b, max_hops),
            BundleRef::Overlay(_) => None,
        }
    }

    pub fn all_base_points(&self) -> std::collections::HashSet<crate::types::BasePoint> {
        match self {
            BundleRef::Heap(s) => s.all_base_points(),
            BundleRef::Overlay(_) => std::collections::HashSet::new(),
        }
    }

    pub fn metric_tensor(&self) -> metric::MetricTensorInfo {
        match self {
            BundleRef::Heap(s) => metric::metric_tensor(s),
            BundleRef::Overlay(_) => metric::MetricTensorInfo {
                matrix: vec![],
                eigenvalues: vec![],
                condition_number: 0.0,
                effective_dimension: 0.0,
                field_names: vec![],
            },
        }
    }
}

// ── BundleMut: Unified mutable access to heap or mmap bundles ──────────────

/// Enum dispatch for mutable bundle access.
/// Returned by `Engine::bundle_mut()`.
/// How much of a bundle an index actually covers.
///
/// TDD-IDX F-4. On a heap bundle an index covers every record, so this is
/// always `Complete` and the type is invisible. On an mmap-backed bundle the
/// index is built from the overlay only — the mmap base contributes no entries
/// — so it covers whatever has been written since the last snapshot and
/// nothing before it.
///
/// `#[must_use]` on purpose: the gap is harmless while nothing reads the index
/// on that path, and becomes a silently-wrong geometry answer the moment the
/// λ-verbs are lifted onto `BundleRef`. Forcing the caller to look is cheaper
/// than an overlay-level merged index built for a consumer that does not exist
/// yet, and safer than a comment.
#[must_use = "an index on an mmap-backed bundle covers the overlay only; the               mmap base contributes no entries. Handle OverlayOnly explicitly               before treating this index as complete — see TDD-IDX F-4."]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IndexCoverage {
    /// Every record in the bundle is indexed.
    Complete,
    /// Only the overlay is indexed; `base_records` records in the mmap base
    /// contribute nothing to the field index.
    OverlayOnly { base_records: usize },
}

impl IndexCoverage {
    /// True when the index covers every record.
    pub fn is_complete(self) -> bool {
        matches!(self, IndexCoverage::Complete)
    }

    /// Records the index does not cover.
    pub fn uncovered(self) -> usize {
        match self {
            IndexCoverage::Complete => 0,
            IndexCoverage::OverlayOnly { base_records } => base_records,
        }
    }
}


pub enum BundleMut<'a> {
    Heap(&'a mut BundleStore),
    Overlay(&'a OverlayBundle),
}

impl<'a> BundleMut<'a> {
    /// Convert to a read-only BundleRef (borrows self).
    pub fn as_ref(&self) -> BundleRef<'_> {
        match self {
            BundleMut::Heap(s) => BundleRef::Heap(s),
            BundleMut::Overlay(o) => BundleRef::Overlay(o),
        }
    }

    // ── Read methods (same as BundleRef) ───────────────────────────────────

    pub fn as_heap(&self) -> Option<&BundleStore> {
        match self {
            BundleMut::Heap(s) => Some(s),
            BundleMut::Overlay(_) => None,
        }
    }

    pub fn as_heap_mut(&mut self) -> Option<&mut BundleStore> {
        match self {
            BundleMut::Heap(s) => Some(s),
            BundleMut::Overlay(_) => None,
        }
    }

    pub fn schema(&self) -> &BundleSchema {
        match self {
            BundleMut::Heap(s) => &s.schema,
            BundleMut::Overlay(o) => o.schema(),
        }
    }

    pub fn curvature_stats(&self) -> CurvatureStats {
        match self {
            BundleMut::Heap(s) => s.curvature_stats.clone(),
            BundleMut::Overlay(o) => o.curvature_stats(),
        }
    }

    pub fn len(&self) -> usize {
        match self {
            BundleMut::Heap(s) => s.len(),
            BundleMut::Overlay(o) => o.len(),
        }
    }

    pub fn filtered_query(
        &self,
        conditions: &[QueryCondition],
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> Vec<Record> {
        match self {
            BundleMut::Heap(s) => s.filtered_query(conditions, sort_by, sort_desc, limit, offset),
            BundleMut::Overlay(o) => {
                o.filtered_query(conditions, sort_by, sort_desc, limit, offset)
            }
        }
    }

    pub fn filtered_query_ex(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_by: Option<&str>,
        sort_desc: bool,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> Vec<Record> {
        match self {
            BundleMut::Heap(s) => {
                s.filtered_query_ex(conditions, or_conditions, sort_by, sort_desc, limit, offset)
            }
            BundleMut::Overlay(o) => {
                o.filtered_query_ex(conditions, or_conditions, sort_by, sort_desc, limit, offset)
            }
        }
    }

    pub fn point_query(&self, key: &Record) -> Option<Record> {
        match self {
            BundleMut::Heap(s) => s.point_query(key),
            BundleMut::Overlay(o) => o.point_query(key),
        }
    }

    pub fn records(&self) -> Box<dyn Iterator<Item = Record> + '_> {
        match self {
            BundleMut::Heap(s) => s.records(),
            BundleMut::Overlay(o) => o.records(),
        }
    }

    pub fn count_where(&self, conditions: &[QueryCondition]) -> usize {
        match self {
            BundleMut::Heap(s) => s.count_where(conditions),
            BundleMut::Overlay(o) => o.count_where(conditions),
        }
    }

    pub fn exists(&self, conditions: &[QueryCondition]) -> bool {
        match self {
            BundleMut::Heap(s) => s.exists(conditions),
            BundleMut::Overlay(o) => o.exists(conditions),
        }
    }

    pub fn distinct(&self, field: &str) -> Vec<Value> {
        match self {
            BundleMut::Heap(s) => s.distinct(field),
            BundleMut::Overlay(o) => o.distinct(field),
        }
    }

    pub fn storage_mode(&self) -> &'static str {
        match self {
            BundleMut::Heap(s) => s.storage_mode(),
            BundleMut::Overlay(o) => o.storage_mode(),
        }
    }

    /// **#107 fix.** See `BundleRef::mutation_counter` for semantics.
    pub fn mutation_counter(&self) -> u64 {
        match self {
            BundleMut::Heap(s) => s.mutation_counter(),
            BundleMut::Overlay(o) => o.mutation_counter(),
        }
    }

    pub fn field_names(&self) -> Vec<String> {
        match self {
            BundleMut::Heap(s) => s.schema.base_fields.iter()
                .chain(s.schema.fiber_fields.iter())
                .map(|f| f.name.clone())
                .collect(),
            BundleMut::Overlay(o) => o.field_names(),
        }
    }

    pub fn field_stats(&self) -> std::collections::HashMap<String, FieldStats> {
        match self {
            BundleMut::Heap(s) => s.field_stats().clone(),
            BundleMut::Overlay(o) => o.field_stats(),
        }
    }

    pub fn compute_anomalies(
        &self,
        n_sigma: f64,
        pre_filter: Option<&[QueryCondition]>,
        limit: usize,
    ) -> Vec<AnomalyRecord> {
        match self {
            BundleMut::Heap(s) => s.compute_anomalies(n_sigma, pre_filter, limit),
            BundleMut::Overlay(o) => o.compute_anomalies(n_sigma, pre_filter, limit),
        }
    }

    // ── Convenience aliases / analytics helpers ────────────────────────────

    pub fn get_field_stats(&self) -> std::collections::HashMap<String, FieldStats> {
        self.field_stats()
    }

    pub fn stats(&self) -> BundleStats {
        match self {
            BundleMut::Heap(s) => s.stats(),
            BundleMut::Overlay(_) => BundleStats {
                name: self.schema().name.clone(),
                record_count: self.len(),
                base_fields: self.schema().base_fields.len(),
                fiber_fields: self.schema().fiber_fields.len(),
                indexed_fields: self.schema().indexed_fields.clone(),
                storage_mode: self.storage_mode().to_string(),
                index_sizes: Vec::new(),
                field_cardinalities: Vec::new(),
            },
        }
    }

    pub fn base_point(&self, key: &Record) -> BasePoint {
        match self {
            BundleMut::Heap(s) => s.base_point(key),
            BundleMut::Overlay(_) => Default::default(),
        }
    }

    pub fn explain(
        &self,
        conditions: &[QueryCondition],
        or_conditions: Option<&[Vec<QueryCondition>]>,
        sort_fields: Option<&[(&str, bool)]>,
        limit: Option<usize>,
        offset: Option<usize>,
    ) -> QueryPlan {
        match self {
            BundleMut::Heap(s) => s.explain(conditions, or_conditions, sort_fields, limit, offset),
            BundleMut::Overlay(_) => QueryPlan {
                scan_type: "overlay_merge_scan".to_string(),
                total_records: self.len(),
                index_scans: Vec::new(),
                full_scan_conditions: conditions.iter().map(|c| format!("{:?}", c)).collect(),
                or_group_count: or_conditions.map_or(0, |g| g.len()),
                has_sort: sort_fields.is_some(),
                has_limit: limit.is_some(),
                has_offset: offset.is_some(),
                storage_mode: "mmap+overlay".to_string(),
                #[cfg(feature = "kahler")]
                commutativity_class: None,
            },
        }
    }

    pub fn scalar_curvature(&self) -> f64 {
        match self {
            BundleMut::Heap(s) => curvature::scalar_curvature(s),
            BundleMut::Overlay(o) => o.curvature_stats().mean(),
        }
    }

    pub fn holonomy(&self, loop_keys: &[Record]) -> f64 {
        match self {
            BundleMut::Heap(s) => curvature::holonomy(s, loop_keys),
            BundleMut::Overlay(_) => 0.0,
        }
    }

    pub fn betti_numbers(&self) -> (usize, usize) {
        match self {
            BundleMut::Heap(s) => spectral::betti_numbers(s),
            BundleMut::Overlay(_) => (0, 0),
        }
    }

    pub fn entropy(&self) -> f64 {
        match self {
            BundleMut::Heap(s) => spectral::entropy(s),
            BundleMut::Overlay(_) => 0.0,
        }
    }

    pub fn spectral_gap(&self) -> f64 {
        match self {
            BundleMut::Heap(s) => spectral::spectral_gap(s).or_zero(),
            BundleMut::Overlay(_) => 0.0,
        }
    }

    pub fn free_energy(&self, tau: f64) -> f64 {
        match self {
            BundleMut::Heap(s) => curvature::free_energy(s, tau),
            BundleMut::Overlay(_) => 0.0,
        }
    }

    pub fn thermodynamic_profile(&self, taus: &[f64]) -> Vec<curvature::ThermoPoint> {
        match self {
            BundleMut::Heap(s) => curvature::thermodynamic_profile(s, taus),
            BundleMut::Overlay(_) => vec![],
        }
    }

    pub fn geodesic_distance(
        &self,
        bp_a: crate::types::BasePoint,
        bp_b: crate::types::BasePoint,
        max_hops: usize,
    ) -> Option<f64> {
        match self {
            BundleMut::Heap(s) => spectral::geodesic_distance(s, bp_a, bp_b, max_hops),
            BundleMut::Overlay(_) => None,
        }
    }

    pub fn geodesic_path(
        &self,
        bp_a: crate::types::BasePoint,
        bp_b: crate::types::BasePoint,
        max_hops: usize,
    ) -> Option<Vec<crate::types::BasePoint>> {
        match self {
            BundleMut::Heap(s) => spectral::geodesic_path(s, bp_a, bp_b, max_hops),
            BundleMut::Overlay(_) => None,
        }
    }

    pub fn all_base_points(&self) -> std::collections::HashSet<crate::types::BasePoint> {
        match self {
            BundleMut::Heap(s) => s.all_base_points(),
            BundleMut::Overlay(_) => std::collections::HashSet::new(),
        }
    }

    pub fn metric_tensor(&self) -> metric::MetricTensorInfo {
        match self {
            BundleMut::Heap(s) => metric::metric_tensor(s),
            BundleMut::Overlay(_) => metric::MetricTensorInfo {
                matrix: vec![],
                eigenvalues: vec![],
                condition_number: 0.0,
                effective_dimension: 0.0,
                field_names: vec![],
            },
        }
    }

    pub fn execute_transaction(
        &mut self,
        ops: &[TransactionOp],
    ) -> Result<Vec<TransactionResult>, String> {
        match self {
            BundleMut::Heap(s) => s.execute_transaction(ops),
            BundleMut::Overlay(_) => Err("transactions not supported in mmap mode".to_string()),
        }
    }

    // ── Write methods ──────────────────────────────────────────────────────

    pub fn insert(&mut self, record: &Record) {
        match self {
            BundleMut::Heap(s) => s.insert(record),
            BundleMut::Overlay(o) => o.insert(record),
        }
    }

    pub fn batch_insert(&mut self, records: &[Record]) -> usize {
        match self {
            BundleMut::Heap(s) => s.batch_insert(records),
            BundleMut::Overlay(o) => o.batch_insert(records),
        }
    }

    pub fn upsert(&mut self, record: &Record) -> bool {
        match self {
            BundleMut::Heap(s) => s.upsert(record),
            BundleMut::Overlay(o) => o.upsert(record),
        }
    }

    pub fn update(&mut self, key: &Record, patches: &Record) -> bool {
        match self {
            BundleMut::Heap(s) => s.update(key, patches),
            BundleMut::Overlay(o) => o.update(key, patches),
        }
    }

    pub fn update_returning(&mut self, key: &Record, patches: &Record) -> Option<Record> {
        match self {
            BundleMut::Heap(s) => s.update_returning(key, patches),
            BundleMut::Overlay(o) => o.update_returning(key, patches),
        }
    }

    pub fn update_versioned(
        &mut self,
        key: &Record,
        patches: &Record,
        expected_version: i64,
    ) -> Result<i64, &'static str> {
        match self {
            BundleMut::Heap(s) => s.update_versioned(key, patches, expected_version),
            BundleMut::Overlay(o) => o.update_versioned(key, patches, expected_version),
        }
    }

    pub fn increment(&mut self, key: &Record, field: &str, amount: f64) -> bool {
        match self {
            BundleMut::Heap(s) => s.increment(key, field, amount),
            BundleMut::Overlay(o) => o.increment(key, field, amount),
        }
    }

    pub fn delete(&mut self, key: &Record) -> bool {
        match self {
            BundleMut::Heap(s) => s.delete(key),
            BundleMut::Overlay(o) => {
                let key_str = o.tombstone_key(key).unwrap_or_default();
                o.delete(&key_str, Some(key));
                true
            }
        }
    }

    pub fn delete_returning(&mut self, key: &Record) -> Option<Record> {
        match self {
            BundleMut::Heap(s) => s.delete_returning(key),
            BundleMut::Overlay(o) => o.delete_returning(key),
        }
    }

    pub fn bulk_delete(&mut self, conditions: &[QueryCondition]) -> usize {
        match self {
            BundleMut::Heap(s) => s.bulk_delete(conditions),
            BundleMut::Overlay(o) => o.bulk_delete(conditions),
        }
    }

    /// Rows the last `bulk_delete` matched and could not address. Always zero
    /// on the heap path, where a matched row is deleted at its own base point.
    pub fn unaddressable_last_bulk_delete(&self) -> usize {
        match self {
            BundleMut::Heap(_) => 0,
            BundleMut::Overlay(o) => o.unaddressable_last_bulk_delete(),
        }
    }

    pub fn bulk_update(&mut self, conditions: &[QueryCondition], patches: &Record) -> usize {
        match self {
            BundleMut::Heap(s) => s.bulk_update(conditions, patches),
            BundleMut::Overlay(o) => o.bulk_update(conditions, patches),
        }
    }

    pub fn truncate(&mut self) -> usize {
        match self {
            BundleMut::Heap(s) => s.truncate(),
            BundleMut::Overlay(o) => o.truncate(),
        }
    }

    pub fn next_auto_id(&mut self) -> i64 {
        match self {
            BundleMut::Heap(s) => s.next_auto_id(),
            BundleMut::Overlay(o) => o.next_auto_id(),
        }
    }

    pub fn drop_field(&mut self, field_name: &str) -> bool {
        match self {
            BundleMut::Heap(s) => s.drop_field(field_name),
            BundleMut::Overlay(o) => o.drop_field(field_name),
        }
    }

    pub fn add_field(&mut self, field_def: FieldDef) {
        match self {
            BundleMut::Heap(s) => s.add_field(field_def),
            BundleMut::Overlay(o) => o.add_field(field_def),
        }
    }

    /// Declare an index, reporting how much of the bundle it covers.
    ///
    /// TDD-IDX F-4. A heap store indexes every record it holds, so that arm is
    /// always `Complete`. The overlay arm is not — see
    /// [`OverlayBundle::add_index`].
    pub fn add_index(&mut self, field_name: &str) -> IndexCoverage {
        match self {
            BundleMut::Heap(s) => {
                s.add_index(field_name);
                IndexCoverage::Complete
            }
            BundleMut::Overlay(o) => o.add_index(field_name),
        }
    }

    pub fn expire_ttl(&mut self, now_epoch_ms: i64) -> usize {
        match self {
            BundleMut::Heap(s) => s.expire_ttl(now_epoch_ms),
            BundleMut::Overlay(o) => o.expire_ttl(now_epoch_ms),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    use crate::types::{BundleSchema, FieldDef, Value as GigiValue};

    /// Write DHOOM text to a temp file and open as MmapBundle.
    fn mmap_from_dhoom(dhoom: &str) -> MmapBundle {
        let mut tmp = NamedTempFile::new().unwrap();
        tmp.write_all(dhoom.as_bytes()).unwrap();
        tmp.flush().unwrap();
        MmapBundle::open(tmp.path()).unwrap()
    }

    /// TDD-11.1: Mmap bundle reads correct data.
    #[test]
    fn tdd_11_1_mmap_reads_correct_data() {
        let dhoom = "items{id@1, name, score}:\nAlice, 95\nBob, 87\nCarol, 42\n";
        let bundle = mmap_from_dhoom(dhoom);

        assert_eq!(bundle.len(), 3);
        assert_eq!(bundle.name(), "items");

        let r0 = bundle.get(0).unwrap();
        assert_eq!(r0["id"], 1);
        assert_eq!(r0["name"], "Alice");
        assert_eq!(r0["score"], 95);

        let r1 = bundle.get(1).unwrap();
        assert_eq!(r1["id"], 2);
        assert_eq!(r1["name"], "Bob");

        let r2 = bundle.get(2).unwrap();
        assert_eq!(r2["id"], 3);
        assert_eq!(r2["name"], "Carol");
        assert_eq!(r2["score"], 42);
    }

    /// TDD-11.2: Point query by index is correct.
    #[test]
    fn tdd_11_2_point_query() {
        let dhoom = "drugs{id@100+10, drug_name, organism|E. coli}:\nrifampin, :S. aureus\namoxicillin\nvancomycin, :K. pneumoniae\n";
        let bundle = mmap_from_dhoom(dhoom);

        assert_eq!(bundle.len(), 3);
        let r0 = bundle.get(0).unwrap();
        assert_eq!(r0["id"], 100);
        assert_eq!(r0["drug_name"], "rifampin");
        assert_eq!(r0["organism"], "S. aureus");

        let r1 = bundle.get(1).unwrap();
        assert_eq!(r1["id"], 110);
        assert_eq!(r1["drug_name"], "amoxicillin");
        assert_eq!(r1["organism"], "E. coli"); // default

        // Out of bounds
        assert!(bundle.get(999).is_none());
    }

    /// TDD-11.3: Sequential scan correctness.
    #[test]
    fn tdd_11_3_sequential_scan() {
        let mut lines = String::from("data{id@1, value}:\n");
        for i in 0..100 {
            lines.push_str(&format!("{}\n", i * 10));
        }
        let bundle = mmap_from_dhoom(&lines);
        assert_eq!(bundle.len(), 100);

        let all: Vec<JsonValue> = bundle.scan().collect();
        assert_eq!(all.len(), 100);

        for (i, rec) in all.iter().enumerate() {
            assert_eq!(rec["id"], (i + 1) as i64);
            assert_eq!(rec["value"], (i * 10) as i64);
        }
    }

    /// **#107 fix.** OverlayBundle exposes a mutation_counter that
    /// bumps on every overlay-side write. Brain endpoints depend on
    /// this for cache invalidation; without it, post-restart bundles
    /// are uncacheable AND inaccessible.
    #[test]
    fn issue_107_overlay_mutation_counter_bumps_on_insert() {
        let dhoom = "items{id@1, val}:\n10\n20\n30\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Fresh overlay: counter starts at 0.
        assert_eq!(overlay.mutation_counter(), 0,
                   "fresh overlay starts at counter=0");

        // Insert → counter bumps.
        let mut rec = Record::new();
        rec.insert("id".into(), GigiValue::Integer(99));
        rec.insert("val".into(), GigiValue::Integer(999));
        overlay.insert(&rec);
        let after_first = overlay.mutation_counter();
        assert!(after_first > 0,
                "counter must bump after insert; got {}", after_first);

        // Second insert bumps again.
        let mut rec2 = Record::new();
        rec2.insert("id".into(), GigiValue::Integer(100));
        rec2.insert("val".into(), GigiValue::Integer(1000));
        overlay.insert(&rec2);
        assert!(overlay.mutation_counter() > after_first,
                "counter must bump on second insert too");
    }

    /// **#107 fix.** BundleRef::mutation_counter dispatches correctly
    /// for both Heap and Overlay variants.
    #[test]
    fn issue_107_bundle_ref_polymorphic_mutation_counter() {
        let dhoom = "items{id@1, val}:\n10\n20\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);
        let ref_overlay = BundleRef::Overlay(&overlay);
        // Polymorphic accessor returns 0 initially.
        assert_eq!(ref_overlay.mutation_counter(), 0);
        // After overlay insert, polymorphic accessor reflects it.
        let mut rec = Record::new();
        rec.insert("id".into(), GigiValue::Integer(7));
        rec.insert("val".into(), GigiValue::Integer(77));
        overlay.insert(&rec);
        assert!(ref_overlay.mutation_counter() > 0);
    }

    /// TDD-11.4: Overlay with BundleStore — insert lands in indexed overlay.
    #[test]
    fn tdd_11_4_overlay_masks_updates() {
        let dhoom = "items{id@1, val}:\n10\n20\n30\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Base record
        let base_r0 = overlay.base().get(0).unwrap();
        assert_eq!(base_r0["val"], 10);

        // Insert into overlay (indexed BundleStore)
        let mut rec = Record::new();
        rec.insert("id".into(), GigiValue::Integer(99));
        rec.insert("val".into(), GigiValue::Integer(999));
        overlay.insert(&rec);

        // Overlay has the record
        let found = overlay.point_query_overlay(&{
            let mut k = Record::new();
            k.insert("id".into(), GigiValue::Integer(99));
            k
        });
        assert!(found.is_some());
        assert_eq!(found.unwrap().get("val"), Some(&GigiValue::Integer(999)));

        // Overlay count
        assert_eq!(overlay.overlay_len(), 1);
    }

    /// TDD-11.5: Tombstones hide mmap records.
    #[test]
    fn tdd_11_5_tombstones_hide_records() {
        let dhoom = "items{id@1, val}:\n10\n20\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Delete key "1"
        overlay.delete("1", None);
        assert!(overlay.is_tombstoned("1"));
        assert_eq!(overlay.tombstone_len(), 1);

        // Base data still exists
        assert!(overlay.base().get(0).is_some());
    }

    /// TDD-11.6: Base scan still works through overlay.
    #[test]
    fn tdd_11_6_scan_base_still_works() {
        let dhoom = "items{id@1, val}:\n10\n20\n30\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Base scan still returns all 3 records
        let all: Vec<JsonValue> = overlay.base().scan().collect();
        assert_eq!(all.len(), 3);
    }

    /// **#106 fix** — `OverlayBundle::len()` must NOT double-count when the
    /// overlay shadows a base record (same primary key). This is the WAL
    /// replay double-count bug: pre-checkpoint record persists in mmap base;
    /// a post-checkpoint update lands in the overlay; both base and overlay
    /// hold the key. `records()` already deduplicates by overlay-shadows-base
    /// (line 959); `len()` must match.
    ///
    /// Spec: tasks #106 in the project tracker.
    #[test]
    fn issue_106_len_does_not_double_count_overlay_shadowing_base() {
        // Base mmap has 3 records: keys 1, 2, 3.
        let dhoom = "items{id@1, val}:\n10\n20\n30\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Baseline: 3 records visible, no overlay/tombstones.
        assert_eq!(overlay.len(), 3, "baseline: only base records");
        assert_eq!(overlay.records().count(), 3, "records() agrees");

        // Insert a NEW record (key=99): both counts go to 4.
        let mut new_rec = Record::new();
        new_rec.insert("id".into(), GigiValue::Integer(99));
        new_rec.insert("val".into(), GigiValue::Integer(999));
        overlay.insert(&new_rec);
        assert_eq!(overlay.len(), 4, "after new insert: 3 base + 1 overlay");
        assert_eq!(overlay.records().count(), 4);

        // Update an EXISTING base record (key=2, same PK as base[1]):
        // overlay grows by 1, but the logical record count should stay 4.
        // **This is the #106 bug:** without the fix, len() returns 5 here
        // because base.len()=3 + overlay.len()=2 = 5, ignoring that one
        // overlay entry shadows a base entry.
        let mut update_rec = Record::new();
        update_rec.insert("id".into(), GigiValue::Integer(2));
        update_rec.insert("val".into(), GigiValue::Integer(2000));
        overlay.insert(&update_rec);
        assert_eq!(
            overlay.len(),
            4,
            "after shadowing-update of key=2: still 4 logical records \
             (base[1] is shadowed, not added). records().count() agrees: {}",
            overlay.records().count()
        );
        assert_eq!(
            overlay.records().count(),
            4,
            "records() must be consistent with len()"
        );

        // Update the SAME key=2 again — should not change the count.
        let mut update_rec2 = Record::new();
        update_rec2.insert("id".into(), GigiValue::Integer(2));
        update_rec2.insert("val".into(), GigiValue::Integer(2222));
        overlay.insert(&update_rec2);
        assert_eq!(overlay.len(), 4, "re-update of same key: still 4");
        assert_eq!(overlay.records().count(), 4);

        // Delete key=2 (which is now in both base AND overlay):
        // base.len()=3, ts=1, overlay loses key=2.
        // Logical count: 3 - 1 (tombstoned base[1]) + 1 (new[99]) = 3.
        //
        // Note: `OverlayBundle::delete` takes a tombstone key string in
        // the format `records()` filters by, i.e. `pk.key_repr()`
        // on the extracted `Value`. For `Value::Integer(2)` that's
        // `"Integer(2)"`. Callers passing the raw "2" produce a
        // tombstone that won't filter the base record (separate API-
        // ergonomics issue; not in scope for #106).
        let mut del_key = Record::new();
        del_key.insert("id".into(), GigiValue::Integer(2));
        overlay.delete("Integer(2)", Some(&del_key));
        assert_eq!(
            overlay.records().count(),
            3,
            "after delete of key=2: records() should give 3 (only 99 from \
             overlay + {{1, 3}} from base; base[2] filtered by tombstone)",
        );
        assert_eq!(
            overlay.len(),
            3,
            "after delete of key=2: base(3) - ts(1) - shadow(0, since key=2 \
             was removed from overlay) + overlay(1, just key=99) = 3",
        );
    }

    /// **#165 (post-#106 follow-up).** `OverlayBundle::insert` must
    /// lift a prior tombstone for the SAME PK regardless of which
    /// field happens to come first in the Record's `HashMap`
    /// iteration order. Pre-fix, `insert` used
    /// `record.values().next()` to pick the "key" — which depends on
    /// `HashMap` bucket order (randomized per-process). On a record
    /// like `{id: Integer(3), val: Integer(333)}`, the iterator might
    /// yield `Integer(333)` first, and the tombstone-remove would
    /// look for `"Integer(333)"` instead of `"Integer(3)"` —
    /// missing the actual tombstone. Post-fix, the lift uses
    /// `tombstone_key(record)` which extracts the PK by *name* via
    /// the schema's `pk_field()`.
    ///
    /// To make this test deterministic (rather than relying on a
    /// lucky `HashMap` seed), we force the failure shape: build many
    /// records with the same PK and varied non-PK fields, and assert
    /// that for ALL of them the tombstone-lift works correctly.
    /// Before the fix this would fail intermittently across runs;
    /// after the fix it succeeds every time.
    #[test]
    fn issue_165_insert_lifts_tombstone_by_pk_not_first_value() {
        let dhoom = "items{id@1, val}:\n10\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Try the delete-then-reinsert cycle for many distinct values
        // of the non-PK `val` field. Each iteration:
        //   1. Delete key=1 → tombstone "Integer(1)".
        //   2. Re-insert key=1 with a fresh `val`.
        //   3. Assert the tombstone is gone (insert lifted it).
        //   4. Clear overlay + tombstones for next iteration.
        for val in [42_i64, 999, -1, 0, 7777777, 1] {
            let mut del_key = Record::new();
            del_key.insert("id".into(), GigiValue::Integer(1));
            overlay.delete("Integer(1)", Some(&del_key));
            assert!(
                overlay.is_tombstoned("Integer(1)"),
                "tombstone should be set after delete for val={val}"
            );

            // Re-insert: a Record with both `id` and `val`. The HashMap
            // iteration order between these is random per Rust process,
            // but the tombstone-lift should succeed regardless of which
            // one .values().next() would have picked.
            let mut new_rec = Record::new();
            new_rec.insert("id".into(), GigiValue::Integer(1));
            new_rec.insert("val".into(), GigiValue::Integer(val));
            overlay.insert(&new_rec);

            assert!(
                !overlay.is_tombstoned("Integer(1)"),
                "tombstone for key=1 must be lifted by insert (val={val}); pre-#165 \
                 this could non-deterministically fail when HashMap order put `val` \
                 ahead of `id`"
            );

            overlay.clear_overlay();
        }
    }

    /// **#106 corollary** — len() consistency under arbitrary
    /// insert/delete sequences. Property test: after any sequence of
    /// inserts and deletes, `len() == records().count()`.
    #[test]
    fn issue_106_len_matches_records_count_under_arbitrary_ops() {
        // Base mmap has 5 records: keys 1..=5.
        let dhoom = "items{id@1, val}:\n10\n20\n30\n40\n50\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        // Sequence of ops mixing shadowing inserts, new inserts, and deletes.
        // Each op-and-check pair asserts the invariant len() == records().count().
        let ops: Vec<(&str, i64, Option<i64>)> = vec![
            ("insert", 6, Some(60)),   // new key
            ("insert", 1, Some(100)),  // shadow base key=1
            ("insert", 7, Some(70)),   // new key
            ("delete", 3, None),       // tombstone base key=3
            ("insert", 3, Some(333)),  // re-insert key=3 (lifts tombstone, shadows base)
            ("insert", 1, Some(101)),  // re-update shadowed key=1
            ("delete", 6, None),       // delete new key=6
        ];
        for (op, key, val) in ops {
            match op {
                "insert" => {
                    let mut r = Record::new();
                    r.insert("id".into(), GigiValue::Integer(key));
                    if let Some(v) = val {
                        r.insert("val".into(), GigiValue::Integer(v));
                    }
                    overlay.insert(&r);
                }
                "delete" => {
                    let mut k = Record::new();
                    k.insert("id".into(), GigiValue::Integer(key));
                    // Format matches records()'s tombstone-filter format.
                    overlay.delete(&format!("Integer({key})"), Some(&k));
                }
                _ => unreachable!(),
            }
            assert_eq!(
                overlay.len(),
                overlay.records().count(),
                "invariant broken after op={op} key={key}: len()={}, records().count()={}",
                overlay.len(),
                overlay.records().count()
            );
        }
    }

    /// TDD-11.7: Clear overlay resets everything.
    #[test]
    fn tdd_11_7_compact_clears_overlay() {
        let dhoom = "items{id@1, val}:\n10\n20\n";
        let bundle = mmap_from_dhoom(dhoom);
        let schema = BundleSchema::new("items")
            .base(FieldDef::numeric("id"))
            .fiber(FieldDef::numeric("val"));
        let overlay = OverlayBundle::new(bundle, schema);

        let mut rec = Record::new();
        rec.insert("id".into(), GigiValue::Integer(99));
        rec.insert("val".into(), GigiValue::Integer(0));
        overlay.insert(&rec);
        overlay.delete("old", None);
        assert_eq!(overlay.overlay_len(), 1);
        assert_eq!(overlay.tombstone_len(), 1);

        overlay.clear_overlay();
        assert_eq!(overlay.overlay_len(), 0);
        assert_eq!(overlay.tombstone_len(), 0);
    }

    /// TDD-11.8: Default (modal) fields handled correctly in mmap.
    #[test]
    fn tdd_11_8_default_fields() {
        // Record fields (non-arithmetic) are: level, msg
        // Empty first field → level takes default "INFO"
        let dhoom = "log{ts@1000+1, level|INFO, msg}:\n, hello\n, world\n:WARN, alert\n";
        let bundle = mmap_from_dhoom(dhoom);

        assert_eq!(bundle.len(), 3);
        let r0 = bundle.get(0).unwrap();
        assert_eq!(r0["level"], "INFO"); // default (empty value)
        assert_eq!(r0["msg"], "hello");

        let r2 = bundle.get(2).unwrap();
        assert_eq!(r2["level"], "WARN"); // deviation override
        assert_eq!(r2["msg"], "alert");
    }

    /// TDD-11.9: Concurrent read safety — multiple readers on same mmap.
    #[test]
    fn tdd_11_9_concurrent_reads() {
        use std::sync::Arc;
        use std::thread;

        let mut lines = String::from("data{id@1, x}:\n");
        for i in 0..500 {
            lines.push_str(&format!("{}\n", i));
        }
        let mut tmp = NamedTempFile::new().unwrap();
        tmp.write_all(lines.as_bytes()).unwrap();
        tmp.flush().unwrap();
        let bundle = Arc::new(MmapBundle::open(tmp.path()).unwrap());

        let handles: Vec<_> = (0..4)
            .map(|t| {
                let b = Arc::clone(&bundle);
                thread::spawn(move || {
                    for i in (t * 100)..((t + 1) * 100).min(500) {
                        let rec = b.get(i).unwrap();
                        assert_eq!(rec["id"], (i + 1) as i64);
                        assert_eq!(rec["x"], i as i64);
                    }
                })
            })
            .collect();

        for h in handles {
            h.join().unwrap();
        }
    }

    /// TDD-11.10: Mmap survives reopen (read-only, no corruption).
    #[test]
    fn tdd_11_10_mmap_survives_reopen() {
        let dhoom = "items{id@1, name}:\nAlice\nBob\nCarol\n";
        let mut tmp = NamedTempFile::new().unwrap();
        tmp.write_all(dhoom.as_bytes()).unwrap();
        tmp.flush().unwrap();
        let path = tmp.path().to_path_buf();

        // First open
        {
            let b1 = MmapBundle::open(&path).unwrap();
            assert_eq!(b1.len(), 3);
            assert_eq!(b1.get(0).unwrap()["name"], "Alice");
        }

        // Second open (simulates restart)
        {
            let b2 = MmapBundle::open(&path).unwrap();
            assert_eq!(b2.len(), 3);
            assert_eq!(b2.get(2).unwrap()["name"], "Carol");
        }
    }
}
