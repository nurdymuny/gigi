//! Complete-case centered moments. No imputation and no dependency on per-field means.
use crate::types::Record;

#[derive(Clone, Debug)]
pub struct CompleteMoments {
    pub count: usize,
    pub excluded: usize,
    pub mean: Vec<f64>,
    scatter: Vec<f64>,
}

#[derive(Clone, Debug)]
pub struct MomentsSnapshot {
    pub moments: CompleteMoments,
    pub build_rows: usize,
    pub incremental_rows: usize,
    pub cache_hit: bool,
}

pub const MAX_MOMENT_CACHE_ENTRIES: usize = 4;
pub const MAX_CACHED_MOMENT_DIM: usize = 512;

#[derive(Debug, Default)]
pub struct MomentsCache {
    entries: std::collections::VecDeque<(Vec<String>, u64, MomentsSnapshot)>,
}

impl MomentsCache {
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn get_or_build<I: IntoIterator<Item = Record>>(
        &mut self,
        fields: &[String],
        revision: u64,
        records: impl FnOnce() -> I,
    ) -> Result<MomentsSnapshot, String> {
        if let Some(index) = self
            .entries
            .iter()
            .position(|(f, at, _)| f == fields && *at == revision)
        {
            let entry = self.entries.remove(index).unwrap();
            let mut snapshot = entry.2.clone();
            snapshot.cache_hit = true;
            self.entries.push_back(entry);
            return Ok(snapshot);
        }
        self.entries
            .retain(|(f, at, _)| f != fields && *at == revision);
        let moments = CompleteMoments::from_records(records(), fields)?;
        let build_rows = moments.count + moments.excluded;
        let snapshot = MomentsSnapshot {
            moments,
            build_rows,
            incremental_rows: 0,
            cache_hit: false,
        };
        if fields.len() <= MAX_CACHED_MOMENT_DIM {
            if self.entries.len() == MAX_MOMENT_CACHE_ENTRIES {
                self.entries.pop_front();
            }
            self.entries
                .push_back((fields.to_vec(), revision, snapshot.clone()));
        }
        Ok(snapshot)
    }

    pub fn append(&mut self, previous: u64, revision: u64, record: &Record) {
        self.entries.retain_mut(|(fields, at, snapshot)| {
            if *at != previous || snapshot.moments.observe(record, fields).is_err() {
                return false;
            }
            snapshot.incremental_rows += 1;
            *at = revision;
            true
        });
    }
}

impl CompleteMoments {
    pub fn new(dim: usize) -> Self {
        Self {
            count: 0,
            excluded: 0,
            mean: vec![0.0; dim],
            scatter: vec![0.0; dim * dim],
        }
    }

    pub fn from_records(
        records: impl IntoIterator<Item = Record>,
        fields: &[String],
    ) -> Result<Self, String> {
        let mut result = Self::new(fields.len());
        for record in records {
            result.observe(&record, fields)?;
        }
        Ok(result)
    }

    pub fn observe(&mut self, record: &Record, fields: &[String]) -> Result<(), String> {
        let mut values = Vec::with_capacity(fields.len());
        let mut complete = true;
        for field in fields {
            match record.get(field).and_then(|v| v.as_f64()) {
                Some(x) if !x.is_finite() => return Err(format!(
                    "field '{field}' contains a non-finite numeric value; replace it with a finite measurement or null before fitting")),
                Some(x) => values.push(x),
                None => complete = false,
            }
        }
        if !complete {
            self.excluded += 1;
            return Ok(());
        }
        self.count += 1;
        if self.count == 1 {
            self.mean.copy_from_slice(&values);
            return Ok(());
        }
        let n = self.count as f64;
        let delta: Vec<f64> = values.iter().zip(&self.mean).map(|(x, m)| x - m).collect();
        let dim = self.mean.len();
        // Symmetric multivariate Welford update, using the old-mean deviation.
        for i in 0..dim {
            self.mean[i] += delta[i] / n;
            for j in 0..=i {
                let value = self.scatter[i * dim + j] + delta[i] * delta[j] * ((n - 1.0) / n);
                self.scatter[i * dim + j] = value;
                self.scatter[j * dim + i] = value;
            }
        }
        if self
            .mean
            .iter()
            .chain(&self.scatter)
            .any(|x| !x.is_finite())
        {
            return Err("numeric moment overflow; rescale the requested fields to finite, smaller magnitudes before fitting".into());
        }
        Ok(())
    }

    pub fn covariance(&self) -> Result<Vec<f64>, String> {
        if self.count < 2 {
            return Err(format!("full-covariance fit requires at least 2 complete numeric records; found {} ({} excluded); supply more complete records or fewer fields", self.count, self.excluded));
        }
        Ok(self
            .scatter
            .iter()
            .map(|x| x / (self.count - 1) as f64)
            .collect())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::Value;

    #[test]
    fn centered_moments_keep_large_offset_variation_and_skip_missing_rows() {
        let fields = vec!["a".into(), "b".into()];
        let mut m = CompleteMoments::new(2);
        for x in [0.0, 2.0, 4.0] {
            m.observe(
                &[
                    ("a".into(), Value::Float(1e12 + x)),
                    ("b".into(), Value::Float(2.0 * x)),
                ]
                .into_iter()
                .collect(),
                &fields,
            )
            .unwrap();
        }
        m.observe(
            &[("a".into(), Value::Float(-1000.0))].into_iter().collect(),
            &fields,
        )
        .unwrap();
        assert_eq!(m.mean, vec![1e12 + 2.0, 4.0]);
        assert_eq!(m.covariance().unwrap(), vec![4.0, 8.0, 8.0, 16.0]);
        assert_eq!((m.count, m.excluded), (3, 1));
    }

    #[test]
    fn nonfinite_measurement_is_an_actionable_refusal() {
        for bad in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let mut m = CompleteMoments::new(1);
            let err = m
                .observe(
                    &[("a".into(), Value::Float(bad))].into_iter().collect(),
                    &["a".into()],
                )
                .unwrap_err();
            assert!(err.contains("field 'a'") && err.contains("replace"));
        }
    }
}
