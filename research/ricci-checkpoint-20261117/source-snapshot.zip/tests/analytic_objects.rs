#![cfg(feature = "kahler")]
use gigi::analytic_objects::prepared::Prepared;
use gigi::geometry::{harmonic_conjugate::RealTerm, holomorphic::Observation};
use nalgebra::Complex;

type C = Complex<f64>;
fn pair(z: C) -> [f64; 2] {
    [z.re, z.im]
}
fn c(z: [f64; 2]) -> C {
    C::new(z[0], z[1])
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() <= 1e-12, "{a} != {b}");
}
fn obs(z: C, w: C) -> Observation {
    Observation {
        z: pair(z),
        value: pair(w),
    }
}
fn term(x: usize, y: usize, coefficient: f64) -> RealTerm {
    RealTerm {
        x_power: x,
        y_power: y,
        coefficient,
    }
}
fn points() -> Vec<[f64; 2]> {
    (0..1024)
        .map(|k| {
            let r = 0.1 + 0.8 * (k % 31) as f64 / 31.;
            let t = std::f64::consts::TAU * k as f64 / 1024.;
            [r * t.cos(), r * t.sin()]
        })
        .collect()
}

#[test]
fn am01_prepared_zero_schwarz_disk_at_1024_new_points() {
    let model = Prepared::family(&[obs(C::new(0., 0.), C::new(0., 0.))], 2.).unwrap();
    for batch in points().chunks(256) {
        let values = model.query(batch).unwrap();
        assert_eq!(values.len(), batch.len());
        for (z, value) in batch.iter().zip(values) {
            assert_eq!(value.center.unwrap(), [0., 0.]);
            close(value.radius.unwrap(), 2. * c(*z).norm());
        }
    }
}

#[test]
fn am02_shifted_complex_disk_matches_independent_circle_formula() {
    let a = C::new(0.125, -0.25);
    let b = C::new(0.25, 0.375);
    for bound in [0.5, 1., 4.] {
        let model = Prepared::family(&[obs(a, b * bound)], bound).unwrap();
        for batch in points().chunks(256) {
            for (z, q) in batch.iter().zip(model.query(batch).unwrap()) {
                let r = ((c(*z) - a) / (C::new(1., 0.) - a.conj() * c(*z))).norm();
                let denominator = 1. - r * r * b.norm_sqr();
                let center = b * ((1. - r * r) / denominator * bound);
                close((c(q.center.unwrap()) - center).norm(), 0.);
                close(
                    q.radius.unwrap(),
                    bound * r * (1. - b.norm_sqr()) / denominator,
                );
            }
        }
    }
}

#[test]
fn am03_unique_identity_and_phase_have_no_radius() {
    for phase in [
        C::new(1., 0.),
        C::new(0., 1.),
        C::new(-1., 0.),
        C::new(0., -1.),
    ] {
        let model = Prepared::family(
            &[
                obs(C::new(0., 0.), C::new(0., 0.)),
                obs(C::new(0.5, 0.), phase * 0.5),
            ],
            1.,
        )
        .unwrap();
        let q = &model.query(&[[0.2, 0.3]]).unwrap()[0];
        close((c(q.value) - phase * C::new(0.2, 0.3)).norm(), 0.);
        close(q.radius.unwrap(), 0.);
    }
}

#[test]
fn am04_jointly_impossible_marginal_choices_refuse() {
    let o = [
        obs(C::new(0., 0.), C::new(0., 0.)),
        obs(C::new(0.5, 0.), C::new(0.5, 0.)),
        obs(C::new(-0.5, 0.), C::new(0.5, 0.)),
    ];
    assert!(Prepared::family(&o, 1.).unwrap_err().contains("infeasible"));
}

#[test]
fn am05_histogram_scales_values_and_both_derivatives() {
    for counts in [vec![1, 2, 5], vec![10, 20, 50], vec![7, 0, 1]] {
        let model = Prepared::histogram(&counts, 1.01).unwrap();
        for z in [[0., 0.], [0.2, 0.3], [-0.4, 0.1]] {
            let q = &model.query(&[z]).unwrap()[0];
            let n = counts.iter().sum::<u64>() as f64;
            let z = c(z);
            let expected =
                (C::new(counts[0] as f64, 0.) + z * counts[1] as f64 + z * z * counts[2] as f64)
                    / n;
            close((c(q.value) - expected).norm(), 0.);
            close(
                (c(q.first_derivative.unwrap())
                    - (C::new(counts[1] as f64, 0.) + z * (2. * counts[2] as f64)) / n)
                    .norm(),
                0.,
            );
            close(
                (c(q.second_derivative.unwrap()) - C::new(2. * counts[2] as f64 / n, 0.)).norm(),
                0.,
            );
        }
    }
}

#[test]
fn am06_polynomial_jet_matches_direct_powers_through_degree_32() {
    for degree in 0usize..=32 {
        let mut choose = 1u64;
        let mut terms = vec![];
        let coefficient = C::new(1., -2.);
        for q in 0..=degree {
            let a = [1., 2., -1., -2.][q % 4] * choose as f64;
            terms.push(term(degree - q, q, a));
            if q < degree {
                choose = choose * (degree - q) as u64 / (q + 1) as u64;
            }
        }
        let model = Prepared::polynomial(&terms, if degree == 0 { -2. } else { 0. }, 3.).unwrap();
        for z in [[0., 0.], [0.125, 0.25], [-0.5, 0.125]] {
            let q = &model.query(&[z]).unwrap()[0];
            let z = c(z);
            close(
                (c(q.value) - coefficient * z.powu(degree as u32)).norm(),
                0.,
            );
            let first = if degree == 0 {
                C::new(0., 0.)
            } else {
                coefficient * degree as f64 * z.powu(degree as u32 - 1)
            };
            let second = if degree < 2 {
                C::new(0., 0.)
            } else {
                coefficient * (degree * (degree - 1)) as f64 * z.powu(degree as u32 - 2)
            };
            close((c(q.first_derivative.unwrap()) - first).norm(), 0.);
            close((c(q.second_derivative.unwrap()) - second).norm(), 0.);
        }
    }
}

#[test]
fn am07_non_harmonic_and_near_harmonic_are_distinct_refusals() {
    assert!(
        Prepared::polynomial(&[term(2, 0, 1.), term(0, 2, 1.)], 0., 3.)
            .unwrap_err()
            .contains("non_harmonic")
    );
    assert!(
        Prepared::polynomial(&[term(2, 0, 1.), term(0, 2, -1. + 1e-14)], 0., 3.)
            .unwrap_err()
            .contains("numerically_unresolved")
    );
}

#[test]
fn am08_exact_tight_histogram_is_unresolved_without_silent_headroom() {
    assert!(Prepared::histogram(&[1, 2, 5], 1.)
        .unwrap_err()
        .contains("numerically_unresolved"));
}
#[test]
fn am08_too_small_histogram_bound_is_exceeded() {
    assert!(Prepared::histogram(&[1, 2, 5], 0.99)
        .unwrap_err()
        .contains("bound_exceeded"));
}

#[test]
fn am11_query_margin_and_batch_atomicity() {
    let model = Prepared::family(&[obs(C::new(0., 0.), C::new(0., 0.))], 1.).unwrap();
    let edge = 1.0_f64 - 1e-8;
    assert!(model.query(&[[edge, 0.]]).is_ok());
    assert!(model
        .query(&[[0.2, 0.], [f64::from_bits(edge.to_bits() + 1), 0.]])
        .is_err());
    assert!(model.query(&[[f64::NAN, 0.]]).is_err());
    assert!(model.query(&[[0., 0.]; 257]).is_err());
}

#[test]
fn am12_observation_changes_a_predeclared_decision() {
    let initial = [obs(C::new(0., 0.), C::new(0., 0.))];
    let before = Prepared::family(&initial, 1.)
        .unwrap()
        .query(&[[0.25, 0.]])
        .unwrap();
    let b = &before[0];
    assert!(b.center.unwrap()[0] - b.radius.unwrap() < 0.2);
    assert!(b.center.unwrap()[0] + b.radius.unwrap() > 0.2);
    let full = [initial[0], obs(C::new(0.5, 0.), C::new(0.5, 0.))];
    let after = Prepared::family(&full, 1.)
        .unwrap()
        .query(&[[0.25, 0.]])
        .unwrap();
    let a = &after[0];
    assert!(a.center.unwrap()[0] - a.radius.unwrap() > 0.2);
    assert_eq!(a.radius, Some(0.));
}

#[test]
fn am00_histogram_refuses_empty_and_unrepresentable_expansion() {
    assert!(Prepared::histogram(&[], 1.01).is_err());
    assert!(Prepared::histogram(&[0, 0], 1.01).is_err());
    assert!(Prepared::histogram(&[1; 34], 1.01).is_err());
    assert!(Prepared::histogram(&[u64::MAX], 1.01).is_err());
    let mut counts = vec![0; 33];
    counts[32] = 1 << 40;
    assert!(Prepared::histogram(&counts, 1.01).is_err());
}

#[test]
fn am05_public_bound_evidence_is_normalized_too() {
    let model = Prepared::histogram(&[10, 20, 50], 1.01).unwrap();
    let evidence = model.evidence();
    assert!(evidence["bound_evidence"]["upper"].as_f64().unwrap() <= 1.01);
    assert!(evidence["bound_evidence"]["upper"].as_f64().unwrap() >= 1.);
}

#[test]
fn am09_conjugation_rotation_scaling_and_permutation() {
    let observations = [
        obs(C::new(0., 0.), C::new(0.125, 0.)),
        obs(C::new(0.5, 0.), C::new(0.25, 0.)),
    ];
    let original = Prepared::family(&observations, 1.).unwrap();
    let phase = C::new(0., 1.);
    let transformed: Vec<_> = observations
        .iter()
        .rev()
        .map(|o| obs(c(o.z).conj(), phase * c(o.value).conj() * 2.))
        .collect();
    let other = Prepared::family(&transformed, 2.).unwrap();
    for z in [[0.25, 0.125], [-0.2, 0.4]] {
        let a = original.query(&[z]).unwrap();
        let b = other.query(&[pair(c(z).conj())]).unwrap();
        close(
            (c(b[0].center.unwrap()) - phase * c(a[0].center.unwrap()).conj() * 2.).norm(),
            0.,
        );
        close(b[0].radius.unwrap(), a[0].radius.unwrap() * 2.);
        close(
            (c(b[0].value) - phase * c(a[0].value).conj() * 2.).norm(),
            0.,
        );
    }
}

#[test]
fn am10_added_observation_nests_the_entire_disk_not_only_radius() {
    let old = Prepared::family(&[obs(C::new(0., 0.), C::new(0.125, 0.))], 1.).unwrap();
    let new = Prepared::family(
        &[
            obs(C::new(0., 0.), C::new(0.125, 0.)),
            obs(C::new(0.5, 0.), C::new(0.25, 0.)),
        ],
        1.,
    )
    .unwrap();
    for batch in points().chunks(256) {
        let older = old.query(batch).unwrap();
        let newer = new.query(batch).unwrap();
        for (a, b) in older.iter().zip(newer) {
            let distance = (c(a.center.unwrap()) - c(b.center.unwrap())).norm();
            assert!(distance + b.radius.unwrap() <= a.radius.unwrap() + 1e-12);
        }
    }
}

#[test]
fn am11_conditioning_is_not_relaxed_by_preparation() {
    assert!(
        Prepared::family(&[obs(C::new(0., 0.), C::new(1. - 1e-12, 0.))], 1.)
            .unwrap_err()
            .contains("numerically_unresolved")
    );
    assert!(Prepared::family(
        &[
            obs(C::new(0., 0.), C::new(0., 0.)),
            obs(C::new(1e-9, 0.), C::new(0., 0.))
        ],
        1.
    )
    .unwrap_err()
    .contains("numerically_unresolved"));
}

#[test]
fn am13_raw_recipe_declares_loss_and_preserves_only_the_histogram() {
    let a = Prepared::histogram_from_values(&[0.1, 0.2, 1.1, 1.9], &[0., 1., 2.], 1.01).unwrap();
    let b = Prepared::histogram_from_values(&[1.8, 0.8, 1.2, 0.4], &[0., 1., 2.], 1.01).unwrap();
    let query = [[0.125, 0.25]];
    assert_eq!(
        serde_json::to_value(a.query(&query).unwrap()).unwrap(),
        serde_json::to_value(b.query(&query).unwrap()).unwrap()
    );
    assert!(a
        .information()
        .discarded
        .iter()
        .any(|x| x == "joint_cross_field_dependence"));
    assert!(!a
        .information()
        .operations
        .iter()
        .any(|x| x == "recover_raw_records"));
    assert_eq!(a.evidence()["integer_counts"], serde_json::json!([2, 2]));
}

#[test]
fn am00_raw_recipe_never_silently_skips_or_rebins() {
    let valid = Prepared::histogram_from_values(&[0., 1., 2.], &[0., 1., 2.], 1.01).unwrap();
    assert_eq!(
        valid.evidence()["integer_counts"],
        serde_json::json!([1, 2])
    );
    assert!(Prepared::histogram_from_values(&[f64::NAN], &[0., 1.], 1.01).is_err());
    assert!(Prepared::histogram_from_values(&[-0.1, 0.5], &[0., 1.], 1.01).is_err());
    assert!(Prepared::histogram_from_values(&[0.5, 1.1], &[0., 1.], 1.01).is_err());
    assert!(Prepared::histogram_from_values(&[0.5], &[0., 0., 1.], 1.01).is_err());
    assert!(Prepared::histogram_from_values(&[0.5], &[0., f64::INFINITY], 1.01).is_err());
}

#[test]
fn am14_counters_detect_preparation_then_prove_no_rebuild_for_new_points() {
    use gigi::geometry::analytic_work as work;
    work::reset();
    let model = Prepared::family(&[obs(C::new(0., 0.), C::new(0.25, 0.))], 1.).unwrap();
    assert_eq!(work::read().preparations, 1);
    assert_eq!(work::read().eigensolves, 1);
    work::reset();
    for batch in points().chunks(256) {
        model.query(batch).unwrap();
    }
    let measured = work::read();
    assert_eq!(measured.preparations, 0);
    assert_eq!(measured.eigensolves, 0);
    assert_eq!(measured.source_rows, 0);
    assert_eq!(measured.recurrence_steps, 2048);
    work::reset();
    Prepared::histogram_from_values(&[0.1, 0.2, 0.3], &[0., 1.], 1.01).unwrap();
    assert_eq!(work::read().source_rows, 3);
    assert_eq!(work::read().preparations, 1);
}
#[test]
fn am14_restored_objects_preserve_math_without_preparation_or_eigensolves() {
    use gigi::geometry::analytic_work;
    use sha2::{Digest, Sha256};
    let models = [
        Prepared::histogram(&[1, 2, 5], 1.01).unwrap(),
        Prepared::family(
            &[Observation {
                z: [0.125, -0.25],
                value: [0.25, 0.375],
            }],
            1.,
        )
        .unwrap(),
        Prepared::family(
            &[
                Observation {
                    z: [0., 0.],
                    value: [0., 0.],
                },
                Observation {
                    z: [0.5, 0.],
                    value: [0.5, 0.],
                },
            ],
            1.,
        )
        .unwrap(),
    ];
    for model in models {
        let bytes = model.encode().unwrap();
        let digest: [u8; 32] = Sha256::digest(&bytes).into();
        analytic_work::reset();
        let restored = Prepared::restore(&bytes, &digest).unwrap();
        assert_eq!(analytic_work::read().preparations, 0);
        assert_eq!(analytic_work::read().eigensolves, 0);
        assert_eq!(analytic_work::read().source_rows, 0);
        assert_eq!(bytes, restored.encode().unwrap());
        for z in [[0., 0.], [0.25, 0.125], [-0.8, 0.2]] {
            assert_eq!(
                serde_json::to_value(model.query(&[z]).unwrap()).unwrap(),
                serde_json::to_value(restored.query(&[z]).unwrap()).unwrap()
            );
        }
        assert_eq!(model.evidence(), restored.evidence());
    }
}

#[test]
fn ao07_corrupted_truncated_and_wrong_identity_bytes_are_never_loaded() {
    use sha2::{Digest, Sha256};
    let model = Prepared::histogram(&[1, 2, 5], 1.01).unwrap();
    let bytes = model.encode().unwrap();
    let digest: [u8; 32] = Sha256::digest(&bytes).into();
    assert!(Prepared::restore(&bytes, &digest).is_ok());
    for i in [0, 8, bytes.len() / 2, bytes.len() - 1] {
        let mut bad = bytes.clone();
        bad[i] ^= 1;
        assert!(Prepared::restore(&bad, &digest)
            .unwrap_err()
            .contains("corrupt_object"));
    }
    for n in [0, 1, 8, bytes.len() - 1] {
        assert!(Prepared::restore(&bytes[..n], &digest).is_err());
    }
    assert!(Prepared::restore(&bytes, &[0; 32])
        .unwrap_err()
        .contains("corrupt_object"));
}

#[path = "../src/analytic_objects/encoding.rs"]
mod storage_encoding_fixture;

#[test]
fn ao07_checksums_do_not_replace_structural_and_mathematical_validation() {
    use sha2::{Digest, Sha256};
    let polynomial = Prepared::histogram(&[1, 2, 5], 1.01).unwrap();
    let family = Prepared::family(&[Observation { z:[0.,0.], value:[0.25,0.] }], 1.).unwrap();
    let poly_value = storage_encoding_fixture::decode(&polynomial.encode().unwrap()).unwrap();
    let family_value = storage_encoding_fixture::decode(&family.encode().unwrap()).unwrap();
    let changes: Vec<(&serde_json::Value, &str, serde_json::Value)> = vec![
        (&poly_value, "/prepared/model/Polynomial/coefficients/0/0", 1000.0.into()),
        (&poly_value, "/prepared/model/Polynomial/conjugate_at_center", 2.0.into()),
        (&poly_value, "/prepared/scale", 1.0.into()),
        (&poly_value, "/prepared/evidence/bound_evidence/upper", 0.0.into()),
        (&poly_value, "/prepared/evidence/integer_counts/0", 2.into()),
        (&poly_value, "/prepared/evidence/declared_bound", 2.0.into()),
        (&poly_value, "/prepared/information/model_class", "lossless_raw_dataset".into()),
        (&family_value, "/prepared/model/Family/representation/steps/0/parameter/0", 0.5.into()),
        (&family_value, "/prepared/model/Family/representation/free_terminal", false.into()),
        (&family_value, "/prepared/model/Family/representation/steps", serde_json::json!([])),
        (&family_value, "/prepared/evidence/status", "feasible_unique".into()),
    ];
    for (original,path,value) in changes {
        let mut altered = original.clone(); *altered.pointer_mut(path).unwrap() = value;
        let bytes = storage_encoding_fixture::encode(&altered).unwrap();
        let digest: [u8;32] = Sha256::digest(&bytes).into();
        assert!(Prepared::restore(&bytes,&digest).unwrap_err().contains("corrupt_object"), "{path}");
    }
    let mut unknown = poly_value.clone(); unknown["prepared"]["accepted"] = true.into();
    let bytes = storage_encoding_fixture::encode(&unknown).unwrap();
    assert!(Prepared::restore(&bytes, &Sha256::digest(&bytes).into()).is_err());
    unknown = poly_value; unknown["evaluator"] = "future-policy".into();
    let bytes = storage_encoding_fixture::encode(&unknown).unwrap();
    assert!(Prepared::restore(&bytes, &Sha256::digest(&bytes).into()).unwrap_err().contains("unsupported_version"));
}

#[test]
fn ao07_binary_codec_rejects_noncanonical_and_unbounded_documents() {
    let samples = [0.1f64, f64::from_bits(0.1f64.to_bits()+1), f64::MIN_POSITIVE, f64::MAX];
    for number in samples {
        let bytes = storage_encoding_fixture::encode(&serde_json::json!({"x":number})).unwrap();
        assert_eq!(storage_encoding_fixture::decode(&bytes).unwrap()["x"].as_f64().unwrap().to_bits(),number.to_bits());
        let mut extra = bytes; extra.push(0);
        assert!(storage_encoding_fixture::decode(&extra).is_err());
    }
    let zero = storage_encoding_fixture::encode(&serde_json::json!(-0.0)).unwrap();
    assert_eq!(zero, storage_encoding_fixture::encode(&serde_json::json!(0.0)).unwrap());
    let mut bad = storage_encoding_fixture::encode(&serde_json::json!(1.0)).unwrap();
    bad[9..17].copy_from_slice(&f64::INFINITY.to_le_bytes());
    assert!(storage_encoding_fixture::decode(&bad).is_err());
    let mut nested = serde_json::Value::Null;
    for _ in 0..34 { nested = serde_json::json!([nested]); }
    assert!(storage_encoding_fixture::encode(&nested).is_err());
}
