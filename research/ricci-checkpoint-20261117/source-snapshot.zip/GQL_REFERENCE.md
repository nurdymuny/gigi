# GQL — Geometric Query Language
## Version 2.2 — Complete Reference

**Authors:** Bee Rosa Davis · Davis Geometric  
**The query language for fiber bundle databases.**

SQL thinks in tables and rows. GQL thinks in bundles, sections, and fibers. Every keyword maps to a geometric operation. The language IS the math.

---

## Design Principles

1. **Geometric primitives, not relational.** SECTION, BUNDLE, COVER, PULLBACK, INTEGRATE — not SELECT, FROM, JOIN, GROUP BY.
2. **Confidence is not optional.** Every query returns confidence. Always.
3. **Analytics are verbs, not plugins.** CURVATURE, SPECTRAL, HOLONOMY, CONSISTENCY are first-class.
4. **The wire format is part of the language.** EMIT controls DHOOM serialization.
5. **Silence means agreement.** Omitted clauses inherit bundle defaults.
6. **Geometry determines complexity.** SECTION AT = O(1). COVER ON = O(|r|). PULLBACK = O(|left|). INTEGRATE = O(|group|).
7. **SQL compatibility via TRANSLATE.** Any SQL → GQL. Not all GQL → SQL.

---

## Implementation Status

| Status | Meaning |
|---|---|
| ✅ Implemented | Working in current server (`gigi-stream`) |
| ⚠️ Parsed | Accepted by parser, silently does nothing |
| ❌ 501 | Returns HTTP 501 Not Implemented |

> **This table is enforced.** `tests/gql_reference_truth.rs` runs one
> statement per ✅ row against a real engine and fails CI when a row and
> the engine disagree — the table has to produce a receipt like everything
> else. Unknown fields, unsupported clauses, and trailing input now error
> loudly instead of returning silently wrong answers (audit 2026-07-02).

| Feature | Status | Notes |
|---|---|---|
| BUNDLE / GAUGE / COLLAPSE / LENS | ✅ | Full schema operations |
| SECTION / SECTIONS / UPSERT | ✅ | Insert and batch insert |
| REDEFINE / BULK REDEFINE | ✅ | Update operations |
| RETRACT / BULK RETRACT | ✅ | Delete operations |
| SECTION AT / EXISTS SECTION | ✅ | O(1) point queries |
| COVER (all variants) | ✅ | Range, filtered, ranked, paginated |
| INTEGRATE | ✅ | Aggregation (COUNT/SUM/AVG/MIN/MAX, incl. COUNT(*)) |
| INTEGRATE … WITH JACKKNIFE ALONG f | ✅ | Autocorrelation-honest error bars on avg() — mean ± err, τ_int, n_eff, blocked-jackknife cross-check |
| SHOW FIELDS ON b | ✅ | One row per field: name, kind (base/fiber), type, indexed, range — DESCRIBE gives counts, this gives names |
| HAVING | ❌ | Not implemented — rejected loudly (was listed ✅; caught by tests/gql_reference_truth.rs) |
| FIBER / TRANSPORT (window) | ❌ | Not implemented — rejected loudly (was listed ✅) |
| PULLBACK | ✅ | Joins |
| PRODUCT / UNION / INTERSECT / SUBTRACT | ❌ | Not implemented — rejected loudly (were listed ✅) |
| ATLAS (transactions) | ❌ | BEGIN / COMMIT / ROLLBACK parse but open no transaction — 501 on `/v1/gql`, NOTICE in the embedded executor. ATLAS SAVEPOINT / ROLLBACK TO / ISOLATION are parse errors. Staged writes live at `/v1/transactions/*` (`--features transactions`) |
| SHOW BUNDLES / DESCRIBE | ✅ | |
| CURVATURE / RICCI / SPECTRAL | ✅ | |
| DIVERGENCE FROM bundle_a TO bundle_b (or VS) | ✅ | Gaussian KL + Jensen-Shannon between two bundles |
| SPECTRAL … ON FIBER (…) MODES k | ✅ | Fiber-space Laplacian eigensolver — semantic cluster count |
| TRANSPORT … FROM (…) TO (…) ON FIBER (…) | ✅ | Parallel transport rotation matrix between two records |
| HOLONOMY … NEAR (…) WITHIN r ON FIBER (…) AROUND field | ✅ | Local holonomy in proximity neighbourhood |
| GAUGE … VS … ON FIBER (…) AROUND field | ✅ | Gauge invariance test across two bundles |
| HOLONOMY … ON FIBER (…) AROUND field | ✅ | Global holonomy — full-bundle loop consistency |
| CONSISTENCY (+ REPAIR) | ✅ | |
| BETTI / ENTROPY / FREEENERGY | ✅ | |
| CAPACITY / HORIZON / DEPTH | ✅ | Cognitive Geometry Correspondence — Davis 2026-05-29 |
| GEODESIC / METRIC TENSOR | ✅ | |
| HEALTH | ✅ | |
| CREATE BUNDLE with ENCRYPTED `<MODE>` | ✅ | v0.2 — AFFINE / OPAQUE / INDEXED / PROBABILISTIC / ISOMETRIC |
| WITH ENCRYPTION SEED `'<hex>'` / `FROM ENV $NAME` | ✅ | v0.2 — bundle-level master seed source |
| GAUGE `<bundle>` ROTATE_KEY FORWARD_SECRET | ✅ | v0.2 — atomic (s, g) → (s', g') rotation, in-process atomic |
| PROJECT INVARIANT (…) FROM `<b>` [WHERE …] | ✅ | v0.2 — 0-decrypt analytics ring (curvature, confidence, capacity(τ), spectral_gap, β₀, β₁, holonomy_avg) |
| SUBSCRIBE / UNSUBSCRIBE | ✅ | WebSocket subscriptions |
| EXPLAIN / TRANSLATE SQL | ✅ | |
| COMPLETE / PROPAGATE / SUGGEST_ADJACENCY | ⚠️ | Parsed; sheaf module built but not wired |
| CREATE/DROP TRIGGER | ⚠️ | Parsed; TriggerManager built but not wired |
| INVALIDATE CACHE / COMPACT / ANALYZE / VACUUM / REBUILD INDEX | ⚠️ | Parsed; no-op — returns a NOTICE saying so (never a bare ok) |
| SHOW INDEXES / SHOW TRIGGERS / etc. | ⚠️ | Parsed; no-op |
| WEAVE / UNWEAVE ROLE | ❌ | 501 |
| GRANT / REVOKE / POLICY | ❌ | 501 |
| PREPARE / EXECUTE / DEALLOCATE | ❌ | 501 |
| BACKUP / RESTORE / VERIFY BACKUP | ❌ | 501 |
| COMMENT ON | ❌ | 501 |
| SET (session variables) | ❌ | 501 |
| SELECT (SQL compat) | ⚠️ | Falls through; use COVER/PULLBACK instead |

---

## Complete SQL → GQL Mapping

| SQL | GQL | Geometric Meaning |
|---|---|---|
| **Schema** | | |
| CREATE TABLE t (...) | BUNDLE t BASE (...) FIBER (...) | Define fiber bundle (E, B, F, π) |
| ALTER TABLE t ADD/DROP/RENAME | GAUGE t TRANSFORM (...) | Gauge transformation on fiber |
| DROP TABLE t | COLLAPSE t | Collapse the bundle |
| CREATE INDEX ON t(f) | (automatic — INDEX modifier) | Topology on base space |
| CREATE VIEW v AS ... | LENS v AS (...) | Virtual bundle via morphism |
| CREATE MATERIALIZED VIEW | LENS v AS (...) MATERIALIZE | Precomputed bundle snapshot |
| **Write** | | |
| INSERT INTO t VALUES (...) | SECTION t (...) | Define section σ at base point |
| batch INSERT | SECTIONS t (...) | Batch section definition |
| UPDATE t SET f=v WHERE k=v | REDEFINE t AT k=v SET (f=v) | Redefine section at a point |
| DELETE FROM t WHERE k=v | RETRACT t AT k=v | Retract section from base point |
| UPSERT / ON CONFLICT | SECTION t (...) UPSERT | Define-or-redefine |
| **Read (point)** | | |
| SELECT * FROM t WHERE pk=v | SECTION t AT pk=v | Section evaluation σ(p) — O(1) |
| SELECT f1,f2 FROM t WHERE pk=v | SECTION t AT pk=v PROJECT (f1,f2) | Projected section |
| SELECT EXISTS(...) | EXISTS SECTION t AT pk=v | Section existence check |
| **Read (range)** | | |
| SELECT * FROM t WHERE f=v | COVER t ON f=v | Sheaf evaluation F(U) — O(|r|) |
| SELECT * FROM t WHERE f IN (...) | COVER t ON f IN (...) | Union of open sets |
| SELECT * FROM t WHERE f > v | COVER t WHERE f > v | Fiber predicate scan |
| SELECT * FROM t WHERE a AND b | COVER t ON a WHERE b | Topology + fiber filter |
| SELECT DISTINCT f FROM t | COVER t DISTINCT f | Field index key enumeration |
| SELECT * ... ORDER BY f | COVER t ... RANK BY f | Ordered cover |
| SELECT * ... LIMIT n | COVER t ... FIRST n | Truncated cover |
| SELECT * ... OFFSET m LIMIT n | COVER t ... SKIP m FIRST n | Paginated cover |
| SELECT * ... WHERE f LIKE '%x' | COVER t WHERE f MATCHES '...' | Pattern on fiber values |
| SELECT * ... WHERE f IS NULL | COVER t WHERE f VOID | Undefined fiber component |
| SELECT * ... WHERE f IS NOT NULL | COVER t WHERE f DEFINED | Defined fiber component |
| **Aggregation** | | |
| SELECT f, AGG(g) GROUP BY f | INTEGRATE t OVER f MEASURE agg(g) | Fiber integral ∫ h dσ |
| SELECT AGG(f) FROM t | INTEGRATE t MEASURE agg(f) | Global fiber integral |
| ... GROUP BY f HAVING agg(g)>v | ... HAVING agg(g) > v | Post-integration filter |
| **Window functions** | | |
| ROW_NUMBER() OVER (PART BY f ORDER BY g) | FIBER RANK t OVER f RANK BY g | Fiber-wise ranking |
| SUM(f) OVER (PART BY g ROWS BETWEEN m AND n) | FIBER SUM t OF f OVER g WINDOW h ROWS (m,n) | Sliding fiber integral |
| LAG(f,n) OVER (ORDER BY g) | TRANSPORT t OF f ALONG g SHIFT -n | Parallel transport backward |
| LEAD(f,n) OVER (ORDER BY g) | TRANSPORT t OF f ALONG g SHIFT +n | Parallel transport forward |
| **Joins** | | |
| t1 JOIN t2 ON fk=pk | PULLBACK t1 ALONG fk ONTO t2 | Pullback bundle f*E₂ — O(|left|) |
| t1 LEFT JOIN t2 ON fk=pk | PULLBACK t1 ALONG fk ONTO t2 PRESERVE LEFT | Left-preserving pullback |
| t1 CROSS JOIN t2 | PRODUCT t1 WITH t2 | Cartesian product bundle |
| t1 UNION t2 | UNION (q1) WITH (q2) | Bundle union |
| t1 INTERSECT t2 | INTERSECT (q1) WITH (q2) | Bundle intersection |
| t1 EXCEPT t2 | SUBTRACT (q1) MINUS (q2) | Bundle difference |
| **Subqueries / CTEs** | | |
| WHERE f IN (SELECT ...) | ON f IN (COVER ... PROJECT f) | Nested sheaf evaluation |
| WITH cte AS (...) SELECT ... | WITH name AS (...) ... | Named intermediate bundle |
| **Transactions** | | |
| BEGIN / COMMIT / ROLLBACK | ATLAS BEGIN / COMMIT / ROLLBACK | ❌ not implemented — parses, opens nothing (see §VIII) |
| SAVEPOINT name | ATLAS SAVEPOINT name | ❌ not implemented — parse error |
| **Admin** | | |
| EXPLAIN SELECT ... | EXPLAIN (any statement) | Geometric query plan |
| SHOW TABLES | SHOW BUNDLES | Bundle catalog |
| DESCRIBE t | DESCRIBE t | Schema + geometric properties |
| **GQL-Only (impossible in SQL)** | | |
| — | CURVATURE t ON f BY g | Local data variability K |
| — | CONFIDENCE t | Query trust 1/(1+K) |
| — | SPECTRAL t | Index connectivity λ₁ |
| — | HOLONOMY t ON FIBER (f1,f2) AROUND field | Global loop consistency — full-bundle |
| — | HOLONOMY t NEAR (f1=v1,...) WITHIN r ON FIBER (f1,f2) AROUND field | Local holonomy in proximity neighbourhood |
| — | SPECTRAL t ON FIBER (f1,f2) MODES k | k eigenvalues of fiber Laplacian |
| — | TRANSPORT t FROM (k=v) TO (k=v) ON FIBER (f1,f2) | Rotation matrix for parallel transport |
| — | GAUGE t1 VS t2 ON FIBER (f1,f2) AROUND field | Gauge invariance test across bundles |
| — | CONSISTENCY t | Čech H¹ diagnostic |
| — | CONSISTENCY t REPAIR | Cocycle resolution |
| — | PARTITION t AT p TOLERANCE τ | Boltzmann approximate query |
| — | CALIBRATE t TOLERANCE τ | Set default temperature |
| — | HEALTH t | Full geometric diagnostic |
| — | PREDICT t ON f BY g | Curvature-ranked forecasting |
| — | TRANSPORT t OF f FROM p TO q | Parallel transport between points |
| — | FLOW t COARSEN BY f LEVELS n | RG flow / C-theorem verification |
| — | GEODESIC t FROM p TO q | Shortest path on bundle |
| — | RESTRICT t TO (cover) AS name | Sheaf restriction to sub-bundle |
| — | GLUE (c1) WITH (c2) CHECK OVERLAP | Explicit sheaf gluing |
| — | SNAPSHOT t AS name | Point-in-time capture |
| — | DIFF t1 AGAINST t2 | Bundle comparison with ΔK |
| — | EMIT DHOOM / JSON / CSV | Wire format control |
| — | TRANSLATE SQL "..." | SQL-to-GQL compiler |
| — | COVER t ... CONFIDENCE >= c | Filter by geometric trust |
| — | HAVING CURVATURE(f) > v | Filter groups by curvature |
| **Spectral Geometry** | | |
| — | SPECTRAL t FULL | Full eigenvalue spectrum of index graph |
| — | BOTTLENECK t | Cheeger inequality — find weakest connectivity |
| — | CLUSTER t INTO n | Spectral clustering via Fiedler vector |
| — | MIXING t | Mixing time from spectral gap: O(1/λ₁) |
| — | CONDUCTANCE t ON f | Graph conductance of field index |
| — | LAPLACIAN t | Hodge Laplacian eigenvalues on data forms |
| **Information Geometry** | | |
| — | ENTROPY t | Shannon entropy of the bundle |
| — | ENTROPY t ON f BY g | Per-group entropy (RG flow integrand) |
| — | DIVERGENCE FROM bundle_a TO bundle_b | ✅ KL + JS divergence between two bundles |
| — | FISHER t ON f1, f2 | Fisher information metric between fields |
| — | MUTUAL t ON f1 WITH f2 | Mutual information between fields |
| — | CAPACITY t | C = τ/K at every base point |
| **Statistical Mechanics** | | |
| — | FREEENERGY t TOLERANCE τ | Helmholtz free energy F = −τ log Z |
| — | PHASE t ON f | Detect phase transitions (discontinuities in K) |
| — | CRITICAL t ON f | Find critical points (∂K/∂f = 0) |
| — | TEMPERATURE t | Effective temperature per neighborhood |
| **Curvature Variants** | | |
| — | RICCI t BETWEEN n AND m | ✅ Ricci curvature between record index n and m |
| — | SECTIONAL t ON f1, f2 | Sectional curvature on 2-plane |
| — | SCALAR t | Scalar curvature (trace of Ricci) |
| — | DEVIATION t FROM p ALONG f | Geodesic deviation — how nearby sections diverge |
| — | TREND t ON f BY g | Curvature-based trend detection (dK/dt) |
| **Topology** | | |
| — | BETTI t | Betti numbers β₀, β₁, β₂ of the data bundle |
| — | EULER t | Euler characteristic χ = β₀ − β₁ + β₂ |
| — | COCYCLE t ON (f1, f2) | Extract specific Čech cocycles |
| — | COBOUNDARY t ON cocycle | Check if cocycle is exact (removable) |
| — | TRIVIALIZE t | Check if bundle is globally trivial (E ≅ B × F) |
| **Gauge Theory** | | |
| — | WILSON t AROUND path | Wilson loop — holonomy along explicit path |
| — | GAUGE VERIFY t | Verify K-invariance after migration |
| — | CHARACTERISTIC t | Characteristic classes (Chern/Euler) |
| **Similarity and Discovery** | | |
| — | SIMILAR t TO section_id WITHIN d | Find geometrically similar sections |
| — | CORRELATE t ON f1 WITH f2 | Geometric correlation via connection |
| — | SEGMENT t INTO n BY f | Geometric segmentation (curvature-based clustering) |
| — | OUTLIER t ON f SIGMA n | Flag outliers at nσ from local mean |
| — | PROFILE t | Full geometric data profile (all fields) |
| **Double Cover** | | |
| — | DOUBLECOVER t ON query | Compute S + d² = 1 for any query |
| — | RECALL t ON query | Compute recall S for a query |
| — | COMPLETENESS t ON query | Verify S + d² = 1 holds |
| **Subscriptions** | | |
| — | SUBSCRIBE ANOMALIES t ON f | Real-time curvature spike events |
| — | SUBSCRIBE CURVATURE t DRIFT > ε | Curvature drift events |
| — | SUBSCRIBE CONSISTENCY t | H¹ violation events |
| — | SUBSCRIBE SPECTRAL t | Topology change events |
| — | SUBSCRIBE PHASE t ON f | Phase transition events |
| — | SUBSCRIBE DIVERGENCE t THRESHOLD ε | Distribution drift events |

**Score: 45 SQL operations matched. 50+ GQL-only operations. 0 SQL operations missing.**

---

## I. Schema Operations

### BUNDLE — Define a fiber bundle ✅

```sql
BUNDLE sensors
  BASE (id NUMERIC)
  FIBER (
    city        CATEGORICAL INDEX,
    region      CATEGORICAL INDEX,
    date        NUMERIC,
    temp        NUMERIC RANGE 80,
    temp_max    NUMERIC RANGE 80,
    temp_min    NUMERIC RANGE 80,
    humidity    NUMERIC RANGE 100,
    pressure    NUMERIC RANGE 20,
    wind        NUMERIC RANGE 30,
    solar       NUMERIC RANGE 12,
    status      CATEGORICAL DEFAULT 'normal'
  );
```

**Field Types:** NUMERIC, CATEGORICAL, TEXT, BOOLEAN, TIMESTAMP

**Field Modifiers:**

| Modifier | Effect | DHOOM Wire |
|---|---|---|
| INDEX | Field index topology (enables COVER ON) | — |
| RANGE n | Domain width for curvature: K = variance/range² | — |
| DEFAULT v | Zero section σ₀ | `\|v` (elided when matching) |
| AUTO | Sequential base, array storage | `@start+1` |
| ARITHMETIC | Arithmetic sequence | `@start+step` |
| UNIQUE | Enforce injectivity across sections | — |
| REQUIRED | Must be defined in every section | — |
| NULLABLE | May be VOID (default) | — |
| ENCRYPTED [`<MODE>`] | Gauge-invariant encryption (GaugeKey). See [Encryption](#encryption) below. | — |

**INVARIANT constraints:**

Bundles may declare runtime invariants that GIGI enforces on every SECTION insert and UPSERT.

```sql
BUNDLE corpus
  BASE (token_id NUMERIC)
  FIBER (
    tense_label CATEGORICAL INDEX,
    f11 NUMERIC, f12 NUMERIC
  )
  INVARIANT f11 * f11 + f12 * f12 = 1.0 +/- 0.05;
-- Any section where f11²+f12² ∉ [0.95, 1.05] is rejected.
-- Multiple INVARIANT clauses are allowed.
```

The `+/-` tolerance specifies the half-width of the allowed band. Sections that violate
an invariant are rejected with a structured error explaining which constraint failed.

**Storage auto-detection:** Single arithmetic key → SEQUENTIAL (array, K=0). Composite → HASHED. Mostly arithmetic → HYBRID. The curvature of the base space determines the storage engine.

**Bundle Options:**

```sql
BUNDLE events
  BASE (id NUMERIC AUTO)
  FIBER (...)
  OPTIONS (
    STORAGE AUTO,                -- AUTO | SEQUENTIAL | HASHED
    TOLERANCE 0.1,               -- default τ for PARTITION queries
    ANOMALY_THRESHOLD AUTO,      -- AUTO (adaptive) | FIXED n
    WAL ENABLED,                 -- write-ahead log
    COMPACTION INTERVAL 3600     -- seconds between compactions
  );
```

**Bundle with encryption:**

```sql
CREATE BUNDLE secrets
  BASE (id NUMERIC AUTO)
  FIBER (
    label CATEGORICAL,
    payload TEXT ENCRYPTED                  -- defaults to OPAQUE for TEXT
  );
-- payload is stored and queried via gauge-invariant GaugeKey encryption.
-- The 32-byte master seed is generated server-side (CSPRNG) by default;
-- use `WITH ENCRYPTION SEED ...` to supply your own (see Encryption below).
-- K, λ₁, β₀, β₁, capacity(τ) are preserved under encryption — the topology
-- of the data is maintained, so analytics work directly on ciphertext.
```

### Encryption

GIGI Encrypt v0.2 ships five gauge-invariant encryption modes, all
declarable per-field on `CREATE BUNDLE`. The bare `ENCRYPTED` keyword
picks a sensible default for the field type; explicit modes are below.

**Modes:**

| Mode | Field types | Equality query | Randomized? | Use when |
|---|---|---|---|---|
| `AFFINE` | numeric (default for INT/FLOAT/TIMESTAMP) | O(1) exact | No (deterministic) | gauge-invariant numeric — preserves curvature, distances, holonomy |
| `OPAQUE` | TEXT, BINARY (default for TEXT/BINARY) | ❌ no equality | Yes (AEAD per-record nonce) | sensitive payloads where indexed lookup isn't needed (chat content, free-form notes) |
| `INDEXED` | TEXT, CATEGORICAL | O(1) exact via deterministic PRF | No | high-cardinality text where you need equality queries (UUIDs, row keys, hashed IDs). **Frequency-leaks** on low-cardinality columns — don't use on `gender`/`zip`/`diagnosis`. |
| `PROBABILISTIC SIGMA n` | numeric | O(1) σ-bucket via Davis Identity | Yes (Gaussian noise width σ) | randomized numeric encryption that's still queryable. Same plaintext → different ciphertext, but equality survives because S + d² = 1. |
| `ISOMETRIC GROUP <name>` | numeric (≥2 fields per group) | distance-preserving | No (deterministic) | grouped vectors (wind {u,v,w}, embeddings) where pairwise Euclidean distance must be exact post-encryption — encryption is a shared O(k) rotation + offset |

**Examples:**

```sql
-- Per-field AFFINE on a single numeric (default for INT/FLOAT)
CREATE BUNDLE temps (
  id INT BASE,
  reading NUMERIC FIBER ENCRYPTED AFFINE
);

-- OPAQUE (AEAD) on the chat payload — IND-CPA, tamper-detected
CREATE BUNDLE chat (
  id INT BASE,
  body TEXT FIBER ENCRYPTED OPAQUE,
  created_at TIMESTAMP FIBER INDEX
);

-- INDEXED PRF for equality lookup on a UUID column
CREATE BUNDLE accounts (
  account_id TEXT BASE,
  external_uuid TEXT FIBER ENCRYPTED INDEXED INDEX
);

-- PROBABILISTIC for randomized but queryable numeric (Davis Identity)
CREATE BUNDLE scores (
  id INT BASE,
  score NUMERIC FIBER ENCRYPTED PROBABILISTIC SIGMA 0.5
);

-- ISOMETRIC GROUP for vector-like fields — shared O(k) matrix
CREATE BUNDLE telemetry (
  id INT BASE,
  wind_u NUMERIC FIBER ENCRYPTED ISOMETRIC GROUP wind,
  wind_v NUMERIC FIBER ENCRYPTED ISOMETRIC GROUP wind,
  wind_w NUMERIC FIBER ENCRYPTED ISOMETRIC GROUP wind
);
```

**Master-seed sources** (the 32-byte input that derives every per-field
GaugeKey + the base-space hash seed):

```sql
-- Random — server-side CSPRNG (default if no clause given)
CREATE BUNDLE b (...) ;

-- Hex literal — exactly 64 hex chars
CREATE BUNDLE b (...)
  WITH ENCRYPTION SEED '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';

-- Environment variable — the engine reads $NAME at create-time and
-- derives the master seed from its hex value. Production-recommended:
-- the secret never appears in the GQL stream or query log.
CREATE BUNDLE b (...) WITH ENCRYPTION SEED FROM ENV JG_KV_ENCRYPTION_SEED;
```

**Key rotation** (Sprint G — forward secrecy on both seeds):

```sql
-- Rotate (s, g) → (s', g') with a freshly-generated CSPRNG seed
GAUGE chat ROTATE_KEY FORWARD_SECRET;

-- Or rotate to a specific new seed (for staged rollouts)
GAUGE chat ROTATE_KEY FORWARD_SECRET
  WITH ENCRYPTION SEED FROM ENV JG_KV_ENCRYPTION_SEED_V2;
```

After rotation:
- The OLD GaugeKey cannot decrypt any post-rotation record — even if
  the attacker has it AND a backup of the post-rotation storage.
- The OLD base-space hash seed cannot map plaintext keys to their
  post-rotation `BasePoint`s — the lookup-via-old-seed hit rate drops
  to ~0% (≤ 5/1000 by random collision).
- Record count is invariant across rotation. The bundle stays
  queryable end-to-end via the new key.
- Rotation is in-process atomic: a panic mid-rotation leaves the
  ORIGINAL bundle untouched (atomic-swap rebuild). Cross-process
  WAL crash atomicity is on the roadmap.

**Zero-decrypt analytics** (Sprint H — invariant ring):

```sql
-- Each op evaluates directly on ciphertext; bytes decrypted = 0
PROJECT INVARIANT (curvature, confidence, capacity(0.1), spectral_gap,
                   beta_0, beta_1, holonomy_avg)
  FROM chat;

-- WHERE clause filters records before invariant computation
PROJECT INVARIANT (curvature)
  FROM chat
  WHERE created_at > 1700000000;

-- Arithmetic on invariants — closed under + and ×
PROJECT INVARIANT (curvature * confidence) FROM chat;
```

The whitelist of invariant ops is enforced **at parse time** —
`PROJECT INVARIANT (sum)` is a syntax error, not a runtime error. A
query that compiles is one whose evaluator is structurally guaranteed
never to reach a `decrypt_*` function. Pinned by an instrumented
per-thread decrypt counter; see
`gigi/src/invariant.rs::test_project_invariant_zero_decrypt_calls_in_execution_path`.

Allowed ops: `curvature`, `confidence`, `capacity(τ)`, `spectral_gap`,
`beta_0`, `beta_1`, `holonomy_avg`, plus constants and `+`/`*`
combinations of those. (Entropy + full affine-gauge holonomy require
fiber-value access; use the standalone `ENTROPY <bundle>` and
`HOLONOMY ...` statements when you're willing to decrypt.)

### GAUGE — Schema migration (gauge transformation) ✅

```sql
GAUGE sensors TRANSFORM (
  ADD altitude NUMERIC RANGE 5000 DEFAULT 0,
  RENAME temp TO temperature,
  DROP humidity
);
-- curvature_before: 0.0346
-- curvature_after:  0.0346  ✓ gauge invariant
```

Curvature is INVARIANT under gauge transforms. The fiber reshapes; the connection adjusts; K is preserved. Mathematically guaranteed.

### COLLAPSE — Drop a bundle ✅

```sql
COLLAPSE sensors;              -- requires CONFIRM in interactive mode
```

### LENS — Views (virtual bundles) ✅

```sql
LENS moscow_temps AS
  COVER sensors ON city = 'Moscow' PROJECT (date, temp, wind);

-- Query the lens like any bundle
SECTION moscow_temps AT date=20240104;
CURVATURE moscow_temps ON temp;

-- Materialized lens with auto-refresh
LENS daily_stats AS
  INTEGRATE sensors OVER city MEASURE avg(temp), max(wind), count(*)
  MATERIALIZE REFRESH 60;
```

### DESCRIBE / SHOW ✅

```sql
SHOW BUNDLES;
-- name | records | base_geometry | K | confidence | storage

DESCRIBE sensors;
-- Full schema + per-field curvature + storage mode

DESCRIBE sensors VERBOSE;
-- Adds value distributions, anomaly thresholds, bitmap sizes
```

---

## II. Write Operations

### SECTION — Insert a single record ✅

```sql
SECTION sensors (
  id: 42, city: 'Moscow', region: 'EU',
  date: 20240104, temp: -31.9, humidity: 97.4, wind: 2.2
);
-- status omitted → defaults to 'normal' (silence = agreement)
-- Response:
-- SECTION STORED AT base=42
-- confidence: 0.9772  curvature: 0.0233  anomaly: TRUE (z=5.30)
```

### SECTIONS — Batch insert ✅

```sql
SECTIONS sensors (
  42, 'Moscow', 'EU', 20240104, -31.9, 97.4, 2.2,
  43, 'Moscow', 'EU', 20240105, -30.3, 97.8, 1.8,
  44, 'Moscow', 'EU', 20240106, -22.1, 94.2, 3.1
);
-- Single WAL flush. Deferred field index. Batch curvature update.
```

### SECTIONS ... UPSERT — Batch insert-or-update ✅

```sql
SECTIONS sensors (
  42, 'Moscow', 'EU', 20240104, -31.9, 97.4, 2.2,
  43, 'Moscow', 'EU', 20240105, -30.3, 97.8, 1.8
) UPSERT;
-- Each record: insert if key absent, update if key present.
-- Single WAL flush covering the entire batch.
-- Response: { inserted: n, updated: m }
```

### SECTION ... UPSERT — Insert or update ✅

```sql
SECTION sensors (id: 42, city: 'Moscow', temp: -28.5) UPSERT;
-- If exists: update. If not: insert. Response shows which.
```

### REDEFINE — Update ✅

```sql
-- Point update
REDEFINE sensors AT id=42 SET (temp: -28.5);

-- Bulk update via cover
REDEFINE sensors ON city = 'Moscow' SET (region: 'RU');
```

### RETRACT — Delete ✅

```sql
RETRACT sensors AT id=42;

RETRACT sensors ON city = 'TestCity';
-- Response includes curvature_delta
```

### RETURNING — Get back what you wrote ✅

```sql
-- Insert with return
SECTION sensors (id: 99, city: 'Test', region: 'XX', date: 20260317,
  temp: 22.0, humidity: 50.0, wind: 3.0)
RETURNING *;
-- Returns: the stored section + confidence + curvature + anomaly flag

-- Return specific fields
SECTION sensors (...) RETURNING id, confidence, curvature;

-- Update with return (old and new)
REDEFINE sensors AT id=42 SET (temp: -28.5)
RETURNING temp AS new_temp, OLD.temp AS old_temp, curvature;

-- Delete with return
RETRACT sensors AT id=42 RETURNING *;

-- Batch with return
SECTIONS sensors (..., ..., ...)
RETURNING id, anomaly;
-- Returns per-record anomaly flags for the batch
```

---

## III. Point Queries — SECTION AT (O(1)) ✅

```sql
SECTION sensors AT id=42;                               -- full section
SECTION sensors AT id=42 PROJECT (city, temp, wind);    -- projected
SECTION events AT user_id=1001, timestamp=1710000000;   -- composite key
EXISTS SECTION sensors AT id=42;                        -- boolean check
```

Every response includes confidence and curvature. Always.

---

## IV. Range Queries — COVER (O(|r|)) ✅

### The ON / WHERE Distinction

The most important design decision in GQL:

- **ON** uses the **field index** (bitmap lookup). O(|bucket|). For indexed categorical fields.
- **WHERE** applies a **fiber predicate** (value scan). O(|scope|). For comparisons on values.

```sql
COVER sensors ON city = 'Moscow';                        -- bitmap: O(366)
COVER sensors WHERE temp < -25;                          -- full scan: O(7320)
COVER sensors ON city = 'Moscow' WHERE temp < -25;       -- bitmap then filter: O(366)
COVER sensors ON region IN ('EU', 'NA') WHERE wind > 8;  -- union then filter
```

### Full Range Query Capabilities

```sql
-- All sections
COVER sensors ALL;

-- Distinct values
COVER sensors DISTINCT city;                    -- field index keys: O(1)

-- Ordering and pagination
COVER sensors ON city = 'Moscow' RANK BY temp ASC;
COVER sensors RANK BY date DESC FIRST 10;
COVER sensors RANK BY date DESC SKIP 10 FIRST 10;

-- Pattern matching
COVER sensors WHERE city MATCHES 'Mos*';        -- wildcard
COVER sensors WHERE city MATCHES '/^[A-M]/';    -- regex

-- Void/defined handling
COVER sensors WHERE pressure VOID;              -- IS NULL
COVER sensors WHERE pressure DEFINED;           -- IS NOT NULL

-- Confidence filter (GQL-only)
COVER sensors ON city = 'Moscow' CONFIDENCE >= 0.95;
-- Only results from neighborhoods with K < 0.0526

-- Multiple index fields
COVER sensors ON region IN ('EU', 'NA') WHERE wind > 8;

-- Computed projection
COVER sensors PROJECT (
  city, temp,
  temp_max - temp_min AS daily_range,
  CLASSIFY temp
    WHEN temp < 0  THEN 'freezing'
    WHEN temp < 15 THEN 'cold'
    WHEN temp < 25 THEN 'mild'
    ELSE 'hot'
  AS category,
  RESOLVE(pressure, 101.3) AS pressure,
  CONFIDENCE() AS conf,
  CURVATURE() AS K
);

-- Set operations
UNION (COVER sensors ON region = 'EU') WITH (COVER sensors ON region = 'NA');
INTERSECT (COVER sensors WHERE temp > 30) WITH (COVER sensors WHERE humidity > 80);
SUBTRACT (COVER sensors ON city = 'Moscow') MINUS (COVER sensors WHERE temp > 0);

-- Subqueries
COVER sensors ON city IN (
  INTEGRATE sensors OVER city
    MEASURE avg(temp) AS avg_t
    HAVING avg_t < 0
    PROJECT city
);

-- CTEs
WITH cold AS (
  INTEGRATE sensors OVER city MEASURE avg(temp) AS avg_t HAVING avg_t < 5
)
COVER sensors ON city IN (cold PROJECT city) WHERE wind > 8;

-- Filter by geometric functions
COVER sensors WHERE ANOMALY() = TRUE;
COVER sensors WHERE Z_SCORE() > 3.0;
COVER sensors WHERE CONFIDENCE() < 0.90;
```

---

## V. Aggregation — INTEGRATE ✅

INTEGRATE = fiber integral ∫_U h dσ. OVER = base partition. MEASURE = integrand.

```sql
-- Per-group (response auto-includes per-group K and confidence)
INTEGRATE sensors OVER city MEASURE avg(temp), count(*);

-- Global (no OVER = integrate over all of B)
INTEGRATE sensors MEASURE avg(temp), stddev(temp), min(temp), max(temp);

-- Multi-level grouping
INTEGRATE sensors OVER region, city MEASURE avg(temp);

-- HAVING (post-aggregation filter)
INTEGRATE sensors OVER city
  MEASURE avg(temp) AS avg_t, count(*)
  HAVING avg_t < 0;

-- HAVING with curvature (GQL-only)
INTEGRATE sensors OVER city
  MEASURE avg(temp)
  HAVING CURVATURE(temp) > 0.02;

-- Restrict scope before aggregation
INTEGRATE sensors OVER city
  MEASURE avg(temp)
  RESTRICT TO (COVER sensors ON region = 'EU');

-- Ordering + pagination on results
INTEGRATE sensors OVER city
  MEASURE avg(temp) AS avg_t
  RANK BY avg_t ASC FIRST 5;
```

**Aggregate Functions:** avg, sum, count, min, max, stddev, variance

stddev/variance are the **population** forms (divisor n — what SQL calls
STDDEV_POP / VAR_POP), computed in the same single pass as the other
aggregates from a zero-clamped sum-of-squares accumulator. Empty groups
and non-numeric fields return null, matching min/max. median, percentile,
and mode are **not implemented** — the parser rejects them.

### Conditional Aggregation — FILTER clause ✅

```sql
INTEGRATE sensors OVER city MEASURE
  count(*) AS total,
  count(*) FILTER (WHERE temp < 0) AS freezing_days,
  count(*) FILTER (WHERE temp > 30) AS hot_days,
  avg(temp) FILTER (WHERE status = 'alert') AS alert_avg_temp,
  max(wind) FILTER (WHERE status = 'alert') AS alert_max_wind,
  stddev(temp) FILTER (WHERE DATEPART(date, 'month') IN (12, 1, 2)) AS winter_stddev;

-- FILTER with geometric functions (GQL-only)
INTEGRATE sensors OVER city MEASURE
  avg(temp) FILTER (WHERE CURVATURE(temp) > 0.01) AS volatile_avg,
  count(*) FILTER (WHERE CONFIDENCE() < 0.95) AS low_confidence_count;
```

### Error bars for correlated samples — WITH JACKKNIFE ✅

Monte Carlo chains and time series produce *correlated* samples; the naive
standard error `sqrt(var/n)` assumes independence and is always too small on
correlated data — flattering, and wrong. `WITH JACKKNIFE` returns
evidence-grade error bars:

```gql
-- global: mean plaquette over a whole chain, ordered by sweep number
INTEGRATE chain MEASURE avg(plaquette) WITH JACKKNIFE ALONG sweep;

-- per group: one error bar per coupling
INTEGRATE runs OVER beta MEASURE avg(plaquette) WITH JACKKNIFE ALONG sweep;

-- thermalization cut: drop the first 500 ordered samples (per group)
-- before the analysis — burn-in biases both the mean and tau_int
INTEGRATE chain MEASURE avg(plaquette) WITH JACKKNIFE ALONG sweep SKIP FIRST 500;
```

Each `avg(f)` measure returns six columns: `avg_f` (mean), `avg_f_err`
(autocorrelation-corrected bar = naive · √(2·τ_int)), `avg_f_err_naive`,
`avg_f_err_jack` (delete-one-block jackknife with block length ≈ 2·τ_int — an
independent cross-check; if it disagrees badly with `_err`, the chain is
under-sampled), `avg_f_tau_int` (integrated autocorrelation time,
initial-positive-sequence window), and `avg_f_n_eff` (= n / 2·τ_int).

`ALONG <field>` is required — it defines chain order; autocorrelation is
undefined without one. `SKIP FIRST n` is optional (default 0) and is applied
AFTER ordering, so "first" means first along the chain, not insertion order;
a cut that discards all of a group's samples is a loud error. Only `avg()`
measures are supported (an error bar is an estimate of the uncertainty of a
mean); anything else is refused with an explanation. Validated against AR(1)
with known τ_int and a planted burn-in in `src/aggregation.rs` tests and
end-to-end in `tests/gql_reference_truth.rs`.

---

### EXPLAIN the κ — why is this record priced that way? ✅

```gql
EXPLAIN SECTION stations AT station_id='st-042';
-- field | value | mean   | sigma | range | kappa  | z
-- temp  | 500.0 | 20.3…  | 0.17… | 100   | 4.797  | 2760.3
-- wind  | 5.5   | 5.45   | 0.29  | 50    | 0.001  | 0.17
```

`EXPLAIN` wrapped around a point read returns the per-field
decomposition of the record's κ — the SAME loop `compute_record_k`
runs, exported as rows, loudest field first. The record's κ is the
mean of the `kappa` column; `z` is the classical |v−μ|/σ for
cross-checking against textbook anomaly scores. A missing record is a
loud error; a bundle without enough history says so. Works on both the
embedded engine and gigi-stream. Enforced by `tests/explain_kappa.rs`.

### Time you can type — TIMESTAMP fields ✅

```gql
BUNDLE events BASE (id TEXT) FIBER (kind TEXT INDEX, at TIMESTAMP);

SECTION events (id='e1', kind='deploy', at='2026-06-30');          -- date
SECTION events (id='e2', kind='alert',  at='2026-07-01T14:30:05Z');-- datetime
SECTION events (id='e3', kind='deploy', at=1782950400000);         -- epoch ms
SECTION events (id='e4', kind='ping',   at=NOW);                   -- the clock

COVER events WHERE at > '2026-07-01';
COVER events WHERE at <= NOW;
```

`TIMESTAMP` (aliases `DATETIME`, `DATE`) stores epoch milliseconds and
accepts what a person types: `YYYY-MM-DD`, optional `[ T]HH:MM[:SS[.mmm]]`,
optional `Z` — UTC only. Writes normalize before the WAL (replay sees the
same record), comparisons against date strings and epoch integers both
mean what they say, and a string that is not a date is a loud error that
teaches the accepted forms — never stored as text that would compare as
a type tag forever after. `NOW` is the current time as epoch ms and works
anywhere a value does. The CLI renders timestamps as ISO 8601; the wire
keeps raw epoch ms. κ range default: one day (`RANGE(ms)` overrides), so
curvature on a timestamp field prices days-off-pattern.
Enforced end-to-end by `tests/timestamp_ergonomics.rs`.

---

## VI. Window Functions — FIBER Operations ❌ (not implemented)

SQL window functions = GQL fiber operations. Named for what they geometrically ARE.

> **Status correction (audit 2026-07-02):** the FIBER verbs below do not
> currently parse — `FIBER RANK …` returns `Unknown statement: FIBER`. The
> section is kept as the design spec for when they land.

```sql
FIBER RANK sensors OVER city RANK BY date;                              -- ROW_NUMBER
FIBER SUM sensors OF temp OVER city WINDOW date ROWS (UNBOUNDED, 0);   -- cumulative sum
FIBER AVG sensors OF temp OVER city WINDOW date ROWS (-7, 7);          -- 15-day moving avg
FIBER PERCENTRANK sensors OF temp OVER city RANK BY temp;              -- percent rank

-- LAG = parallel transport backward
TRANSPORT sensors OF temp ALONG date SHIFT -1;

-- LEAD = parallel transport forward
TRANSPORT sensors OF temp ALONG date SHIFT +1;

-- Day-over-day delta (inline transport in PROJECT)
COVER sensors PROJECT (
  city, date, temp,
  temp - (TRANSPORT sensors OF temp ALONG date SHIFT -1) AS daily_delta
);
```

**Why TRANSPORT, not LAG:** SQL's LAG is parallel transport along the base space. On a flat connection, transport = array shift. On a curved connection, transport adjusts for Christoffel symbols. GQL names it what it IS.

---

## VII. Joins — PULLBACK (O(|left|)) ✅

```sql
PULLBACK readings ALONG sensor_id ONTO sensors;                              -- inner join
PULLBACK readings ALONG sensor_id ONTO sensors PRESERVE LEFT;                -- left join
PULLBACK orders ALONG customer_id ONTO customers ALONG region ONTO regions;  -- chain
PULLBACK sensors AS s1 ALONG region ONTO sensors AS s2;                      -- self-join
PRODUCT sensors WITH regions;                                                -- cross product
```

### Recursive Joins — ITERATE ✅

```sql
-- WITH RECURSIVE equivalent
WITH RECURSIVE chain AS (
  SECTION employees AT id=1
  UNION
  PULLBACK chain ALONG manager_id ONTO employees
)
COVER chain;

-- Clean syntax: walk a hierarchy
ITERATE employees
  START AT id=1
  STEP ALONG manager_id
  UNTIL VOID;
-- Returns: all reachable sections via iterated pullback along manager_id

-- With depth limit
ITERATE employees
  START AT id=1
  STEP ALONG manager_id
  UNTIL VOID
  MAX DEPTH 10;

-- With accumulation
ITERATE employees
  START AT id=1
  STEP ALONG manager_id
  UNTIL VOID
  ACCUMULATE count(*) AS team_size, sum(salary) AS total_salary;

-- Graph traversal
ITERATE friends
  START AT user_id=42
  STEP ALONG friend_id
  UNTIL DEPTH 3;
-- 3-hop friend-of-friend network
```

---

## VIII. Transactions — ATLAS ❌ NOT IMPLEMENTED

An atlas is a collection of coordinate charts, and the design intent is
that a transaction is an atomic chart transition. **That design is not
built on the GQL surface.** This section previously read ✅ and showed
the syntax below as working. It does not work. What actually happens
today, measured:

| Statement | Actual behavior |
|---|---|
| `BEGIN;` / `ATLAS BEGIN;` | parses; opens no transaction. `501` on `/v1/gql`, `NOTICE` in the embedded executor |
| `COMMIT;` / `ATLAS COMMIT;` | same — there is nothing to commit; writes were already applied when you issued them |
| `ROLLBACK;` / `ATLAS ROLLBACK;` | same — **undoes nothing**. There is no undo log behind this verb |
| `ATLAS SAVEPOINT <n>;` | parse error: `Unknown ATLAS action: SAVEPOINT` |
| `ATLAS ROLLBACK TO <n>;` | parse error: trailing input `TO <n>` rejected |
| `ATLAS BEGIN ISOLATION FLAT/CURVED;` | parse error: trailing input `ISOLATION …` rejected |

Concretely: `BEGIN; INSERT INTO b (id, val) VALUES (1, 42.0); ROLLBACK;`
leaves the row in `b`. Do not wrap writes in these verbs expecting
atomicity.

```sql
-- ❌ NONE of the following is implemented. Kept for shape only.
ATLAS BEGIN;                             -- opens nothing
  SECTION sensors (id: 9001, city: 'Test', ...);
ATLAS COMMIT;                            -- commits nothing
ATLAS ROLLBACK;                          -- undoes nothing
ATLAS SAVEPOINT checkpoint1;             -- parse error
ATLAS ROLLBACK TO checkpoint1;           -- parse error
ATLAS BEGIN ISOLATION FLAT;              -- parse error
ATLAS BEGIN ISOLATION CURVED;            -- parse error
```

### What IS built

Two real things, neither of them the syntax above:

1. **`POST /v1/bundles/{name}/transaction`** (always compiled). A
   single-bundle op list (`insert` / `update` / `delete` / `increment`)
   applied together, with rollback on failure. The rollback works by
   snapshotting **every record in the bundle** before the first op and
   re-inserting them on error — so it costs O(bundle size) in time and
   memory per call regardless of how many ops you send. Fine for small
   bundles; do not put it on a hot path.

2. **`POST /v1/transactions/{begin,write,commit,rollback}`** — requires
   `--features transactions`, off by default. Phase-A: writes are staged
   in memory and applied via `batch_insert` at commit, bundle by bundle.
   Per the handler's own comment, *"if any insert fails, the prior
   bundles' writes are already applied"* — so this is a write lifecycle,
   **not cross-bundle atomicity**. The 2PC coordinator, MVCC snapshot
   isolation, deadlock detector, and geometric-coherence engine in
   `src/transactions/` (3,146 lines, TX1–TX18 gates green) are validated
   against their own gates but are **not wired to live bundles** — no
   file outside `src/transactions/` references `MvccStore`,
   `Coordinator`, or `GeometricCoherenceEngine`.

See `theory/transactions/ATOMIC_SHEAF_COMMIT_SPEC.md` for the intended
design.

### Error handling in transactions

```sql
ATLAS BEGIN;
  SECTION orders (id: 1, customer_id: 999, total: 50.0);
  ON ERROR (
    CASE
      WHEN CONSTRAINT_VIOLATION THEN
        NOTIFY 'constraint_error'
      WHEN MORPHISM_VIOLATION THEN
        NOTIFY 'missing_customer'
      ELSE
        ATLAS ROLLBACK
    END
  );
ATLAS COMMIT;

-- Error info
SHOW LAST ERROR;
-- Returns: error_type, message, constraint_name, field, value, suggestion
```

---

## IX. Subscriptions ✅

```sql
SUBSCRIBE sensors ON status = 'alert';                     -- new matching sections
SUBSCRIBE ANOMALIES sensors ON temp;                       -- curvature spikes
SUBSCRIBE CURVATURE sensors ON temp DRIFT > 0.01;         -- K drift events
SUBSCRIBE CONSISTENCY sensors;                             -- H¹ violations
SUBSCRIBE SPECTRAL sensors;                                -- topology changes
SUBSCRIBE PHASE sensors ON temp;                           -- phase transition events
SUBSCRIBE DIVERGENCE sensors THRESHOLD 0.1;                -- distribution drift
UNSUBSCRIBE sub_id;
```

---

## X. Output Control ✅

### EMIT — Wire format

```sql
COVER sensors ON city = 'Moscow' EMIT DHOOM;                              -- default
COVER sensors ON city = 'Moscow' EMIT DHOOM WITH CURVATURE, CONFIDENCE;   -- metadata
COVER sensors ON city = 'Moscow' EMIT DHOOM BARE;                         -- data only
COVER sensors ON city = 'Moscow' EMIT JSON;
COVER sensors ALL EMIT CSV;
```

### EXPLAIN — Geometric query plan

```sql
EXPLAIN COVER sensors ON city = 'Moscow' WHERE temp < -25;
-- PLAN:
--   Step 1: COVER ON city='Moscow' → bitmap lookup → est. 366 sections [O(366)]
--   Step 2: WHERE temp < -25 → fiber scan [O(366)]
--   Total: O(366)
--   Confidence: 0.9772
--   Wire: DHOOM ~54% smaller than JSON
```

### TRANSLATE — SQL compatibility bridge ✅

```sql
TRANSLATE SQL "SELECT city, AVG(temp), COUNT(*)
               FROM sensors WHERE region='EU'
               GROUP BY city HAVING AVG(temp)<10
               ORDER BY AVG(temp) LIMIT 5";
-- Output:
-- INTEGRATE sensors OVER city
--   MEASURE avg(temp) AS avg_t, count(*)
--   RESTRICT TO (COVER sensors ON region = 'EU')
--   HAVING avg_t < 10
--   RANK BY avg_t ASC FIRST 5;
```

---

## XI. Geometric Operations (GQL-Only)

These are impossible in SQL. They exist because the data lives on a fiber bundle.

### CURVATURE — Local data variability ✅

```sql
CURVATURE sensors ON temp;                                    -- global K for temp
CURVATURE sensors ON temp BY city;                            -- per-city K
CURVATURE sensors ON temp, wind, humidity;                    -- multi-field + scalar
CURVATURE sensors ON temp WITHIN (COVER sensors ON region = 'EU');  -- scoped
```

### RICCI — Ricci curvature between two records ✅

Computes the Ollivier-Ricci curvature between two records (by index) on the data manifold.

```sql
RICCI sensors BETWEEN 0 AND 1;
-- Ricci curvature κ(0, 1) between records at index 0 and 1
-- κ > 0 → records are closer than typical (positively curved neighborhood)
-- κ < 0 → records are farther than typical (negatively curved)
-- κ = 0 → flat — records are at typical geodesic distance

RICCI sensor_das BETWEEN 0 AND 100;
```

**Response fields:**
- `bundle` — bundle name
- `idx_a`, `idx_b` — record indices compared
- `ricci` — Ollivier-Ricci curvature κ(x, y)
- `wasserstein` — 1-Wasserstein distance between neighborhoods
- `mean_dist` — mean neighbor distance used for normalization

### SECTIONAL — Curvature on 2-planes

```sql
SECTIONAL sensors ON temp, humidity;
-- Sectional curvature on the (temp, humidity) 2-plane
-- Positive = data clusters in ellipses. Negative = data spreads in saddles.

SECTIONAL sensors ON temp, humidity BY region;
```

### SCALAR — Total curvature (trace of Ricci)

```sql
SCALAR sensors;
-- Scalar curvature = sum of all sectional curvatures. Single number.

SCALAR sensors BY city;
```

### DEVIATION — Geodesic deviation

```sql
DEVIATION sensors FROM id=42 ALONG date;
-- How does section 42 diverge from neighbors over time?
-- Large deviation = this record is becoming more anomalous

DEVIATION sensors ON temp BY city;
-- Per-city: how are temperature profiles diverging?
```

### TREND — Curvature-based trend detection

```sql
TREND sensors ON temp BY city;
-- dK/dt — is curvature increasing or decreasing over time?

TREND sensors ON temp BY city WINDOW date ROWS (-30, 0);
-- 30-day rolling curvature trend
```

### CONFIDENCE — Query trust level ✅

```sql
CONFIDENCE sensors;                       -- global: 0.9665
CONFIDENCE sensors ON city = 'Moscow';    -- cover-specific: 0.9772
```

### CAPACITY — Davis capacity (C = τ/K) ✅

```sql
CAPACITY sensors;               -- C = τ/K. Davis Theorem 8.1 (Cognitive Geometry Correspondence).
                                -- How many distinct interpretations the system can maintain
                                -- simultaneously at this curvature level (τ = 1.0 default).
CAPACITY sensors TOLERANCE 2.5; -- explicit τ

-- GQL scalar result. For full report including confidence and regime interpretation
-- use GET /v1/bundles/{name}/capacity[?tau=n]
```

**Cognitive Geometry connection:** C = τ/K is the Davis Capacity Law (Thm 8.1). Gate J in
Marcella fires at the C→0 boundary — high curvature, few distinguishable interpretations.

### HORIZON — Holonomy horizon (s_max = τ/(K·ℓ_c)) ✅

```sql
HORIZON sensors;               -- s_max = τ/(K · ℓ_c). Definition 5.1 (Cognitive Geometry Correspondence).
                               -- Maximum coherent context depth: beyond s_max positions,
                               -- contributions to the accumulated frame rotation are irrecoverable.
HORIZON sensors TOLERANCE 3.0; -- explicit τ

-- ℓ_c (correlation length) is estimated from the spectral gap: ℓ_c ≈ 1/√λ₁.
-- Returns Inf when K ≈ 0 (flat geometry, unlimited depth).
-- GQL scalar result. For full report use GET /v1/bundles/{name}/horizon[?tau=n]
```

**Cognitive Geometry connection:** s_max is the maximum sequence length over which a system
can attribute accumulated frame rotation to specific positions. Beyond s_max, non-abelian
holonomy composition has irreversibly mixed individual contributions.

### DEPTH — Encoding depth classification (I–IV) ✅

```sql
DEPTH sensors;
-- Returns encoding depth as a scalar:
--   1.0 → I  (Tangent)     low K, high λ₁  — easily erased (facts from books)
--   2.0 → II (Connection)  moderate K or λ₁ — skill-level persistence (practice)
--   3.0 → III (Metric)     high K, low λ₁  — resists argument (emotional beliefs)
--   4.0 → IV (Topological) K→∞ or λ₁→0    — irrecoverable (trauma, topology change)

-- For the full classification with labels and descriptions
-- use GET /v1/bundles/{name}/depth
```

**Cognitive Geometry connection:** Theorem 8.14 — encoding depth determines how much energy
is required to erase an encoding. The Laplace-Beltrami spectral hierarchy: small λ₁ means
slow diffusion of counter-evidence, high erasure cost.

### SPECTRAL — Index connectivity ✅

```sql
SPECTRAL sensors;                -- λ₁, components, diameter, mixing_time
SPECTRAL sensors ON region;      -- per-index spectral analysis
SPECTRAL sensors FULL;           -- full eigenvalue spectrum
```

See also **SPECTRAL … ON FIBER** above for the fiber-space Laplacian form.

### BOTTLENECK — Find weakest connectivity (Cheeger inequality)

```sql
BOTTLENECK sensors;
-- Finds the minimum cut in the field index graph
-- Returns: bottleneck_set, conductance h, Cheeger bound: λ₁/2 ≤ h ≤ √(2λ₁)

BOTTLENECK sensors ON city;
```

### CLUSTER — Spectral clustering via Fiedler vector

```sql
CLUSTER sensors INTO 4;
-- Pure spectral clustering. No k-means. No embeddings. No Euclidean distance.

CLUSTER sensors INTO 4 BY temp, humidity, wind;

CLUSTER sensors INTO AUTO;
-- Auto-detect cluster count from spectral gap (near-zero eigenvalues)
```

### MIXING — Mixing time estimation

```sql
MIXING sensors;
-- mixing_time = O(1/λ₁)
-- How many hops to reach equilibrium on the field index graph?

MIXING sensors ON region;
```

### CONDUCTANCE — Graph conductance

```sql
CONDUCTANCE sensors;
-- Low conductance = strong internal clusters with weak bridges
-- High conductance = well-mixed data

CONDUCTANCE sensors ON city;
```

### LAPLACIAN — Hodge Laplacian on data forms

```sql
LAPLACIAN sensors;
-- The spectrum IS the topology: zero eigenvalues = components,
-- gap to first nonzero = connectivity strength

LAPLACIAN sensors ON city TOP 5;
```

### HOLONOMY — Loop consistency ✅

```sql
-- Global form: holonomy over the entire bundle
HOLONOMY corpus ON FIBER (f11, f12) AROUND tense_label;
-- Groups records by tense_label, computes 2D centroids, measures
-- parallel transport deficit δφ = |Σ θ_k| mod 2π.
-- Returns one row per group (centroid + transport angle) + summary row:
--   { _type: "summary", holonomy_angle: 0.42, holonomy_trivial: false }
-- holonomy_angle ≈ 0   → trivial bundle (flat connection)
-- holonomy_angle ≈ 2π  → maximally twisted fiber

-- Legacy categorical form (index-based, not fiber-aware):
HOLONOMY sensors AROUND (city, region);
-- holonomy=0 → consistent. holonomy>0 → drift with locations.
```

### HOLONOMY … NEAR — Local holonomy in a proximity neighbourhood ✅

Computes holonomy only within the neighbourhood of a query point. Useful for Marcella-style
NLP embeddings where you want locality-aware geometric analysis rather than a global scan.

```sql
-- Euclidean proximity neighbourhood (default metric)
HOLONOMY corpus
  NEAR (f11=1.0, f12=0.0)
  WITHIN 0.3
  ON FIBER (f11, f12)
  AROUND tense_label;
-- Returns: { local_holonomy_angle, neighbourhood_size }
-- Only records within Euclidean distance 0.3 of the query point participate.

-- Cosine similarity neighbourhood
HOLONOMY corpus
  NEAR (f11=1.0, f12=0.0)
  WITHIN 0.1
  METRIC cosine
  ON FIBER (f11, f12)
  AROUND tense_label;
-- WITHIN r for cosine = minimum similarity 1 − r.
-- METRIC cosine → WITHIN 0.1 means cosine_similarity ≥ 0.9.
```

**Why local holonomy:** The global holonomy scans all N records (O(N)). Local holonomy scans
only the neighbourhood (O(|N_r|)), which for a dense embedding space can be O(log N) with
HNSW indexing. Use local holonomy when you want to ask: *"Is the fiber geometry curved
near this specific point in the embedding space?"*

### SPECTRAL … ON FIBER — Fiber-space Laplacian eigenmodes ✅

Computes the k smallest non-zero eigenvalues (and their inverse participation ratios) of
the normalized Laplacian built from the k-nearest-neighbour graph in the named fiber fields.
Directly answers: *"How many semantic clusters live in this fiber subspace?"*

```sql
SPECTRAL corpus ON FIBER (f11, f12) MODES 3;
-- Returns 3 rows, one per eigenmode:
--   { mode: 1, lambda: 0.012, ipr: 0.83 }
--   { mode: 2, lambda: 0.018, ipr: 0.71 }
--   { mode: 3, lambda: 0.341, ipr: 0.22 }
-- lambda close to 0 → strong cluster boundary
-- ipr (inverse participation ratio) → how localized the mode is
--   ipr ≈ 1 = highly localized (single cluster). ipr ≈ 0 = fully delocalized.

SPECTRAL corpus ON FIBER (f0, f1, f2, f3, f4, f5, f6, f7) MODES 5;
-- Full 8D semantic sphere — how many stable semantic neighborhoods exist?

-- Classic scalar form (spectral gap of the index graph):
SPECTRAL sensors;
SPECTRAL sensors FULL;
```

**Near-zero eigenvalues = cluster count.** If `MODES 5` returns λ₁=0.001, λ₂=0.002,
λ₃=0.003, λ₄=0.41, λ₅=0.57, there are 3 natural clusters in the fiber subspace.

**Algorithm:** exp(−d²) weighted k-NN graph → symmetrized adjacency → normalized Laplacian
→ deflated power iteration. O(N²) for graph build, O(N·iter) per eigenvector.

### TRANSPORT … FROM / TO — Parallel transport between records ✅

Computes the rotation matrix encoding how the fiber has rotated when moving along the
geodesic from one record to another. For NLP embeddings: how much does the semantic
vector rotate between token A and token B?

```sql
TRANSPORT corpus FROM (token_id=42) TO (token_id=99) ON FIBER (f11, f12);
-- Returns one row:
--   { transport_angle: 1.047,  -- rotation in radians
--     t00: 0.500, t01: -0.866, -- 2×2 rotation matrix
--     t10: 0.866, t11:  0.500,
--     displacement_0: 0.12,   -- raw displacement in each fiber dim
--     displacement_1: -0.33 }

TRANSPORT corpus FROM (token_str='walk') TO (token_str='walked') ON FIBER (f4, f11, f12);
-- Tense transport: how much does the tense fiber rotate between forms?
-- transport_angle ≈ π/2 → quarter turn (present → past is a 90° rotation)
-- transport_angle ≈ 0   → trivial transport (same fiber class)
```

**Geometric meaning:** On a curved fiber bundle, moving a vector from point A to point B
along a path rotates the vector. `transport_angle` is that rotation. `t00, t01, t10, t11`
is the 2×2 SO(2) matrix for the 2D fiber subspace. For higher-dimensional fibers, only
the first two dimensions are used for the rotation matrix.

**Window-function form (flat parallel transport — no curvature):**
```sql
TRANSPORT sensors OF temp ALONG date SHIFT -1;   -- LAG(temp, 1) on sorted date
TRANSPORT sensors OF temp ALONG date SHIFT +1;   -- LEAD(temp, 1)
```

### GAUGE … VS — Gauge invariance test across two bundles ✅

Measures whether two bundles have the same holonomy structure in a shared fiber subspace.
If gauge-invariant (deficit < π/10), the two bundles encode the same geometric information
even if their raw values differ — a gauge transformation relates them.

```sql
GAUGE corpus_en VS corpus_fr ON FIBER (f11, f12) AROUND tense_label;
-- Returns one row:
--   { bundle1: "corpus_en",
--     bundle2: "corpus_fr",
--     holonomy_1: 0.312,
--     holonomy_2: 0.298,
--     gauge_difference: 0.014,
--     gauge_invariant: true }
-- gauge_invariant = true when |δφ₁ − δφ₂| < π/10 ≈ 0.314

-- Comparing tense encoding across models:
GAUGE marcella_v1 VS marcella_v2 ON FIBER (f11, f12) AROUND tense_label;
-- If gauge_invariant: true, fine-tuning preserved tense topology.
-- If gauge_invariant: false, the fine-tuning changed the geometry.

-- Multi-axis gauge test:
GAUGE corpus_en VS corpus_de ON FIBER (f8, f9) AROUND person_label;
-- Is person encoding (1st/2nd/3rd) geometrically equivalent between languages?
```

**Interpretation:** Gauge invariance is the mathematical statement that two coordinate
representations are describing the same underlying geometry. `gauge_difference < π/10`
means the two bundles' holonomy angles agree to within a curvature threshold — strong
evidence they are encoding the same fiber topology.

### WILSON — Wilson loop (holonomy along explicit path)

```sql
WILSON sensors AROUND (city='Moscow', region='EU', city='London', region='EU');
-- Parallel transport around a specific path in the index graph
-- Wilson loop ≠ 0 means the data is not self-consistent along this path

WILSON sensors AROUND (date=20240101, date=20240201, date=20240301, date=20240101);
-- Temporal loop: is the data self-consistent across time?
```

### CONSISTENCY — Čech cohomology ✅

```sql
CONSISTENCY sensors;              -- h1: 0 (consistent)
CONSISTENCY sensors REPAIR;       -- attempt cocycle resolution
```

### BETTI — Topological invariants ✅

```sql
BETTI sensors;
-- β₀ = connected components
-- β₁ = independent loops (1-cycles)
-- β₂ = enclosed voids (2-cycles)
-- β₁ > 0 means there are non-contractible loops in your data topology

BETTI sensors ON city, region;
```

### EULER — Euler characteristic

```sql
EULER sensors;
-- χ = β₀ - β₁ + β₂
-- If χ changes after a batch insert, the TOPOLOGY of your data changed
```

### COCYCLE — Extract specific Čech cocycles

```sql
COCYCLE sensors ON (city, region);
-- Returns all nonzero cocycles → each identifies a specific inconsistency

COBOUNDARY sensors ON cocycle_id;
-- Is this cocycle exact (removable by local adjustment)?
-- If no: topological inconsistency — structural, not fixable locally.
```

### TRIVIALIZE — Check bundle triviality

```sql
TRIVIALIZE sensors;
-- TRIVIAL → E ≅ B × F everywhere → can flatten to CSV without loss
-- NON-TRIVIAL → bundle has intrinsic structure that NO flat schema can capture
```

### CHARACTERISTIC — Characteristic classes

```sql
CHARACTERISTIC sensors;
-- c₁ = 0 → bundle is topologically trivializable
-- c₁ ≠ 0 → bundle has intrinsic twist that cannot be removed
```

### ENTROPY — Shannon entropy ✅

```sql
ENTROPY sensors;
-- H = -Σ p(x) log p(x)

ENTROPY sensors ON status;
ENTROPY sensors ON temp BY city;
```

### DIVERGENCE — KL divergence between bundles ✅

Computes Gaussian KL divergence and Jensen–Shannon divergence between two bundles using lazy-cached per-field sufficient statistics. O(1) per query after the first call (which warms the stats cache).

```sql
DIVERGENCE FROM sensor_das TO sensor_sonar;
-- Compare numeric field distributions between two bundles
-- Returns kl_forward, kl_reverse, jensen_shannon, fields_compared, per_field

-- VS alias (ICARUS form) — equivalent to FROM ... TO:
DIVERGENCE sensor_das VS sensor_sonar;

DIVERGENCE FROM chembl_activities TO chembl_assays;
-- Cross-domain divergence — fields_compared = 0 if no shared numeric fields

DIVERGENCE FROM sensor_das TO sensor_das;
-- Same bundle → kl_forward = 0.0  (sanity check)
```

**Response fields:**
- `kl_forward` — KL(A‖B): how surprising B's distribution is under A's model
- `kl_reverse` — KL(B‖A): symmetric direction
- `jensen_shannon` — JS divergence (symmetric, bounded [0, ln 2])
- `fields_compared` — number of shared numeric fields used in computation
- `per_field` — per-field KL contribution

**Math:** Uses Gaussian KL from sufficient statistics (μ, σ²) cached per field:
$$KL(P\|Q) = \frac{1}{2}\left[\frac{\sigma_P^2}{\sigma_Q^2} + \frac{(\mu_P - \mu_Q)^2}{\sigma_Q^2} - 1 + \ln\frac{\sigma_Q^2}{\sigma_P^2}\right]$$

**Also available via REST:** `POST /v1/divergence` — see API reference.

### FISHER — Fisher information metric

```sql
FISHER sensors ON temp, humidity;
-- Natural metric on the statistical manifold of the data
-- High Fisher = small changes in temp strongly predict humidity changes

FISHER sensors ON temp, humidity BY city;
```

### MUTUAL — Mutual information between fields

```sql
MUTUAL sensors ON temp WITH humidity;
-- I(temp; humidity) = H(temp) + H(humidity) - H(temp, humidity)
-- I = 0 → independent. I >> 0 → strongly coupled.

MUTUAL sensors ON temp WITH wind BY city;
```

### FREEENERGY — Helmholtz free energy ✅

```sql
FREEENERGY sensors TOLERANCE 0.1;
-- F = -τ log Z(β, p)
-- Low F = data is in a "low energy" state (well-organized)
-- ΔF between snapshots measures how much the data's organization changed

FREEENERGY sensors BY city TOLERANCE 1.0;
```

### TEMPERATURE — Effective temperature per neighborhood

```sql
TEMPERATURE sensors;
-- Effective τ at each neighborhood, computed from local fluctuations
-- High temperature = high local variance = approximate queries are safe

TEMPERATURE sensors BY city;
```

### PHASE — Phase transition detection

```sql
PHASE sensors ON temp;
-- Detect discontinuities in curvature K as function of base parameters

PHASE sensors ON temp ALONG date;
-- "Phase transition detected at date=20240315: K jumped from 0.01 to 0.04"

PHASE sensors ON temp ALONG date BY city;
```

### CRITICAL — Find critical points

```sql
CRITICAL sensors ON temp;
-- Points where ∂K/∂(base) = 0
-- Returns: base_points, K_value, type (minimum / maximum / saddle)

CRITICAL sensors ON temp BY city;
```

### PARTITION — Approximate queries (statistical mechanics)

```sql
PARTITION sensors AT city = 'Moscow' TOLERANCE 0.5;    -- fuzzy match
PARTITION sensors WHERE temp NEAR 22.0 TOLERANCE 2.0;  -- neighborhood

CALIBRATE sensors TOLERANCE 0.01;                       -- set default τ
```

### TRANSPORT — Parallel transport ✅

```sql
TRANSPORT sensors OF temp FROM id=42 TO id=100;          -- point-to-point
TRANSPORT sensors OF temp ALONG date SHIFT -1;           -- LAG (flat)
TRANSPORT sensors OF temp ALONG date SHIFT +1;           -- LEAD (flat)
```

### FLOW — Renormalization group (C-theorem)

```sql
FLOW sensors COARSEN BY region LEVELS 3;
-- Returns entropy per level. C-theorem: non-increasing.
-- Violation = structural anomaly at that scale.

FLOW sensors COARSEN BY city LEVELS 5 SHOW ENTROPY;
```

### GEODESIC — Shortest path ✅

```sql
GEODESIC sensors FROM id=42 TO id=100;
GEODESIC sensors FROM city='Moscow' TO city='Singapore';
```

### SIMILAR — Find geometrically similar sections

```sql
SIMILAR sensors TO id=42 WITHIN 0.1;
-- Uses fiber distance (not Euclidean!) — normalized by field ranges

SIMILAR sensors TO id=42 WITHIN 0.1 ON temp, wind;

SIMILAR sensors TO id=42 TOP 10;
-- 10 nearest geodesic neighbors
```

### CORRELATE — Geometric correlation via connection

```sql
CORRELATE sensors ON temp WITH wind;
-- Geometric correlation on the MANIFOLD, not in flat Euclidean space

CORRELATE sensors ON temp WITH wind BY city;
```

### SEGMENT — Geometric segmentation

```sql
SEGMENT sensors INTO 4 BY temp, humidity, wind;
-- Curvature-based clustering: natural segments where K is locally minimal

SEGMENT sensors INTO AUTO;
-- Number of local K minima = number of natural segments
```

### OUTLIER — Flag outliers by curvature

```sql
OUTLIER sensors ON temp SIGMA 3;
-- Curvature-normalized thresholds (adaptive, not global)
-- High-K neighborhoods → wider thresholds. Low-K → tighter thresholds.

OUTLIER sensors ON temp, wind SIGMA 2.5 BY city;
```

### PROFILE — Full geometric data profile ✅

```sql
PROFILE sensors;
-- Per-field: K, confidence, entropy, range, distinct_count, void_rate
-- Per-pair: Ricci curvature, Fisher information, mutual information
-- Global: scalar curvature, spectral gap, Betti numbers, Euler characteristic
-- Storage: base geometry, estimated compression via DHOOM
-- Anomalies: top outliers with Z-scores
-- One call. Everything you need to understand your data geometrically.
```

### DOUBLECOVER — S + d² = 1 verification

```sql
DOUBLECOVER sensors ON (COVER sensors ON city = 'Moscow');
-- Returns: S=0.998, d=0.045, S+d²=1.000 ✓

RECALL sensors ON (COVER sensors WHERE temp < -25);
-- What fraction of relevant records were returned?

COMPLETENESS sensors ON (COVER sensors WHERE temp < -25);
-- Full Double Cover check: S + d² = 1?
```

### RESTRICT — Sheaf restriction ⚠️

```sql
RESTRICT sensors TO (COVER sensors ON region = 'EU') AS eu_sensors;
```

### GLUE — Explicit sheaf gluing ⚠️

```sql
GLUE (COVER sensors ON region = 'EU') WITH (COVER sensors ON region = 'NA') CHECK OVERLAP;
```

### PREDICT — Curvature forecasting ✅

```sql
PREDICT sensors ON temp BY city;
PREDICT sensors ON temp BY city TRAIN BEFORE date=20240901 TEST AFTER date=20240901;
```

### DIFF — Bundle comparison

```sql
DIFF sensors_v1 AGAINST sensors_v2;
DIFF sensors AT SNAPSHOT 'yesterday' AGAINST sensors;
```

### SNAPSHOT — Point-in-time capture ✅

```sql
SNAPSHOT sensors AS 'pre_migration';
```

### HEALTH — Full diagnostic ✅

```sql
HEALTH sensors;
```

### GAUGE VERIFY — Post-migration invariance check

```sql
GAUGE VERIFY sensors;
-- Returns: K_before, K_after, delta, status (INVARIANT / VIOLATED)
-- If VIOLATED: identifies which transformation broke invariance
```

---

## XII. Bulk Import/Export — INGEST ✅ (NPZ, CSV, JSONL) · EMIT CSV ✅ (gated)

### INGEST — Bulk import from files ✅

What ships today (enforced end-to-end by `tests/ingest_executor.rs` and
`tests/ingest_csv_basic.rs`):

```sql
-- NumPy archive: one record per outer-axis slice, vector fibers
INGEST harvest FROM 'links.npz' FORMAT NPZ;
INGEST harvest FROM 'links.npz' FORMAT NPZ KEY links_su3;  -- pick one member

-- CSV: header row names the fields, one record per data row
INGEST stations FROM 'stations.csv' FORMAT CSV;
INGEST chembl   FROM 'molecules.csv' FORMAT CSV KEY chembl_id;

-- JSONL / NDJSON: one object per line; KEY is required (JSON objects
-- have no column order). Numeric arrays become Vector fibers, so
-- embeddings ingest as first-class vectors. Brain endpoints expand a
-- vector(d) fiber into d sample columns per record (since 2026-08-02;
-- earlier builds skipped Vector fibers in /brain/* — symptom was a
-- 200 with n_samples: 0). Exploded scalar fields v0..vN remain fully
-- supported; the VECTOR (v0..vN) range sugar assembles them.
INGEST docs FROM 'embeddings.jsonl' FORMAT JSONL KEY doc_id;
```

CSV policy: the base key is the `KEY <col>` column, or the FIRST column
when no KEY is given. Column types are inferred from the data — a column
whose every non-empty value is numeric becomes NUMERIC, everything else
CATEGORICAL (numbers in a mixed column are stored as text so the column
stays one type). Quoted fields and embedded commas are handled. Loud
errors: KEY names a missing column (lists the header), header with no
data rows, empty base-key cell (row number named). If the target bundle
does not exist it is auto-created from the inferred schema; if it
exists, the inferred schema must be compatible.

> **Status correction (audit 2026-07-02):** the richer INGEST sugar this
> section used to show — `HEADER`/`DELIMITER`/`NULL_VALUE`/`SKIP`
> options, `FORMAT JSON/DHOOM/SQL`, `FROM STDIN`, `FROM <url>`,
> `MAP (...)` renames, `FILTER (...)` — is design spec, NOT implemented.
> Unsupported formats are refused with the supported list; unsupported
> clauses are refused by the trailing-token guard.

### EMIT TO — CSV export ✅ (gated on GIGI_EMIT_DIR)

```sql
COVER sensors ALL                                EMIT CSV TO 'exports/rows.csv';
COVER sensors ON city='Moscow' WHERE temp < -20  EMIT CSV TO 'moscow_cold.csv';
INTEGRATE sensors OVER city MEASURE count(*), avg(temp)
                                                 EMIT CSV TO 'city_stats.csv';
SHOW FIELDS ON sensors                           EMIT CSV TO 'schema.csv';
```

`EMIT CSV TO '<path>'` is a suffix on any rows-producing statement. It
executes only when the engine's environment sets `GIGI_EMIT_DIR`, and
the path must be relative with no `..` — files land strictly inside
that directory, so a public server that never sets the variable can
never be talked into writing files. Without the gate the statement is
refused loudly (the error names the knob) and the inner statement does
NOT run. Cells containing commas/quotes/newlines are RFC-4180 quoted;
columns are the sorted union of row keys; the receipt is a NOTICE with
the row count and resolved path. Only CSV is accepted (JSON rows are
what the HTTP surface already returns). Enforced by `tests/emit_csv.rs`
and `tests/gql_reference_truth.rs`.

## XIII. Generate Series & Fill

### GENERATE BASE ✅

```sql
GENERATE BASE sensors
  FROM date=20240101 TO date=20241231 STEP 1;
-- Creates section stubs at every base point. Sections with no data have VOID fibers.

-- Pre-populate specific fields
GENERATE BASE sensors
  FROM date=20240101 TO date=20241231 STEP 1
  WITH (city: 'Moscow', region: 'EU');

-- Detect gaps (dates with no data)
COVER sensors ON city = 'Moscow' WHERE temp VOID;

-- Integer sequence (for testing / synthetic data)
GENERATE BASE test_bundle
  FROM id=1 TO id=1000000 STEP 1;
```

### FILL — Gap filling

```sql
-- Fill via parallel transport (curvature-aware)
FILL sensors ON date USING TRANSPORT;

-- Linear interpolation
FILL sensors ON date USING INTERPOLATE LINEAR;

-- Constant fill
FILL sensors ON date
  USING CONSTANT (temp: 0.0, humidity: 50.0);
```

---

## XIV. Copy Between Bundles — TRANSPLANT

```sql
-- Copy all sections
TRANSPLANT sensors INTO sensors_archive;

-- Copy with filter
TRANSPLANT sensors INTO sensors_archive
  WHERE date < 20240601;

-- Copy with field rename
TRANSPLANT sensors INTO sensors_v2
  MAP (
    temp -> temperature,
    humidity -> relative_humidity
  );

-- Move (copy + retract from source)
TRANSPLANT sensors INTO sensors_archive
  WHERE date < 20240101
  RETRACT SOURCE;
```

---

## XV. Built-in Functions

### Math Functions

```sql
COVER sensors PROJECT (
  ABS(temp) AS abs_temp,
  ROUND(temp, 1) AS rounded,
  CEIL(wind) AS wind_ceil,
  FLOOR(humidity) AS humid_floor,
  TRUNC(temp, 0) AS truncated,
  POWER(temp, 2) AS temp_squared,
  SQRT(ABS(temp)) AS temp_root,
  CBRT(ABS(temp)) AS cube_root,
  LOG(pressure) AS log_p,
  LOG10(pressure) AS log10_p,
  LOG2(pressure) AS log2_p,
  EXP(temp / 100) AS exp_scaled,
  MOD(id, 3) AS bucket,
  SIGN(temp) AS direction,
  GREATEST(temp, 0) AS temp_floor_zero,
  LEAST(temp, 40) AS temp_cap,
  PI() AS pi_val,
  RANDOM() AS rand
);
```

### String Functions

```sql
COVER sensors PROJECT (
  UPPER(city) AS city_upper,
  LOWER(city) AS city_lower,
  INITCAP(city) AS city_title,
  LENGTH(city) AS name_len,
  SUBSTR(city, 1, 3) AS prefix,
  LEFT(city, 3) AS left3,
  RIGHT(city, 3) AS right3,
  CONCAT(city, '-', region) AS label,
  CONCAT_WS(', ', city, region) AS full,
  REPLACE(status, 'normal', 'ok') AS stat,
  TRIM(city) AS trimmed,
  LTRIM(city) AS left_trimmed,
  RTRIM(city) AS right_trimmed,
  LPAD(id, 5, '0') AS padded_id,
  RPAD(city, 15, '.') AS dotted,
  REVERSE(city) AS reversed,
  REPEAT('*', 3) AS stars,
  POSITION('ow' IN city) AS pos,
  SPLIT(city, '_') AS parts,
  MD5(city) AS checksum
);
```

### Date/Time Functions

```sql
COVER events PROJECT (
  NOW() AS current_time,
  TODAY() AS current_date,
  EPOCH(timestamp) AS unix_ts,
  FROM_EPOCH(1710000000) AS ts,
  DATEPART(timestamp, 'year') AS yr,
  DATEPART(timestamp, 'month') AS mo,
  DATEPART(timestamp, 'day') AS dy,
  DATEPART(timestamp, 'hour') AS hr,
  DATEPART(timestamp, 'dow') AS day_of_week,  -- 0=Sun, 6=Sat
  DATEPART(timestamp, 'doy') AS day_of_year,
  DATETRUNC(timestamp, 'month') AS month_start,
  DATETRUNC(timestamp, 'day') AS day_start,
  DATEADD(timestamp, 7, 'day') AS next_week,
  DATEADD(timestamp, -1, 'month') AS last_month,
  DATEDIFF(end_ts, start_ts, 'hours') AS duration_hrs,
  DATEDIFF(end_ts, start_ts, 'days') AS duration_days,
  FORMAT_DATE(timestamp, 'YYYY-MM-DD') AS formatted,
  PARSE_DATE('2024-01-04', 'YYYY-MM-DD') AS parsed
);
```

### Type Casting

```sql
COVER sensors PROJECT (
  CAST(temp AS TEXT) AS temp_str,
  CAST('42' AS NUMERIC) AS num,
  CAST(temp AS INTEGER) AS temp_int,
  CAST(1 AS BOOLEAN) AS flag
);

-- Shorthand
COVER sensors PROJECT (
  temp::TEXT AS temp_str,
  '42'::NUMERIC AS num
);
```

### Conditional Expressions

```sql
COVER sensors PROJECT (
  -- CLASSIFY (extended CASE/WHEN)
  CLASSIFY temp
    WHEN temp < -20 THEN 'extreme_cold'
    WHEN temp < 0   THEN 'freezing'
    WHEN temp < 15  THEN 'cold'
    WHEN temp < 25  THEN 'mild'
    WHEN temp < 35  THEN 'warm'
    ELSE 'extreme_heat'
  AS category,

  -- IF (two-branch)
  IF(temp < 0, 'below_zero', 'above_zero') AS freezing,

  -- RESOLVE (COALESCE)
  RESOLVE(pressure, 101.3) AS pressure_safe,

  -- VOIDIF (NULLIF equivalent)
  VOIDIF(wind, 0) AS wind_nonzero,

  -- GREATEST / LEAST
  GREATEST(temp, temp_min, 0) AS warmest,
  LEAST(temp, temp_max, 40) AS coolest
);
```

### Array/Collection Functions

```sql
-- Array construction
COVER sensors PROJECT (
  ARRAY(temp, humidity, wind) AS measurements,
  ARRAY_LENGTH(ARRAY(temp, humidity, wind)) AS n_measures
);

-- Array aggregation
INTEGRATE sensors OVER city MEASURE
  ARRAY_AGG(temp) AS all_temps,
  ARRAY_AGG(temp RANK BY date ASC) AS ordered_temps;

-- JSON construction
COVER sensors PROJECT (
  JSON_BUILD(
    'city', city,
    'temp', temp,
    'confidence', CONFIDENCE()
  ) AS record_json
);
```

### System Functions (usable in PROJECT or WHERE)

```sql
NOW()                -- current timestamp
TODAY()              -- current date
CURRENT_ROLE()       -- current role name
CURRENT_BUNDLE()     -- last accessed bundle
VERSION()            -- GIGI version string

-- Geometric state functions
CONFIDENCE()         -- confidence at current base point
CURVATURE()          -- K at current base point
ANOMALY()            -- boolean anomaly flag
Z_SCORE()            -- z-score at current base point
CAPACITY()           -- C = τ/K at current base point
DRIFT(field)         -- recent curvature drift (used in triggers)
DIFF(OLD, NEW)       -- field diff (used in triggers)
```

---

## XVI. Access Control ❌ (501 — Not Yet Implemented)

The access control syntax is fully specified and parsed. All operations return HTTP 501.

### WEAVE — Create roles

```sql
WEAVE ROLE analyst;
WEAVE ROLE admin;
WEAVE ROLE api_user PASSWORD 'secure_hash_here';
WEAVE ROLE admin INHERITS analyst;
WEAVE ROLE superadmin SUPERWEAVE;

UNWEAVE ROLE analyst;
SHOW ROLES;
```

### GRANT / REVOKE — Permissions

```sql
GRANT SECTION ON sensors TO admin;
GRANT COVER ON sensors TO analyst;
GRANT REDEFINE ON sensors TO admin;
GRANT RETRACT ON sensors TO admin;
GRANT CURVATURE ON sensors TO analyst;
GRANT SPECTRAL ON sensors TO analyst;
GRANT HEALTH ON sensors TO analyst;
GRANT ALL ON sensors TO admin;
GRANT COVER ON ALL BUNDLES TO readonly;

REVOKE RETRACT ON sensors FROM analyst;
REVOKE ALL ON sensors FROM readonly;

GRANT BUNDLE TO admin;
GRANT GAUGE ON sensors TO admin;
GRANT COLLAPSE ON sensors TO admin;
```

### POLICY — Row-level security via geometric restriction

```sql
-- Analyst can only see EU data
POLICY analyst_eu ON sensors
  FOR COVER
  RESTRICT TO (COVER sensors ON region = 'EU')
  TO analyst;

-- Write restriction
POLICY admin_eu ON sensors
  FOR SECTION, REDEFINE, RETRACT
  RESTRICT TO (COVER sensors ON region = 'EU')
  TO admin;

-- Curvature-based access (GQL-only — no Postgres equivalent)
POLICY high_confidence ON sensors
  FOR COVER
  RESTRICT TO (COVER sensors CONFIDENCE >= 0.95)
  TO analyst;
-- Analyst can only see records from low-curvature regions. The geometry determines access.

DROP POLICY analyst_eu ON sensors;
SHOW POLICIES ON sensors;
```

### AUDIT — Audit trail

```sql
AUDIT sensors ON;
AUDIT sensors ON SECTION, REDEFINE, RETRACT, GAUGE;
AUDIT SHOW sensors;
AUDIT SHOW sensors SINCE '2024-01-01';
AUDIT SHOW sensors ROLE admin;
AUDIT sensors OFF;
```

---

## XVII. Constraints ✅

### Fiber Value Constraints (inline)

```sql
BUNDLE orders
  BASE (id NUMERIC AUTO)
  FIBER (
    customer_id NUMERIC REQUIRED,
    total NUMERIC REQUIRED CHECK (total > 0),
    qty NUMERIC CHECK (qty >= 1 AND qty <= 10000),
    status CATEGORICAL IN ('pending', 'shipped', 'delivered', 'cancelled'),
    email TEXT CHECK (email MATCHES '/^[^@]+@[^@]+\.[^@]+$/'),
    discount NUMERIC CHECK (discount >= 0 AND discount <= 1),
    customer_id NUMERIC REFERENCES customers(id),
    region_id NUMERIC REFERENCES regions(id)
  );
```

### CONSTRAINT block — Cross-field and composite constraints

```sql
BUNDLE orders
  BASE (id NUMERIC AUTO)
  FIBER (...)
  CONSTRAINT (
    UNIQUE (customer_id, date),
    CHECK (ship_date >= order_date),
    CHECK (discount_total <= total),
    CHECK (qty * unit_price = line_total),
    CHECK (status = 'shipped' IMPLIES ship_date DEFINED),
    CHECK (status = 'cancelled' IMPLIES cancel_reason DEFINED),
    MORPHISM customer_id -> customers(id),
    MORPHISM region_id -> regions(id),
    EXCLUDE (customer_id WITH =, daterange WITH OVERLAPS)
  );
```

### Adding/Dropping constraints after creation

```sql
GAUGE orders CONSTRAIN (
  ADD CHECK (total > 0) AS positive_total,
  ADD UNIQUE (customer_id, date) AS unique_order,
  ADD MORPHISM region_id -> regions(id)
);

GAUGE orders UNCONSTRAIN positive_total;
SHOW CONSTRAINTS ON orders;
```

---

## XVIII. Triggers ⚠️ (Parsed — Not Yet Implemented)

The trigger syntax is fully specified. The `TriggerManager` is built in the engine. Nothing is wired to HTTP yet.

```sql
-- Trigger on insert
ON SECTION sensors
  EXECUTE NOTIFY 'new_reading';

-- Conditional trigger
ON SECTION sensors
  WHERE temp < -30
  EXECUTE ALERT 'extreme_cold';

-- Trigger with action
ON SECTION sensors
  WHERE status = 'alert'
  EXECUTE (
    SECTION alerts (
      source: 'sensors',
      record_id: NEW.id,
      message: CONCAT('Alert from ', NEW.city, ': temp=', NEW.temp),
      timestamp: NOW()
    )
  );

-- Trigger on curvature drift
ON CURVATURE sensors
  WHERE DRIFT(temp) > 0.01
  EXECUTE NOTIFY 'volatility_shift';

-- Auto-repair on consistency violation
ON CONSISTENCY sensors
  WHERE h1 > 0
  EXECUTE REPAIR;

-- Cascade delete
ON RETRACT customers
  CASCADE RETRACT orders WHERE customer_id = OLD.id;

-- Cascade via morphism
ON RETRACT customers
  CASCADE MORPHISM;

-- Before-trigger (validation)
BEFORE SECTION orders
  CHECK (EXISTS SECTION customers AT id = NEW.customer_id)
  ON FAIL REJECT 'Customer does not exist';

-- After-trigger (logging)
AFTER REDEFINE sensors
  EXECUTE (
    SECTION audit_log (
      bundle: 'sensors',
      action: 'REDEFINE',
      record_id: OLD.id,
      changed_fields: DIFF(OLD, NEW),
      timestamp: NOW(),
      role: CURRENT_ROLE()
    )
  );

DROP TRIGGER extreme_cold ON sensors;
SHOW TRIGGERS ON sensors;
```

---

## XIX. Prepared Statements ❌ (501 — Not Yet Implemented)

```sql
PREPARE point_lookup AS
  SECTION sensors AT id = $1;

EXECUTE point_lookup (42);

PREPARE city_query AS
  COVER sensors ON city = $1 WHERE temp < $2;

EXECUTE city_query ('Moscow', -25);

PREPARE region_stats AS
  INTEGRATE sensors OVER city
    MEASURE avg(temp), count(*)
    RESTRICT TO (COVER sensors ON region = $1);

EXECUTE region_stats ('EU');

DEALLOCATE point_lookup;
DEALLOCATE ALL;
SHOW PREPARED;
```

---

## XX. Backup & Restore ❌ (501 — Not Yet Implemented)

```sql
BACKUP sensors TO 'sensors_2024.gigi';
BACKUP ALL TO 'full_backup_2024.gigi';
BACKUP sensors TO 'sensors.gigi.zst' COMPRESS;
BACKUP sensors TO 'sensors_incr.gigi' INCREMENTAL SINCE '2024-06-01';

RESTORE sensors FROM 'sensors_2024.gigi';
RESTORE sensors FROM 'sensors_2024.gigi' AT SNAPSHOT 'pre_migration';
RESTORE sensors FROM 'sensors_2024.gigi' AS sensors_restored;

VERIFY BACKUP 'sensors_2024.gigi';
-- Returns: sections, schema hash, curvature at backup time, CRC check

SHOW BACKUPS;
```

---

## XXI. Maintenance Operations ⚠️ (Parsed — Not Yet Implemented)

```sql
-- WAL compaction
COMPACT sensors;
COMPACT sensors ANALYZE;

-- Refresh geometric statistics
ANALYZE sensors;
ANALYZE sensors ON temp;
ANALYZE sensors FULL;

-- Storage report ✅ (this one works)
STORAGE sensors;
-- base_geometry: SEQUENTIAL
-- sections: 7320
-- memory_usage: 4.2 MB
-- wal_size: 1.8 MB
-- compression_ratio: 3.2x vs raw JSON

-- Rebuild field index
REBUILD INDEX sensors;
REBUILD INDEX sensors ON city;

-- Vacuum (reclaim space from retracted sections)
VACUUM sensors;
VACUUM sensors FULL;

-- Check integrity
CHECK sensors;
-- Verifies WAL CRC, field index consistency, GIGI hash uniqueness,
-- constraint satisfaction, curvature cache accuracy

-- Repair
REPAIR sensors;
```

---

## XXII. Session & Connection Management ❌ (501 — Not Yet Implemented)

```sql
SET TOLERANCE 0.01;
SET EMIT DHOOM;
SET ANOMALY_THRESHOLD 2.5;
SET MAX_SECTIONS 1000000;

SHOW SETTINGS;
SHOW SESSION;
SHOW CURRENT ROLE;

RESET TOLERANCE;
RESET ALL;
```

---

## XXIII. Information Schema ✅

```sql
SHOW BUNDLES;
SHOW BUNDLES VERBOSE;

DESCRIBE sensors;
DESCRIBE sensors VERBOSE;

SHOW FIELDS ON sensors;
-- name, type, modifiers, K, distinct_count, void_rate, index_size

SHOW INDEXES ON sensors;
-- field, distinct_values, bucket_sizes, bitmap_memory

SHOW CONSTRAINTS ON orders;
SHOW MORPHISMS ON sensors;
-- field, target_bundle, target_field, referential_integrity_status

SHOW TRIGGERS ON sensors;
SHOW POLICIES ON sensors;

SHOW STATISTICS ON sensors;
-- per-field mean, stddev, min, max, K, entropy, distinct, void_rate

SHOW GEOMETRY ON sensors;
-- scalar_K, spectral_gap, betti_numbers, euler_characteristic,
-- storage_mode, base_geometry, double_cover_status
```

---

## XXIV. Comments ❌ (501 — Not Yet Implemented)

```sql
COMMENT ON BUNDLE sensors IS 'NASA POWER atmospheric data, 20 cities, 2024';
COMMENT ON FIELD sensors.temp IS 'Temperature at 2 meters (°C), RANGE 80 for K normalization';
COMMENT ON CONSTRAINT positive_total ON orders IS 'Prevents negative order totals';
SHOW COMMENTS ON sensors;
```

---

## XXV. Formal Grammar (EBNF)

```
program       = statement ( ";" statement )* ";"?

statement     = bundle_stmt | gauge_stmt | gauge_test_stmt | collapse_stmt | lens_stmt
              | section_stmt | sections_stmt | redefine_stmt | retract_stmt
              | point_query | cover_stmt | integrate_stmt | pullback_stmt
              | fiber_window | curvature_stmt | confidence_stmt | spectral_stmt
              | holonomy_stmt | consistency_stmt | partition_stmt | calibrate_stmt
              | transport_stmt | transport_fiber | flow_stmt | geodesic_stmt | restrict_stmt
              | glue_stmt | predict_stmt | diff_stmt | snapshot_stmt
              | health_stmt | atlas_stmt | subscribe_stmt | explain_stmt
              | translate_stmt | show_stmt | describe_stmt
              | set_op | product_stmt | with_stmt

bundle_stmt   = "BUNDLE" name "BASE" "(" field_defs ")" "FIBER" "(" field_defs ")"
                ( "OPTIONS" "(" option_list ")" )?
gauge_stmt    = "GAUGE" name "TRANSFORM" "(" alterations ")"
collapse_stmt = "COLLAPSE" name
lens_stmt     = "LENS" name "AS" query ( "MATERIALIZE" ( "REFRESH" number )? )?
section_stmt  = "SECTION" name "(" kv_pairs ")" ( "UPSERT" )? ( "RETURNING" proj_list )?
sections_stmt = "SECTIONS" name "(" value_rows ")" ( "RETURNING" proj_list )?
redefine_stmt = "REDEFINE" name ( "AT" key_preds | on_clause ) "SET" "(" kv_pairs ")"
                ( "RETURNING" proj_list )?
retract_stmt  = "RETRACT" name ( "AT" key_preds | on_clause ) ( "RETURNING" proj_list )?
point_query   = ( "EXISTS" )? "SECTION" name "AT" key_preds ( project )?
cover_stmt    = "COVER" name ( "ALL" | on_clause? where_clause? )
                distinct? rank? pagination? confidence_filter? emit?
integrate_stmt = "INTEGRATE" name ( "OVER" field_list )? "MEASURE" agg_list
                 restrict? having? rank? pagination?
fiber_window  = "FIBER" agg_name name "OF" field "OVER" field
                ( "WINDOW" field "ROWS" "(" bound "," bound ")" )?
              | "FIBER" ( "RANK" | "PERCENTRANK" ) name "OF"? field? "OVER" field
                "RANK" "BY" field
pullback_stmt = "PULLBACK" name ("AS" alias)? ("ALONG" field "ONTO" name ("AS" alias)?)+
                ("PRESERVE" "LEFT")?
transport_stmt = "TRANSPORT" name "OF" field
                 ("FROM" key_preds "TO" key_preds | "ALONG" field "SHIFT" signed_num)
product_stmt  = "PRODUCT" name "WITH" name
set_op        = ("UNION"|"INTERSECT") "(" query ")" "WITH" "(" query ")"
              | "SUBTRACT" "(" query ")" "MINUS" "(" query ")"
with_stmt     = "WITH" ("RECURSIVE")? name "AS" "(" query ")" statement
iterate_stmt  = "ITERATE" name "START" "AT" key_preds "STEP" "ALONG" field
                "UNTIL" ("VOID" | "DEPTH" number) ("MAX" "DEPTH" number)?
                ("ACCUMULATE" agg_list)?
curvature_stmt  = "CURVATURE" name "ON" field_list ("BY" field)? ("WITHIN" "(" query ")")?
confidence_stmt = "CONFIDENCE" name (on_clause)?
spectral_stmt   = "SPECTRAL" name ("ON" field)? ("FULL")?
                | "SPECTRAL" name "ON" "FIBER" "(" field_list ")" "MODES" number
holonomy_stmt   = "HOLONOMY" name "AROUND" "(" field_list ")"
                | "HOLONOMY" name "ON" "FIBER" "(" field_list ")" "AROUND" field
                | "HOLONOMY" name "NEAR" "(" f64_kv_pairs ")" "WITHIN" number
                  ("METRIC" ("euclidean" | "cosine"))?
                  "ON" "FIBER" "(" field_list ")" "AROUND" field
transport_fiber = "TRANSPORT" name "FROM" "(" kv_pairs ")" "TO" "(" kv_pairs ")"
                  "ON" "FIBER" "(" field_list ")"
gauge_test_stmt = "GAUGE" name "VS" name "ON" "FIBER" "(" field_list ")" "AROUND" field
consistency_stmt = "CONSISTENCY" name ("REPAIR")?
partition_stmt  = "PARTITION" name ("AT" key_preds | "WHERE" field "NEAR" value) "TOLERANCE" num
calibrate_stmt  = "CALIBRATE" name "TOLERANCE" number
flow_stmt       = "FLOW" name "COARSEN" "BY" field "LEVELS" number
                  ("MEASURE" agg_list)? ("SHOW" "ENTROPY")?
geodesic_stmt   = "GEODESIC" name "FROM" key_preds "TO" key_preds
restrict_stmt   = "RESTRICT" name "TO" "(" query ")" ("AS" name)?
glue_stmt       = "GLUE" "(" query ")" "WITH" "(" query ")" ("CHECK" "OVERLAP")?
predict_stmt    = "PREDICT" name "ON" field "BY" field
                  ("TRAIN" "BEFORE" predicate "TEST" "AFTER" predicate)?
diff_stmt       = "DIFF" name ("AT" "SNAPSHOT" string)? "AGAINST" name
snapshot_stmt   = "SNAPSHOT" name "AS" string
health_stmt     = "HEALTH" name
atlas_stmt      = "ATLAS" ("BEGIN" ("ISOLATION" ("FLAT"|"CURVED"))?
                | "COMMIT" | "ROLLBACK" ("TO" name)? | "SAVEPOINT" name)
subscribe_stmt  = "SUBSCRIBE" subscribe_target | "UNSUBSCRIBE" name
subscribe_target = name on_clause?
                 | "ANOMALIES" name ("ON" field)?
                 | "CURVATURE" name ("ON" field)? "DRIFT" ">" number
                 | "CONSISTENCY" name | "SPECTRAL" name
                 | "PHASE" name "ON" field
                 | "DIVERGENCE" name "THRESHOLD" number
explain_stmt    = "EXPLAIN" statement
translate_stmt  = "TRANSLATE" "SQL" string
show_stmt       = "SHOW" "BUNDLES" ("VERBOSE")?
describe_stmt   = "DESCRIBE" name ("VERBOSE")?
ingest_stmt     = "INGEST" name "FROM" (string | "STDIN") "FORMAT" format_name
                  ("HEADER" bool)? ("DELIMITER" char)? ("NULL_VALUE" string)?
                  ("SKIP" number)? ("MAP" "(" field_map ")")? ("FILTER" "(" where_clause ")")?
emit_file_stmt  = cover_stmt "EMIT" format_name "TO" (string | "STDOUT")
                  ("WITH" meta_list)?
generate_stmt   = "GENERATE" "BASE" name "FROM" key_preds "TO" key_preds "STEP" number
                  ("WITH" "(" kv_pairs ")")?
fill_stmt       = "FILL" name "ON" field "USING" ("TRANSPORT" | "INTERPOLATE" interp_method
                  | "CONSTANT" "(" kv_pairs ")")
transplant_stmt = "TRANSPLANT" name "INTO" name
                  ("WHERE" pred_expr)? ("MAP" "(" field_map ")")? ("RETRACT" "SOURCE")?

on_clause       = "ON" index_pred ("AND" index_pred)*
where_clause    = "WHERE" pred_expr
project         = "PROJECT" "(" proj_list ")"
distinct        = "DISTINCT" field
rank            = "RANK" "BY" field ("ASC"|"DESC")?
pagination      = ("FIRST" number)? ("SKIP" number)?
confidence_filter = "CONFIDENCE" (">="|">") number
restrict        = "RESTRICT" "TO" "(" query ")"
having          = "HAVING" pred_expr
emit            = "EMIT" ("DHOOM"|"JSON"|"CSV") ("WITH" meta_list)? ("BARE")?

index_pred      = field "=" value | field "IN" "(" (values | query) ")"
pred_expr       = pred_term ("OR" pred_term)*
pred_term       = pred_atom ("AND" pred_atom)*
pred_atom       = field comp_op value | field "MATCHES" string
                | field "VOID" | field "DEFINED" | field "NEAR" value
                | "CURVATURE" "(" field ")" comp_op number
                | "CONFIDENCE" "(" ")" comp_op number
                | "ANOMALY" "(" ")" "=" bool
                | "Z_SCORE" "(" ")" comp_op number
```

---

## XXVI. PostgreSQL Parity Checklist

| Category | PostgreSQL | GQL v2.1 | Status |
|---|---|---|---|
| CRUD | ✓ | ✓ | ✅ SECTION, REDEFINE, RETRACT, UPSERT |
| Range queries | ✓ | ✓ | ✅ COVER with ON/WHERE, DISTINCT, RANK, FIRST, SKIP |
| Aggregation | ✓ | ✓ | ✅ INTEGRATE with FILTER clause |
| Window functions | ✓ | ✓ | ✅ FIBER operations + TRANSPORT |
| Joins | ✓ | ✓ | ✅ PULLBACK + PRODUCT + set ops |
| Subqueries / CTEs | ✓ | ✓ | ✅ Nested covers + WITH + WITH RECURSIVE |
| Recursive queries | ✓ | ✓ | ✅ ITERATE |
| Transactions | ✓ | ✓ | ✅ ATLAS with FLAT/CURVED isolation |
| Constraints | ✓ | ✓ | ✅ CHECK, UNIQUE, REFERENCES, MORPHISM, IN, EXCLUDE |
| Access control | ✓ | ✓ | ❌ Specified; returns 501 |
| Row-level security | ✓ | ✓ | ❌ POLICY specified; returns 501 |
| Audit trail | ✓ | ✓ | ❌ Specified; returns 501 |
| Math functions | ✓ | ✓ | ✅ |
| String functions | ✓ | ✓ | ✅ |
| Date functions | ✓ | ✓ | ✅ |
| Type casting | ✓ | ✓ | ✅ CAST, :: shorthand |
| Conditional expressions | ✓ | ✓ | ✅ CLASSIFY, IF, RESOLVE, VOIDIF, GREATEST, LEAST |
| RETURNING | ✓ | ✓ | ✅ On SECTION, REDEFINE, RETRACT |
| Conditional aggregation | ✓ | ✓ | ✅ FILTER (WHERE ...) on any aggregate |
| Generate series | ✓ | ✓ | ✅ GENERATE BASE + FILL |
| Bulk import | ✓ | ✓ | ✅ INGEST from CSV/JSON/JSONL/DHOOM/SQL/URL |
| Bulk export | ✓ | ✓ | ✅ EMIT TO file (CSV/JSON/DHOOM) |
| Prepared statements | ✓ | ✓ | ❌ Specified; returns 501 |
| Triggers | ✓ | ✓ | ⚠️ Parsed; TriggerManager built but not wired |
| Cascade operations | ✓ | ✓ | ⚠️ Parsed; not wired |
| Backup/restore | ✓ | ✓ | ❌ Specified; returns 501 |
| Maintenance | ✓ | ✓ | ⚠️ COMPACT/ANALYZE/VACUUM parsed; no-op |
| Session management | ✓ | ✓ | ❌ SET/RESET return 501 |
| Information schema | ✓ | ✓ | ✅ SHOW BUNDLES/FIELDS/INDEXES/CONSTRAINTS/etc. |
| Comments | ✓ | ✓ | ❌ Returns 501 |
| **GQL-only (no SQL equivalent)** | | | |
| Curvature / Ricci / Spectral | — | ✓ | ✅ |
| Fiber Laplacian eigenmodes (SPECTRAL … ON FIBER … MODES k) | — | ✓ | ✅ |
| Betti / Euler / Topology | — | ✓ | ✅ |
| Entropy / Free Energy | — | ✓ | ✅ |
| Geodesic / Similarity | — | ✓ | ✅ |
| Phase transitions | — | ✓ | ✅ |
| Anomaly detection | — | ✓ | ✅ |
| Double Cover (S + d² = 1) | — | ✓ | ✅ |
| Geometric encryption | — | ✓ | ✅ GaugeKey on ENCRYPTED fields |
| Confidence filtering | — | ✓ | ✅ |
| Global fiber holonomy (HOLONOMY … ON FIBER … AROUND) | — | ✓ | ✅ |
| Local fiber holonomy (HOLONOMY … NEAR … WITHIN … ON FIBER) | — | ✓ | ✅ |
| Fiber parallel transport matrix (TRANSPORT … FROM … TO … ON FIBER) | — | ✓ | ✅ |
| Cross-bundle gauge invariance test (GAUGE … VS … ON FIBER) | — | ✓ | ✅ |
| Sheaf restriction / gluing | — | ✓ | ⚠️ Sheaf module built; not wired |
| Subscriptions (WebSocket) | — | ✓ | ✅ |

## Homogeneous Three-Sphere Ricci Flow (RICCI_FLOW)

Requires `gauge`. This evolves a smooth, left-invariant SU(2) metric, not a
record-variance statistic or graph curvature proxy. Input coefficients are
squared lengths in a fixed frame with cyclic bracket `[e1,e2]=2e3`.

```sql
RICCI_FLOW SU2 METRIC (1,1,1) TIME 0.2 STEPS 16;
RICCI_FLOW SU2 METRIC (0.5,1,2) TIME 2 STEPS 1024 NORMALIZED;
```

The first is Hamilton flow `dg/dt=-2Ric`; the second adds `(2/3)R*g` to
preserve volume. Returns `STEPS+1` trajectory rows, including time zero,
metric components, Ricci and sectional curvature, cover volume, anisotropy,
step-doubling error estimates and scope disclosures. Computation does not
require an existing bundle and does not mutate stored records.

Optional `TOLERANCE` defaults to `0.00000001`. It applies to a Richardson
estimate relative to the largest initial metric coefficient, not a rigorous
error enclosure. `STEPS` is bounded to 1..4096. A nonpositive intermediate
metric or excessive estimate refuses the whole request. Shorten the interval
or increase the resolution; the engine does not step through singularities.

`NORMALIZED` and `TOLERANCE` may each occur once. Only `SU2` is supported.
There is no surgery, arbitrary-manifold recognition, or Wilson/Ricci
equivalence claim. See [the scope, equations and gates](docs/RICCI_FLOW_SU2_SPEC.md).

## Ricci / Yang-Mills Mapping Audit (RICCI_WILSON_AUDIT)

Requires the `gauge` feature. This diagnostic evaluates two independently
implemented operators at the same positive diagonal SU(2) metric:

```sql
RICCI_WILSON_AUDIT SU2 METRIC (3,1,1);
RICCI_WILSON_AUDIT SU2 METRIC (0.5,1,2) NORMALIZED;
```

The first operator maps the Ricci metric velocity through its Levi-Civita
connection. The second is the negative Yang-Mills action gradient using that
instantaneous metric. The time scale is fixed at one. The response includes
both three-component velocities, their actual difference, weighted norms,
connection/curvature coefficients, action density and explicit conventions.
At `(3,1,1)`, both velocities are `(48,-8*sqrt(3),-8*sqrt(3))`.

Metric coefficients are squared lengths in `[1e-6,1e6]`, with max/min at most
10,000. No bundle is created or scanned. This is a local homogeneous continuum
audit, not a lattice Wilson-flow solver or a fixed-background equivalence
claim. In particular, the map forgets overall metric scale. Deck groups and
Levi-Civita holonomy are different objects.

See [the mapping, independent operators and gates](docs/RICCI_WILSON_CORRESPONDENCE_SPEC.md).

## Bounded SU(2) Generator Closure (MONODROMY_GROUP_ORDER)

Requires `--features gauge` (included by `halcyon`). Operates on a declared
gauge field, not a bundle name. Both embedded GQL and `POST /v1/gql` use the
same closure implementation.

```sql
MONODROMY_GROUP_ORDER field FROM EDGES (0, 1)
  COMMUTATOR CAP 256 TOLERANCE 0.00000001;
```

GIGI enumerates products of the selected forward edge elements and their
inverses, constructs a complete multiplication table, and checks identity,
inverses, and every associativity triple. It returns one row with the table's
order and an element-order histogram (`element_orders`, `element_order_counts`).
`COMMUTATOR` additionally computes the derived subgroup order, `is_perfect`,
and the abelianization order.

`COMMUTATOR`, `CAP`, and `TOLERANCE` are optional, order-independent, and may
appear only once. Default cap: 256; default tolerance: 1e-8. Limits: 1..32
generator edges, cap 1..256, tolerance [1e-12, 1e-6]. Only SU(2) is supported.
Unit-norm inputs are required within 1e-10; the query normalizes accepted
copies once and reports the input residual. It never identifies q with -q.

An accepted table has `status: numerically_closed`, `table_verified: true`,
and `exact_subgroup_certified: false`. Cap exhaustion or ambiguous numerical
matches return `status: unresolved` with null order fields and a reason.
They do not establish an infinite group. Invalid inputs refuse.

This computes the subgroup of **supplied generators**. It does not infer that
the edges are loops, prove a representation faithful, or recognize a manifold.
Simultaneous conjugation preserves the answer; arbitrary independent changes
at unrelated edge endpoints need not. See
[the mathematical contract and gates](docs/MONODROMY_GROUP_ORDER_SPEC.md).
